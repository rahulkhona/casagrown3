import React, { useState } from 'react';
import { Camera, MapPin, Bell, Phone, Mail, LogOut, Edit2, Save, X, Upload, Plus, CheckCircle, Users, ShoppingBag, Wrench, Settings } from 'lucide-react';
import ToggleSwitch from './ToggleSwitch';

interface User {
  id: string;
  name: string;
  email: string;
  photo?: string;
  points: number;
  communities: string[];
  roles: string[];
  communityRoles?: { [community: string]: string[] };
}

interface ProfilePageProps {
  user: User;
  onUpdate: (user: User) => void;
  onLogout: () => void;
  onNavigateToFollowing?: () => void;
  onDeactivateAccount?: () => void;
}

export default function ProfilePage({ user, onUpdate, onLogout, onNavigateToFollowing, onDeactivateAccount }: ProfilePageProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user.name);
  const [photo, setPhoto] = useState(user.photo || '');
  const [phone, setPhone] = useState('(555) 123-4567');
  const [pushNotifications, setPushNotifications] = useState(true);
  const [smsNotifications, setSmsNotifications] = useState(false);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [community, setCommunity] = useState<string>(user.communities[0] || '');
  const [roles, setRoles] = useState<string[]>(user.roles || ['buyer']);
  const [isChangingCommunity, setIsChangingCommunity] = useState(false);
  const [newZipcode, setNewZipcode] = useState('');
  const [selectedNewCommunity, setSelectedNewCommunity] = useState('');
  const [newRoles, setNewRoles] = useState<string[]>([]);

  // Mock communities based on zipcode
  const mockCommunities = [
    'Lincoln High School Community',
    'Washington High School Community',
    'Roosevelt High School Community',
    'Jefferson High School Community'
  ];

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    const updatedUser = {
      ...user,
      name,
      photo,
      communities: community ? [community] : [],
      roles
    };
    onUpdate(updatedUser);
    localStorage.setItem('casagrown_user', JSON.stringify(updatedUser));
    setIsEditing(false);
  };

  const handleChangeCommunity = () => {
    if (selectedNewCommunity && newRoles.length > 0) {
      setCommunity(selectedNewCommunity);
      setRoles(newRoles);
      setIsChangingCommunity(false);
      setNewZipcode('');
      setSelectedNewCommunity('');
      setNewRoles([]);
    }
  };

  const handleLeaveCommunity = () => {
    setCommunity('');
    setRoles([]);
  };

  const handleRoleToggle = (role: string) => {
    if (roles.includes(role)) {
      setRoles(roles.filter(r => r !== role));
    } else {
      setRoles([...roles, role]);
    }
  };

  const handleNewRoleToggle = (role: string) => {
    if (newRoles.includes(role)) {
      setNewRoles(newRoles.filter(r => r !== role));
    } else {
      setNewRoles([...newRoles, role]);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Profile Settings</h1>
          {!isEditing && (
            <button
              onClick={() => setIsEditing(true)}
              className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              <Edit2 className="w-4 h-4" />
              Edit Profile
            </button>
          )}
        </div>

        {/* Profile Card */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
          <div className="p-6">
            {/* Photo and Basic Info */}
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 mb-6 pb-6 border-b border-gray-200">
              <div className="flex flex-col items-center gap-3">
                <div className="relative">
                  {photo ? (
                    <img src={photo} alt={name} className="w-24 h-24 rounded-full object-cover" />
                  ) : (
                    <div className="w-24 h-24 bg-green-600 rounded-full flex items-center justify-center text-white text-3xl font-bold">
                      {name.charAt(0).toUpperCase()}
                    </div>
                  )}
                  {isEditing && (
                    <label className="absolute bottom-0 right-0 w-8 h-8 bg-green-600 rounded-full flex items-center justify-center cursor-pointer hover:bg-green-700 transition-colors shadow-lg">
                      <Camera className="w-4 h-4 text-white" />
                      <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                    </label>
                  )}
                </div>
                
                {/* Upload or Take Photo Options */}
                {isEditing && (
                  <div className="flex gap-2">
                    <label className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-gray-300 rounded-lg cursor-pointer hover:border-green-500 hover:bg-green-50 transition-all text-sm">
                      <Upload className="w-3.5 h-3.5 text-gray-600" />
                      <span className="text-xs font-medium text-gray-700">Upload</span>
                      <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                    </label>
                    
                    <label className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-gray-300 rounded-lg cursor-pointer hover:border-green-500 hover:bg-green-50 transition-all text-sm">
                      <Camera className="w-3.5 h-3.5 text-gray-600" />
                      <span className="text-xs font-medium text-gray-700">Take Photo</span>
                      <input type="file" accept="image/*" capture="user" onChange={handlePhotoUpload} className="hidden" />
                    </label>
                  </div>
                )}
              </div>
              
              <div className="flex-1 text-center sm:text-left">
                {isEditing ? (
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="text-2xl font-bold text-gray-900 mb-2 px-3 py-1 border-2 border-green-500 rounded-lg focus:outline-none w-full sm:w-auto"
                  />
                ) : (
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">{name}</h2>
                )}
                <p className="text-gray-600 mb-4">{user.email}</p>
              </div>

              {isEditing && (
                <div className="flex gap-2">
                  <button
                    onClick={handleSave}
                    className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                  >
                    <Save className="w-4 h-4" />
                    Save
                  </button>
                  <button
                    onClick={() => {
                      setIsEditing(false);
                      setName(user.name);
                      setPhoto(user.photo || '');
                      setCommunity(user.communities[0] || '');
                      setRoles(user.roles || ['buyer']);
                    }}
                    className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <X className="w-4 h-4" />
                    Cancel
                  </button>
                </div>
              )}
            </div>

            {/* My Community */}
            <div className="mb-6">
              <h3 className="font-semibold text-gray-900 mb-3">My Community</h3>
              
              {community ? (
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <MapPin className="w-5 h-5 text-green-600" />
                      <span className="font-medium text-gray-900">{community}</span>
                    </div>
                    {isEditing && (
                      <button
                        onClick={handleLeaveCommunity}
                        className="text-sm text-red-600 hover:text-red-700 font-medium"
                      >
                        Leave Community
                      </button>
                    )}
                  </div>
                  
                  {/* Roles - Display Only */}
                  <div className="ml-8 flex flex-wrap gap-2">
                    {roles.map((role) => (
                      <span key={role} className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium capitalize">
                        {role.replace('-', ' ')}
                      </span>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-4 border-2 border-dashed border-gray-300 rounded-lg">
                  <p className="text-sm text-gray-600 mb-3">You haven't joined a community yet.</p>
                  {isEditing && (
                    <button
                      onClick={() => setIsChangingCommunity(true)}
                      className="flex items-center gap-2 text-sm text-green-600 hover:text-green-700 font-medium"
                    >
                      <Plus className="w-4 h-4" />
                      Join a Community
                    </button>
                  )}
                </div>
              )}

              {/* Change Community UI */}
              {isEditing && isChangingCommunity && (
                <div className="mt-3 p-4 border-2 border-green-300 bg-green-50 rounded-lg">
                  <div className="mb-3">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Enter Zip Code to Find Communities
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={newZipcode}
                        onChange={(e) => setNewZipcode(e.target.value)}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white"
                        placeholder="Enter zip code"
                        maxLength={5}
                      />
                      <button
                        className="px-3 py-2 border border-gray-300 rounded-lg hover:bg-white transition-colors bg-white"
                        title="Use current location"
                      >
                        <MapPin className="w-5 h-5 text-gray-600" />
                      </button>
                    </div>
                  </div>

                  {/* Community Selection - only show if zip code is 5 digits */}
                  {newZipcode.length === 5 && (
                    <>
                      <div className="mb-3">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Select Your Community
                        </label>
                        <p className="text-xs text-gray-500 mb-2">Join the community closest to you</p>
                        <div className="space-y-2">
                          {mockCommunities.map((comm) => (
                            <button
                              key={comm}
                              onClick={() => setSelectedNewCommunity(comm)}
                              className={`w-full flex items-center justify-between p-3 border-2 rounded-lg transition-all ${
                                selectedNewCommunity === comm
                                  ? 'border-green-500 bg-white'
                                  : 'border-gray-200 hover:border-gray-300 bg-white'
                              }`}
                            >
                              <div className="flex items-center gap-2">
                                <Users className="w-4 h-4 text-gray-600" />
                                <span className="text-sm font-medium text-gray-900">{comm}</span>
                              </div>
                              {selectedNewCommunity === comm && (
                                <CheckCircle className="w-5 h-5 text-green-600" />
                              )}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Roles for new community */}
                      {selectedNewCommunity && (
                        <div className="mb-3">
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Select Your Roles
                          </label>
                          <div className="space-y-2">
                            <label className="flex items-center justify-between p-3 bg-white rounded-lg border border-gray-200 cursor-pointer hover:border-green-300 transition-colors">
                              <div className="flex items-center gap-3">
                                <ShoppingBag className="w-5 h-5 text-gray-600" />
                                <span className="text-gray-900 font-medium">Buyer</span>
                              </div>
                              <ToggleSwitch
                                checked={newRoles.includes('buyer')}
                                onChange={() => handleNewRoleToggle('buyer')}
                              />
                            </label>

                            <label className="flex items-center justify-between p-3 bg-white rounded-lg border border-gray-200 cursor-pointer hover:border-green-300 transition-colors">
                              <div className="flex items-center gap-3">
                                <Users className="w-5 h-5 text-gray-600" />
                                <span className="text-gray-900 font-medium">Seller</span>
                              </div>
                              <ToggleSwitch
                                checked={newRoles.includes('seller')}
                                onChange={() => handleNewRoleToggle('seller')}
                              />
                            </label>

                            <label className="flex items-center justify-between p-3 bg-white rounded-lg border border-gray-200 cursor-pointer hover:border-green-300 transition-colors">
                              <div className="flex items-center gap-3">
                                <Wrench className="w-5 h-5 text-gray-600" />
                                <span className="text-gray-900 font-medium">Service Provider</span>
                              </div>
                              <ToggleSwitch
                                checked={newRoles.includes('service-provider')}
                                onChange={() => handleNewRoleToggle('service-provider')}
                              />
                            </label>
                          </div>
                        </div>
                      )}
                    </>
                  )}

                  <div className="flex gap-2 mt-3">
                    <button
                      onClick={handleChangeCommunity}
                      disabled={!selectedNewCommunity || newRoles.length === 0}
                      className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
                    >
                      {community ? 'Switch Community' : 'Join Community'}
                    </button>
                    <button
                      onClick={() => {
                        setIsChangingCommunity(false);
                        setNewZipcode('');
                        setSelectedNewCommunity('');
                        setNewRoles([]);
                      }}
                      className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-white transition-colors"
                    >
                          Cancel
                    </button>
                  </div>
                </div>
              )}

              {/* Button to change community */}
              {isEditing && community && !isChangingCommunity && (
                <div className="mt-3">
                  <button
                    onClick={() => setIsChangingCommunity(true)}
                    className="flex items-center gap-2 text-sm text-green-600 hover:text-green-700 font-medium"
                  >
                    <Settings className="w-4 h-4" />
                    Switch to Different Community
                  </button>
                </div>
              )}
            </div>

            {/* Contact Information - Only show phone when SMS is enabled */}
            <div className="mb-6 pb-6 border-b border-gray-200">
              <h3 className="font-semibold text-gray-900 mb-3">Contact Information</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-gray-400" />
                  <span className="text-gray-900">{user.email}</span>
                  <span className="ml-auto px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded">Verified</span>
                </div>
                {smsNotifications && (
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-gray-400" />
                    {isEditing ? (
                      <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="flex-1 px-3 py-1 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        placeholder="(555) 123-4567"
                      />
                    ) : (
                      <span className="text-gray-900">{phone}</span>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Notification Preferences */}
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">Notification Preferences</h3>
              <div className="space-y-3">
                <label className="flex items-center justify-between p-3 bg-gray-50 rounded-lg cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Bell className="w-5 h-5 text-gray-600" />
                    <div>
                      <div className="font-medium text-gray-900">Push Notifications</div>
                      <div className="text-sm text-gray-600">Get instant updates on your device</div>
                    </div>
                  </div>
                  <ToggleSwitch
                    checked={pushNotifications}
                    onChange={(val) => setPushNotifications(val)}
                  />
                </label>

                <label className="flex items-center justify-between p-3 bg-gray-50 rounded-lg cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-gray-600" />
                    <div>
                      <div className="font-medium text-gray-900">SMS Notifications</div>
                      <div className="text-sm text-gray-600">Receive text message alerts</div>
                    </div>
                  </div>
                  <ToggleSwitch
                    checked={smsNotifications}
                    onChange={(val) => setSmsNotifications(val)}
                  />
                </label>

                {/* Phone Number (if SMS enabled) */}
                {smsNotifications && (
                  <div className="ml-13">
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      placeholder="(555) 123-4567"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Stats Card */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
          <div className="p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Activity Stats</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-gray-900">127</div>
                <div className="text-sm text-gray-600">Transactions</div>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-gray-900">4.8</div>
                <div className="text-sm text-gray-600">Rating</div>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-gray-900">23</div>
                <div className="text-sm text-gray-600">Posts</div>
              </div>
              <button
                onClick={onNavigateToFollowing}
                className="text-center p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors cursor-pointer"
              >
                <div className="text-2xl font-bold text-green-700">4</div>
                <div className="text-sm text-green-700 font-medium">Following</div>
              </button>
            </div>
          </div>
        </div>

        {/* Danger Zone */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden border-2 border-red-200">
          <div className="p-6">
            <h3 className="font-semibold text-red-600 mb-4">Account Actions</h3>
            <div className="space-y-3">
              <button
                onClick={onLogout}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-red-600 text-white font-medium rounded-lg hover:bg-red-700 transition-colors"
              >
                <LogOut className="w-5 h-5" />
                Logout
              </button>
              {onDeactivateAccount && (
                <button
                  onClick={onDeactivateAccount}
                  className="w-full px-4 py-3 border-2 border-red-600 text-red-600 font-medium rounded-lg hover:bg-red-50 transition-colors"
                >
                  Deactivate Account
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}