import React, { useState } from 'react';
import { ArrowLeft, Star, MapPin, Calendar, MessageCircle, Heart, ShoppingBag, Package, Wrench, MessageSquare, Lightbulb, Image as ImageIcon, UserPlus, UserCheck } from 'lucide-react';

interface User {
  id: string;
  name: string;
  points: number;
}

interface UserPostsPageProps {
  userId: string;
  currentUser: User;
  onBack: () => void;
  onPostClick: (postId: string) => void;
  onFollowToggle: (userId: string) => void;
  isFollowing: boolean;
}

interface Post {
  id: string;
  type: 'sell' | 'buy' | 'service-request' | 'service-offer' | 'advice' | 'show-tell';
  title: string;
  description: string;
  price?: number;
  category: string;
  imageUrl?: string;
  createdAt: Date;
  likes: number;
  community: string;
}

interface UserProfile {
  id: string;
  name: string;
  photo?: string;
  bio: string;
  rating: number;
  totalReviews: number;
  joinedDate: Date;
  communities: string[];
  specialties: string[];
  totalPosts: number;
  totalTransactions: number;
}

export default function UserPostsPage({ userId, currentUser, onBack, onPostClick, onFollowToggle, isFollowing }: UserPostsPageProps) {
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [likedPosts, setLikedPosts] = useState<Set<string>>(new Set());

  // Mock user profiles data
  const userProfiles: Record<string, UserProfile> = {
    '2': {
      id: '2',
      name: 'Sarah Johnson',
      photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400',
      bio: 'Passionate organic gardener specializing in heirloom tomatoes and herbs. Love sharing my harvest and composting knowledge with the community!',
      rating: 5.0,
      totalReviews: 47,
      joinedDate: new Date('2024-01-15'),
      communities: ['Lincoln High School Community'],
      specialties: ['Tomatoes', 'Herbs', 'Composting'],
      totalPosts: 28,
      totalTransactions: 134
    },
    '3': {
      id: '3',
      name: 'Michael Chen',
      photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400',
      bio: 'Home chef and fruit enthusiast. Always looking for fresh, locally-grown produce to create delicious meals for my family.',
      rating: 4.9,
      totalReviews: 32,
      joinedDate: new Date('2023-11-20'),
      communities: ['Washington High School Community'],
      specialties: ['Fruits', 'Berries', 'Cooking'],
      totalPosts: 19,
      totalTransactions: 87
    },
    '4': {
      id: '4',
      name: 'David Martinez',
      photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400',
      bio: 'Retired professional landscaper with 30 years of experience. Happy to share my tools, knowledge, and help neighbors with their garden projects.',
      rating: 4.9,
      totalReviews: 23,
      joinedDate: new Date('2024-02-20'),
      communities: ['Lincoln High School Community', 'Roosevelt High School Community'],
      specialties: ['Equipment', 'Landscaping', 'Fruit Trees'],
      totalPosts: 15,
      totalTransactions: 56
    },
    '5': {
      id: '5',
      name: 'Jessica Martinez',
      photo: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400',
      bio: 'High school junior building my lawn care business. Reliable, affordable, and passionate about outdoor work. Saving up for college!',
      rating: 4.8,
      totalReviews: 31,
      joinedDate: new Date('2024-03-10'),
      communities: ['Lincoln High School Community'],
      specialties: ['Lawn Care', 'Weeding', 'Yard Cleanup'],
      totalPosts: 24,
      totalTransactions: 78
    },
    '8': {
      id: '8',
      name: 'Amanda Rodriguez',
      photo: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=400',
      bio: 'New to gardening and loving every minute of it! Learning from this amazing community while growing cucumbers and herbs. Also love garden photography!',
      rating: 4.5,
      totalReviews: 8,
      joinedDate: new Date('2024-04-01'),
      communities: ['Lincoln High School Community'],
      specialties: ['Cucumbers', 'Learning', 'Photography'],
      totalPosts: 11,
      totalTransactions: 23
    }
  };

  // Mock posts by user
  const allUserPosts: Record<string, Post[]> = {
    '2': [
      {
        id: 'intro-2',
        type: 'show-tell',
        title: 'Hello from a Tomato Lover! 🍅',
        description: 'Hi neighbors! I\'m Sarah and I\'ve been growing organic vegetables for over a decade. Started with just a few pots on my balcony...',
        category: 'Introduction',
        imageUrl: 'https://images.unsplash.com/photo-1592841200221-a6898f307baa?w=800',
        createdAt: new Date('2024-01-16'),
        likes: 34,
        community: 'Lincoln High School Community'
      },
      {
        id: '1',
        type: 'sell',
        title: 'Fresh Organic Tomatoes',
        description: 'Just harvested! 5 lbs of fresh organic heirloom tomatoes from my backyard garden.',
        price: 50,
        category: 'Vegetables',
        imageUrl: 'https://images.unsplash.com/photo-1645931413394-01bd95d294ca?w=800',
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
        likes: 12,
        community: 'Lincoln High School Community'
      },
      {
        id: 's2-1',
        type: 'sell',
        title: 'Fresh Basil and Cilantro Bundle',
        description: 'Huge bundle of organic basil and cilantro. Perfect for pesto, salsa, or cooking!',
        price: 25,
        category: 'Herbs',
        imageUrl: 'https://images.unsplash.com/photo-1509358271058-acd22cc93898?w=800',
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        likes: 18,
        community: 'Lincoln High School Community'
      },
      {
        id: 's2-2',
        type: 'advice',
        title: 'Best Practices for Composting in Small Spaces',
        description: 'Sharing my tips for successful composting even if you only have a small backyard or balcony. Happy to answer questions!',
        category: 'Composting',
        imageUrl: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800',
        createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
        likes: 45,
        community: 'Lincoln High School Community'
      },
      {
        id: 's2-3',
        type: 'sell',
        title: 'Heirloom Tomato Variety Pack',
        description: 'Try 5 different heirloom varieties! Cherokee Purple, Brandywine, Green Zebra, and more.',
        price: 60,
        category: 'Vegetables',
        imageUrl: 'https://images.unsplash.com/photo-1574673215765-e95e82825f3d?w=800',
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
        likes: 22,
        community: 'Lincoln High School Community'
      },
      {
        id: 's2-4',
        type: 'show-tell',
        title: 'My Garden Tour - 15 Varieties Growing!',
        description: 'Wanted to share my pride and joy - my backyard tomato garden with 15 different heirloom varieties all thriving!',
        category: 'Garden Tour',
        imageUrl: 'https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=800',
        createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
        likes: 67,
        community: 'Lincoln High School Community'
      }
    ],
    '3': [
      {
        id: '2',
        type: 'buy',
        title: 'Looking for Fresh Strawberries',
        description: 'Anyone have fresh strawberries available? Need about 2-3 lbs for a family gathering this weekend.',
        price: 40,
        category: 'Fruits',
        imageUrl: 'https://images.unsplash.com/photo-1629905707362-03cf1a9f6e2d?w=800',
        createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
        likes: 8,
        community: 'Washington High School Community'
      },
      {
        id: 'm3-1',
        type: 'buy',
        title: 'Need Fresh Blueberries',
        description: 'Looking for 2-3 lbs of fresh blueberries for baking. Will pay up to 45 points.',
        price: 45,
        category: 'Fruits',
        imageUrl: 'https://images.unsplash.com/photo-1498557850523-fd3d118b962e?w=800',
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        likes: 5,
        community: 'Washington High School Community'
      },
      {
        id: 'm3-2',
        type: 'show-tell',
        title: 'Made Fresh Berry Tart with Community Produce!',
        description: 'Just wanted to share this beautiful berry tart I made using strawberries from Sarah and blueberries from Tom. Thank you neighbors!',
        category: 'Recipes',
        imageUrl: 'https://images.unsplash.com/photo-1519915028121-7d3463d20b13?w=800',
        createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
        likes: 41,
        community: 'Washington High School Community'
      }
    ],
    '4': [
      {
        id: 'intro-4',
        type: 'show-tell',
        title: 'Former Landscaper Here to Help!',
        description: 'Hello everyone! After 30 years in professional landscaping, I recently retired and I\'m loving every minute of it...',
        category: 'Introduction',
        imageUrl: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800',
        createdAt: new Date('2024-02-21'),
        likes: 28,
        community: 'Lincoln High School Community'
      },
      {
        id: '3',
        type: 'sell',
        title: 'Premium Garden Tool Set',
        description: 'Professional grade garden tool set including spade, hoe, rake, and pruning shears.',
        price: 150,
        category: 'Equipment',
        imageUrl: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800',
        createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
        likes: 15,
        community: 'Lincoln High School Community'
      },
      {
        id: 'd4-1',
        type: 'service-offer',
        title: 'Free Fruit Tree Pruning Consultation',
        description: 'Offering free consultations for fruit tree care and pruning. 30+ years of professional experience.',
        price: 0,
        category: 'Services',
        imageUrl: 'https://images.unsplash.com/photo-1560493676-04071c5f467b?w=800',
        createdAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000),
        likes: 52,
        community: 'Lincoln High School Community'
      },
      {
        id: 'd4-2',
        type: 'advice',
        title: 'Fall is the Best Time to Plant Fruit Trees',
        description: 'Professional tip: Fall planting gives fruit trees time to establish roots before spring growth. Here\'s what you need to know...',
        category: 'Landscaping',
        imageUrl: 'https://images.unsplash.com/photo-1557296387-5358ad7997bb?w=800',
        createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
        likes: 38,
        community: 'Lincoln High School Community'
      }
    ],
    '5': [
      {
        id: 'intro-5',
        type: 'show-tell',
        title: 'Teen Entrepreneur Ready to Help! 💪',
        description: 'Hi everyone! I\'m Jessica, a junior at Lincoln High, and I\'m building my lawn care and gardening business...',
        category: 'Introduction',
        imageUrl: 'https://images.unsplash.com/photo-1558904541-efa843a96f01?w=800',
        createdAt: new Date('2024-03-11'),
        likes: 42,
        community: 'Lincoln High School Community'
      },
      {
        id: 'j5-1',
        type: 'service-offer',
        title: 'Affordable Lawn Mowing - $20/yard',
        description: 'Professional lawn mowing and edging service. Reliable high school student saving for college!',
        price: 200,
        category: 'Lawn Care',
        imageUrl: 'https://images.unsplash.com/photo-1558904541-efa843a96f01?w=800',
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        likes: 19,
        community: 'Lincoln High School Community'
      },
      {
        id: 'j5-2',
        type: 'service-offer',
        title: 'Weeding and Garden Maintenance',
        description: 'Keep your garden looking great! Weeding, deadheading, and basic maintenance services.',
        price: 150,
        category: 'Weeding',
        imageUrl: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800',
        createdAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000),
        likes: 24,
        community: 'Lincoln High School Community'
      }
    ],
    '8': [
      {
        id: 'intro-8',
        type: 'show-tell',
        title: 'New Gardener, Excited to Learn! 🌱',
        description: 'Hello neighbors! I just moved to the area a few months ago and decided to try my hand at gardening for the first time...',
        category: 'Introduction',
        imageUrl: 'https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?w=800',
        createdAt: new Date('2024-04-02'),
        likes: 51,
        community: 'Lincoln High School Community'
      },
      {
        id: 'a8-1',
        type: 'show-tell',
        title: 'My First Cucumber Harvest! 🥒',
        description: 'I can\'t believe it - my first cucumbers are ready to pick! This community\'s advice made all the difference!',
        category: 'Garden Success',
        imageUrl: 'https://images.unsplash.com/photo-1568584711271-e5e960ac906a?w=800',
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        likes: 73,
        community: 'Lincoln High School Community'
      },
      {
        id: 'a8-2',
        type: 'advice',
        title: 'Question: When to Harvest Cucumbers?',
        description: 'My cucumbers are growing but I\'m not sure when they\'re ready to pick. Any advice from experienced gardeners?',
        category: 'Questions',
        imageUrl: 'https://images.unsplash.com/photo-1604684469134-f21765815e0c?w=800',
        createdAt: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000),
        likes: 15,
        community: 'Lincoln High School Community'
      },
      {
        id: 'a8-3',
        type: 'sell',
        title: 'Fresh Garden Cucumbers - First Harvest!',
        description: 'My first harvest is here! Selling fresh, crispy cucumbers at beginner-friendly prices.',
        price: 20,
        category: 'Vegetables',
        imageUrl: 'https://images.unsplash.com/photo-1568584711271-e5e960ac906a?w=800',
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        likes: 29,
        community: 'Lincoln High School Community'
      }
    ]
  };

  const profile = userProfiles[userId] || userProfiles['2'];
  const userPosts = allUserPosts[userId] || [];

  const filteredPosts = activeFilter === 'all' 
    ? userPosts 
    : userPosts.filter(post => post.type === activeFilter);

  const getTimeAgo = (date: Date) => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    if (seconds < 60) return 'just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    if (days < 30) return `${days}d ago`;
    const months = Math.floor(days / 30);
    if (months < 12) return `${months}mo ago`;
    return `${Math.floor(months / 12)}y ago`;
  };

  const toggleLike = (postId: string) => {
    const newLiked = new Set(likedPosts);
    if (newLiked.has(postId)) {
      newLiked.delete(postId);
    } else {
      newLiked.add(postId);
    }
    setLikedPosts(newLiked);
  };

  const postTypeIcons = {
    'sell': ShoppingBag,
    'buy': Package,
    'service-request': Wrench,
    'service-offer': Wrench,
    'advice': MessageSquare,
    'show-tell': ImageIcon
  };

  const postTypeColors: Record<string, string> = {
    sell: 'bg-green-100 text-green-700',
    buy: 'bg-blue-100 text-blue-700',
    'service-request': 'bg-purple-100 text-purple-700',
    'service-offer': 'bg-orange-100 text-orange-700',
    'advice': 'bg-yellow-100 text-yellow-700',
    'show-tell': 'bg-pink-100 text-pink-700'
  };

  const postTypeLabels: Record<string, string> = {
    sell: 'For Sale',
    buy: 'Wanted',
    'service-request': 'Service Needed',
    'service-offer': 'Service Offered',
    'advice': 'Advice',
    'show-tell': 'Show & Tell'
  };

  const filterOptions = [
    { value: 'all', label: 'All Posts', count: userPosts.length },
    { value: 'sell', label: 'Selling', count: userPosts.filter(p => p.type === 'sell').length },
    { value: 'buy', label: 'Buying', count: userPosts.filter(p => p.type === 'buy').length },
    { value: 'service-offer', label: 'Services', count: userPosts.filter(p => p.type === 'service-offer').length },
    { value: 'advice', label: 'Advice', count: userPosts.filter(p => p.type === 'advice').length },
    { value: 'show-tell', label: 'Show & Tell', count: userPosts.filter(p => p.type === 'show-tell').length }
  ].filter(option => option.count > 0);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>

          {/* User Profile Header */}
          <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-center">
            {/* Profile Photo */}
            {profile.photo ? (
              <img
                src={profile.photo}
                alt={profile.name}
                className="w-24 h-24 rounded-full object-cover border-4 border-green-100"
              />
            ) : (
              <div className="w-24 h-24 bg-green-600 rounded-full flex items-center justify-center text-white text-3xl font-bold border-4 border-green-100">
                {profile.name.charAt(0)}
              </div>
            )}

            {/* Profile Info */}
            <div className="flex-1">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-3">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">{profile.name}</h1>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <span className="font-semibold text-gray-900">{profile.rating.toFixed(1)}</span>
                      <span className="text-gray-500 text-sm">({profile.totalReviews} reviews)</span>
                    </div>
                  </div>
                </div>

                {/* Follow Button */}
                {currentUser.id !== userId && (
                  <button
                    onClick={() => onFollowToggle(userId)}
                    className={`flex items-center gap-2 px-6 py-2 rounded-lg font-medium transition-colors ${
                      isFollowing
                        ? 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        : 'bg-green-600 text-white hover:bg-green-700'
                    }`}
                  >
                    {isFollowing ? (
                      <>
                        <UserCheck className="w-5 h-5" />
                        Following
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-5 h-5" />
                        Follow
                      </>
                    )}
                  </button>
                )}
              </div>

              <p className="text-gray-700 mb-3">{profile.bio}</p>

              {/* Stats */}
              <div className="flex flex-wrap gap-4 text-sm mb-3">
                <div className="flex items-center gap-1 text-gray-600">
                  <Calendar className="w-4 h-4" />
                  <span>Joined {new Date(profile.joinedDate).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}</span>
                </div>
                <div className="flex items-center gap-1 text-gray-600">
                  <MapPin className="w-4 h-4" />
                  <span>{profile.communities[0]}</span>
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-green-50 rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-green-700">{profile.totalPosts}</div>
                  <div className="text-xs text-green-600">Posts</div>
                </div>
                <div className="bg-blue-50 rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-blue-700">{profile.totalTransactions}</div>
                  <div className="text-xs text-blue-600">Transactions</div>
                </div>
                <div className="bg-purple-50 rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-purple-700">{profile.rating.toFixed(1)}</div>
                  <div className="text-xs text-purple-600">Rating</div>
                </div>
              </div>

              {/* Specialties */}
              {profile.specialties.length > 0 && (
                <div className="mt-3">
                  <div className="flex flex-wrap gap-2">
                    {profile.specialties.map((specialty, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-2 overflow-x-auto py-3 scrollbar-hide">
            {filterOptions.map((option) => (
              <button
                key={option.value}
                onClick={() => setActiveFilter(option.value)}
                className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-colors ${
                  activeFilter === option.value
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {option.label} ({option.count})
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Posts Grid */}
      <div className="max-w-4xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        {filteredPosts.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm p-12 text-center">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <ImageIcon className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No posts yet</h3>
            <p className="text-gray-600">
              {activeFilter === 'all' 
                ? `${profile.name} hasn't posted anything yet.`
                : `${profile.name} hasn't posted any ${postTypeLabels[activeFilter]} posts yet.`
              }
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredPosts.map((post) => {
              const PostIcon = postTypeIcons[post.type];
              const isLiked = likedPosts.has(post.id);

              return (
                <div
                  key={post.id}
                  className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => onPostClick(post.id)}
                >
                  {/* Post Image */}
                  {post.imageUrl && (
                    <div className="aspect-video w-full overflow-hidden">
                      <img
                        src={post.imageUrl}
                        alt={post.title}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  )}

                  {/* Post Content */}
                  <div className="p-4 sm:p-6">
                    {/* Post Type Badge */}
                    <div className="flex items-center gap-2 mb-3">
                      <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium ${postTypeColors[post.type]}`}>
                        <PostIcon className="w-3.5 h-3.5" />
                        {postTypeLabels[post.type]}
                      </span>
                      <span className="text-xs text-gray-500">{getTimeAgo(post.createdAt)}</span>
                    </div>

                    {/* Title */}
                    <h3 className="text-lg font-bold text-gray-900 mb-2 line-clamp-2">
                      {post.title}
                    </h3>

                    {/* Description */}
                    <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                      {post.description}
                    </p>

                    {/* Footer */}
                    <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                      <div className="flex items-center gap-4">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleLike(post.id);
                          }}
                          className={`flex items-center gap-1.5 text-sm transition-colors ${
                            isLiked ? 'text-red-600' : 'text-gray-600 hover:text-red-600'
                          }`}
                        >
                          <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
                          <span className="font-medium">{post.likes + (isLiked ? 1 : 0)}</span>
                        </button>
                        <div className="flex items-center gap-1.5 text-gray-600 text-sm">
                          <MessageCircle className="w-5 h-5" />
                        </div>
                      </div>

                      {post.price !== undefined && post.price > 0 && (
                        <div className="text-lg font-bold text-green-600">
                          {post.price} pts
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
