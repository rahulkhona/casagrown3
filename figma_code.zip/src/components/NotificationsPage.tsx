import React, { useState } from 'react';
import { Bell, ShoppingCart, MessageCircle, Tag, Heart, UserPlus, AlertCircle, X, Users, CheckCircle, UserX, UserMinus } from 'lucide-react';

interface User {
  id: string;
  name: string;
}

interface NotificationsPageProps {
  user: User;
  onNavigateToPost: (postId: string) => void;
}

interface Notification {
  id: string;
  type: 'buy-request' | 'offer' | 'follow' | 'following-post' | 'flag-update' | 'delegate-sale-created' | 'delegate-sale-completed' | 'delegate-request-accepted' | 'delegation-revoked' | 'delegation-inactivated' | 'account-deactivated';
  title: string;
  message: string;
  postId?: string;
  isRead: boolean;
  timestamp: Date;
  user: string;
  avatar?: string;
}

const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'buy-request',
    title: 'New Buy Request Match',
    message: 'Sarah Johnson posted a buy request for Fresh Tomatoes that matches your listing',
    postId: 'post1',
    isRead: false,
    timestamp: new Date(Date.now() - 30 * 60 * 1000),
    user: 'Sarah Johnson'
  },
  {
    id: '2',
    type: 'offer',
    title: 'New Offer Received',
    message: 'Michael Chen made an offer of 45 points on your buy request for Gardening Tools',
    postId: 'post2',
    isRead: false,
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
    user: 'Michael Chen'
  },
  {
    id: '7',
    type: 'delegate-sale-created',
    title: 'Delegate Created Sale on Your Behalf',
    message: 'Jane Smith posted "Fresh Garden Tomatoes" for sale in your community',
    postId: 'post6',
    isRead: false,
    timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000),
    user: 'Jane Smith (Delegate)'
  },
  {
    id: '8',
    type: 'delegate-sale-completed',
    title: 'Delegate Sale Completed! 🎉',
    message: 'Your delegate Jane Smith completed a sale of "Fresh Garden Tomatoes" for 50 points. They will transfer your agreed share of points to you.',
    postId: 'post6',
    isRead: false,
    timestamp: new Date(Date.now() - 45 * 60 * 1000),
    user: 'Jane Smith (Delegate)'
  },
  {
    id: '3',
    type: 'following-post',
    title: 'New Post from Someone You Follow',
    message: 'Emma Davis posted fresh strawberries for sale',
    postId: 'post3',
    isRead: false,
    timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000),
    user: 'Emma Davis'
  },
  {
    id: '4',
    type: 'follow',
    title: 'New Follower',
    message: 'Robert Kim started following you',
    isRead: true,
    timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    user: 'Robert Kim'
  },
  {
    id: '5',
    type: 'offer',
    title: 'New Offer Received',
    message: 'Lisa Wong made an offer of 30 points on your buy request for Fresh Basil',
    postId: 'post4',
    isRead: true,
    timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    user: 'Lisa Wong'
  },
  {
    id: '6',
    type: 'flag-update',
    title: 'Post Flagged',
    message: 'Your post "Fresh Zucchini" has been flagged by the community',
    postId: 'post5',
    isRead: true,
    timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    user: 'Community'
  }
];

export default function NotificationsPage({ user, onNavigateToPost }: NotificationsPageProps) {
  const [notifications, setNotifications] = useState(mockNotifications);
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const unreadCount = notifications.filter(n => !n.isRead).length;
  const filteredNotifications = filter === 'unread' 
    ? notifications.filter(n => !n.isRead) 
    : notifications;

  const getIcon = (type: Notification['type']) => {
    switch (type) {
      case 'buy-request':
        return <ShoppingCart className="w-5 h-5 text-blue-600" />;
      case 'offer':
        return <Tag className="w-5 h-5 text-green-600" />;
      case 'follow':
        return <UserPlus className="w-5 h-5 text-purple-600" />;
      case 'following-post':
        return <Heart className="w-5 h-5 text-pink-600" />;
      case 'flag-update':
        return <AlertCircle className="w-5 h-5 text-red-600" />;
      case 'delegate-sale-created':
        return <Users className="w-5 h-5 text-purple-600" />;
      case 'delegate-sale-completed':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'delegate-request-accepted':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'delegation-revoked':
        return <UserX className="w-5 h-5 text-red-600" />;
      case 'delegation-inactivated':
        return <UserMinus className="w-5 h-5 text-orange-600" />;
      case 'account-deactivated':
        return <AlertCircle className="w-5 h-5 text-red-600" />;
      default:
        return <Bell className="w-5 h-5 text-gray-600" />;
    }
  };

  const handleNotificationClick = (notification: Notification) => {
    // Mark as read
    setNotifications(prev => 
      prev.map(n => n.id === notification.id ? { ...n, isRead: true } : n)
    );

    // Navigate to post if applicable
    if (notification.postId && onNavigateToPost) {
      onNavigateToPost(notification.postId);
    }
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const deleteNotification = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const formatTimestamp = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Notifications</h1>
          <div className="flex items-center justify-between">
            <p className="text-gray-600">
              {unreadCount > 0 ? `${unreadCount} unread notification${unreadCount > 1 ? 's' : ''}` : 'All caught up!'}
            </p>
            {unreadCount > 0 && (
              <button
                onClick={markAllAsRead}
                className="text-sm text-green-600 hover:text-green-700 font-medium"
              >
                Mark all as read
              </button>
            )}
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm mb-6">
          <div className="flex border-b border-gray-200">
            <button
              onClick={() => setFilter('all')}
              className={`flex-1 px-6 py-4 text-center font-medium transition-colors ${
                filter === 'all'
                  ? 'text-green-600 border-b-2 border-green-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              All ({notifications.length})
            </button>
            <button
              onClick={() => setFilter('unread')}
              className={`flex-1 px-6 py-4 text-center font-medium transition-colors ${
                filter === 'unread'
                  ? 'text-green-600 border-b-2 border-green-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Unread ({unreadCount})
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="space-y-2">
          {filteredNotifications.length > 0 ? (
            filteredNotifications.map((notification) => (
              <div
                key={notification.id}
                onClick={() => handleNotificationClick(notification)}
                className={`bg-white rounded-lg shadow-sm p-4 cursor-pointer transition-all hover:shadow-md ${
                  !notification.isRead ? 'border-l-4 border-green-500' : ''
                }`}
              >
                <div className="flex items-start gap-4">
                  {/* Icon */}
                  <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
                    !notification.isRead ? 'bg-green-50' : 'bg-gray-50'
                  }`}>
                    {getIcon(notification.type)}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <h3 className={`text-sm font-semibold mb-1 ${
                          !notification.isRead ? 'text-gray-900' : 'text-gray-700'
                        }`}>
                          {notification.title}
                        </h3>
                        <p className="text-sm text-gray-600 mb-2">
                          {notification.message}
                        </p>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-gray-500">
                            {notification.user}
                          </span>
                          <span className="text-xs text-gray-400">•</span>
                          <span className="text-xs text-gray-500">
                            {formatTimestamp(notification.timestamp)}
                          </span>
                        </div>
                      </div>

                      {/* Delete button */}
                      <button
                        onClick={(e) => deleteNotification(notification.id, e)}
                        className="flex-shrink-0 p-1 text-gray-400 hover:text-gray-600 transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="bg-white rounded-lg shadow-sm p-12 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Bell className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No notifications</h3>
              <p className="text-gray-600">
                {filter === 'unread' 
                  ? "You're all caught up! No unread notifications."
                  : "You don't have any notifications yet."}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}