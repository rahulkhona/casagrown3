import React, { useState, useEffect } from 'react';
import { Search, Plus, Filter, Heart, Flag, Share2, ShoppingCart, MessageCircle, ThumbsUp, Star, UserPlus, UserCheck, Users, Sparkles, Send, X, Calendar } from 'lucide-react';
import ChatInterface from './ChatInterface';
import AddressInput from './AddressInput';

interface User {
  id: string;
  name: string;
  email: string;
  photo?: string;
  points: number;
  communities: string[];
  roles: string[];
}

interface MainFeedProps {
  user: User;
  onCreatePost: () => void;
  onCreateDelegatePost?: () => void;
  onViewPost: (postId: string) => void;
  onBuyPoints?: () => void;
  introPost?: {
    message: string;
    media?: string;
    mediaType?: 'image' | 'video';
    gardenProduce: string[];
  };
}

interface Post {
  id: string;
  type: 'sell' | 'buy' | 'service-request' | 'service-offer' | 'advice' | 'show-and-tell';
  authorId: string;
  authorName: string;
  authorPhoto?: string;
  authorRating?: number;
  authorTotalReviews?: number;
  community: string;
  category: string;
  title: string;
  description: string;
  price?: number;
  unit?: string;
  imageUrl?: string;
  createdAt: Date;
  likes: number;
  comments: number;
}

// Mock posts data
const mockPosts: Post[] = [
  {
    id: '3',
    type: 'sell',
    authorId: '4',
    authorName: 'David Martinez',
    authorRating: 4.9,
    authorTotalReviews: 23,
    community: 'Lincoln High School Community',
    category: 'Equipment',
    title: 'Premium Garden Tool Set',
    description: 'Professional grade garden tool set including spade, hoe, rake, and pruning shears. Barely used, excellent condition. Perfect for serious gardeners!',
    price: 150,
    unit: 'set',
    imageUrl: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYXJkZW4lMjB0b29scyUyMHNldHxlbnwxfHx8fDE3Njk0OTQ0OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
    likes: 15,
    comments: 6
  },
  {
    id: '1',
    type: 'sell',
    authorId: '2',
    authorName: 'Sarah Johnson',
    authorRating: 5.0,
    authorTotalReviews: 47,
    community: 'Lincoln High School Community',
    category: 'Vegetables',
    title: 'Fresh Organic Tomatoes',
    description: 'Just harvested! 5 lbs of fresh organic heirloom tomatoes from my backyard garden.',
    price: 50,
    unit: 'lb',
    imageUrl: 'https://images.unsplash.com/photo-1645931413394-01bd95d294ca?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGdhcmRlbiUyMHZlZ2V0YWJsZXMlMjB0b21hdG9lc3xlbnwxfHx8fDE3Njk0OTQ0OTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    likes: 12,
    comments: 5
  },
  {
    id: '2',
    type: 'buy',
    authorId: '3',
    authorName: 'Michael Chen',
    authorRating: 4.7,
    authorTotalReviews: 15,
    community: 'Washington High School Community',
    category: 'Fruits',
    title: 'Looking for Fresh Strawberries',
    description: 'Anyone have fresh strawberries available? Need about 2-3 lbs for a family gathering this weekend.',
    imageUrl: 'https://images.unsplash.com/photo-1629905707362-03cf1a9f6e2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHBpY2tlZCUyMGZydWl0cyUyMGJhc2tldHxlbnwxfHx8fDE3Njk0OTQ0OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
    likes: 8,
    comments: 3
  },
  {
    id: '4',
    type: 'service-offer',
    authorId: '5',
    authorName: 'Jessica Martinez',
    authorRating: 4.8,
    authorTotalReviews: 31,
    community: 'Lincoln High School Community',
    category: 'Lawn Care',
    title: 'Teen Available for Lawn Mowing',
    description: 'Hi neighbors! I\'m a high school student offering lawn mowing services on weekends. Experienced and reliable!',
    price: 30,
    unit: 'service',
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    likes: 15,
    comments: 7
  },
  {
    id: '5',
    type: 'advice',
    authorId: '6',
    authorName: 'David Williams',
    community: 'Roosevelt High School Community',
    category: 'Gardening Tips',
    title: 'Best Time to Plant Tomatoes?',
    description: 'New to gardening! When is the best time to plant tomatoes in our area? Any tips for first-timers?',
    imageUrl: 'https://images.unsplash.com/photo-1629997391037-c3b5210b5d35?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWNreWFyZCUyMHZlZ2V0YWJsZSUyMGdhcmRlbnxlbnwxfHx8fDE3Njk0OTQ0OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    likes: 23,
    comments: 18
  },
  {
    id: '6',
    type: 'service-request',
    authorId: '7',
    authorName: 'Emily Davis',
    authorRating: 4.6,
    authorTotalReviews: 12,
    community: 'Lincoln High School Community',
    category: 'Harvesting',
    title: 'Need Help Harvesting Apples',
    description: 'My apple tree has more fruit than I can handle! Looking for someone to help harvest. You can keep some apples!',
    price: 40,
    unit: 'hour',
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    likes: 19,
    comments: 12
  },
  {
    id: '7',
    type: 'show-and-tell',
    authorId: '8',
    authorName: 'Amanda Rodriguez',
    community: 'Lincoln High School Community',
    category: 'Garden Stories',
    title: 'My First Harvest Success!',
    description: 'After months of learning and trying, I finally harvested my first homegrown cucumbers! They taste so much better than store-bought. Feeling proud and grateful to this community for all the advice!',
    imageUrl: 'https://images.unsplash.com/photo-1568584711271-8e0b0f5d8c8c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGN1Y3VtYmVycyUyMGhhcnZlc3R8ZW58MXx8fHwxNjk5NDk0NDkyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
    likes: 35,
    comments: 14
  }
];

// Mock comments data
const mockComments: { [key: string]: Array<{ id: string; authorName: string; text: string; timestamp: Date }> } = {
  '4': [
    { id: 'c1', authorName: 'Maria Garcia', text: 'Late March to early April is perfect! Make sure the soil is warm enough.', timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000) },
    { id: 'c2', authorName: 'Tom Anderson', text: 'I always wait until after the last frost. Also, add some compost to the soil!', timestamp: new Date(Date.now() - 20 * 60 * 60 * 1000) },
    { id: 'c3', authorName: 'Lisa Chen', text: 'Pro tip: plant them deep and give them plenty of sun!', timestamp: new Date(Date.now() - 18 * 60 * 60 * 1000) }
  ],
  '5': [
    { id: 'c4', authorName: 'John Smith', text: 'I can help! When do you need assistance?', timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000) },
    { id: 'c5', authorName: 'Rachel Kim', text: 'This sounds great! I love fresh apples.', timestamp: new Date(Date.now() - 1.5 * 24 * 60 * 60 * 1000) }
  ]
};

export default function MainFeed({ user, onCreatePost, onCreateDelegatePost, onViewPost, onBuyPoints, introPost }: MainFeedProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'sell' | 'buy' | 'service-request' | 'service-offer' | 'advice' | 'show-and-tell'>('all');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedChat, setSelectedChat] = useState<string | null>(null);
  const [followingUsers, setFollowingUsers] = useState<Set<string>>(new Set(['2', '4', '5', '8'])); // Mock following data
  const [expandedPostId, setExpandedPostId] = useState<string | null>(null);
  const [commentInputs, setCommentInputs] = useState<{ [key: string]: string }>({});
  const [showFlagModal, setShowFlagModal] = useState(false);
  const [flagPostId, setFlagPostId] = useState<string | null>(null);
  const [flagReason, setFlagReason] = useState('');
  const [flagCategory, setFlagCategory] = useState('');
  const [dismissedWelcomeBanner, setDismissedWelcomeBanner] = useState(false);

  // Drop-off request modal states
  const [showDropoffModal, setShowDropoffModal] = useState(false);
  const [selectedPostForDropoff, setSelectedPostForDropoff] = useState<Post | null>(null);
  const [dropoffQuantity, setDropoffQuantity] = useState('');
  const [dropoffAddress, setDropoffAddress] = useState('');
  const [dropoffLatestDate, setDropoffLatestDate] = useState('');
  const [dropoffInstructions, setDropoffInstructions] = useState('');
  const [showChatFromDropoff, setShowChatFromDropoff] = useState(false);
  const [showBuyPointsModal, setShowBuyPointsModal] = useState(false);
  const [showInlineChat, setShowInlineChat] = useState(false);
  const [inlineChatMessage, setInlineChatMessage] = useState('');
  const [inlineChatMessages, setInlineChatMessages] = useState<Array<{
    id: string;
    senderId: string;
    senderName: string;
    message: string;
    timestamp: Date;
  }>>([]);

  // Debug: Check if introPost is received
  console.log('MainFeed - introPost:', introPost);

  // Check if we should restore the drop-off modal after returning from buy points
  useEffect(() => {
    const shouldRestore = sessionStorage.getItem('shouldRestoreDropoffModal');
    const pendingRequest = sessionStorage.getItem('pendingDropoffRequest');
    
    if (shouldRestore === 'true' && pendingRequest) {
      try {
        const request = JSON.parse(pendingRequest);
        
        // Find the post by ID
        const post = mockPosts.find(p => p.id === request.postId);
        
        if (post) {
          // Restore modal state
          setSelectedPostForDropoff(post);
          setDropoffQuantity(request.quantity);
          setDropoffAddress(request.address);
          setDropoffLatestDate(request.latestDate);
          setDropoffInstructions(request.instructions);
          setShowInlineChat(request.showInlineChat);
          setShowDropoffModal(true);
        }
        
        // Clear the flags
        sessionStorage.removeItem('shouldRestoreDropoffModal');
        sessionStorage.removeItem('pendingDropoffRequest');
      } catch (error) {
        console.error('Error restoring drop-off modal:', error);
        sessionStorage.removeItem('shouldRestoreDropoffModal');
        sessionStorage.removeItem('pendingDropoffRequest');
      }
    }
  }, []); // Run only on mount

  // Create intro post if it exists
  const introPostItem: Post | null = introPost ? {
    id: 'intro-post',
    type: 'show-and-tell',
    authorId: user.id,
    authorName: user.name,
    authorPhoto: user.photo,
    community: user.communities[0] || 'Your Community',
    category: 'Introduction',
    title: '👋 Just joined the community!',
    description: introPost.message + (introPost.gardenProduce.length > 0 ? `\n\n🌱 I grow: ${introPost.gardenProduce.join(', ')}` : ''),
    imageUrl: introPost.media,
    createdAt: new Date(),
    likes: 0,
    comments: 0
  } : null;

  console.log('MainFeed - introPostItem:', introPostItem);

  const toggleFollow = (userId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setFollowingUsers(prev => {
      const newSet = new Set(prev);
      if (newSet.has(userId)) {
        newSet.delete(userId);
      } else {
        newSet.add(userId);
      }
      return newSet;
    });
  };

  const postTypeColors = {
    sell: 'bg-green-100 text-green-700',
    buy: 'bg-blue-100 text-blue-700',
    'service-request': 'bg-purple-100 text-purple-700',
    'service-offer': 'bg-orange-100 text-orange-700',
    advice: 'bg-yellow-100 text-yellow-700',
    'show-and-tell': 'bg-pink-100 text-pink-700'
  };

  const postTypeLabels = {
    sell: 'For Sale',
    buy: 'Wanted',
    'service-request': 'Service Needed',
    'service-offer': 'Service Offered',
    advice: 'Advice',
    'show-and-tell': 'Show and Tell'
  };

  const getTimeAgo = (date: Date) => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    if (seconds < 60) return 'just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  };

  const filteredPosts = mockPosts.filter(post => {
    if (selectedFilter !== 'all' && post.type !== selectedFilter) return false;
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        post.title.toLowerCase().includes(query) ||
        post.description.toLowerCase().includes(query) ||
        post.category.toLowerCase().includes(query) ||
        post.authorName.toLowerCase().includes(query)
      );
    }
    return true;
  });

  // Combine intro post with filtered posts - intro post always first
  const allPosts = introPostItem ? [introPostItem, ...filteredPosts] : filteredPosts;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        {/* Search and Filter Bar */}
        <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
          <div className="flex flex-col sm:flex-row gap-3">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search posts, categories, or keywords..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>

            {/* Filter Button */}
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center justify-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <Filter className="w-5 h-5 text-gray-600" />
              <span className="hidden sm:inline">Filter</span>
            </button>

            {/* Create Post Button */}
            <button
              onClick={onCreatePost}
              className="flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              <Plus className="w-5 h-5" />
              <span>Create Post</span>
            </button>

            {/* Post as Delegate Button (only if enabled) */}
            {onCreateDelegatePost && (
              <button
                onClick={onCreateDelegatePost}
                className="flex items-center justify-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                <Users className="w-5 h-5" />
                <span className="hidden sm:inline">Post as Delegate</span>
                <span className="sm:hidden">Delegate</span>
              </button>
            )}
          </div>

          {/* Filter Options */}
          {showFilters && (
            <div className="mt-4 pt-4 border-t border-gray-200">
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setSelectedFilter('all')}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    selectedFilter === 'all'
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  All Posts
                </button>
                <button
                  onClick={() => setSelectedFilter('sell')}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    selectedFilter === 'sell'
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  For Sale
                </button>
                <button
                  onClick={() => setSelectedFilter('buy')}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    selectedFilter === 'buy'
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Wanted
                </button>
                <button
                  onClick={() => setSelectedFilter('service-offer')}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    selectedFilter === 'service-offer'
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Services
                </button>
                <button
                  onClick={() => setSelectedFilter('advice')}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    selectedFilter === 'advice'
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Advice
                </button>
                <button
                  onClick={() => setSelectedFilter('show-and-tell')}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    selectedFilter === 'show-and-tell'
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Show and Tell
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Posts Feed */}
        <div className="space-y-4">
          {allPosts.length === 0 ? (
            <div className="bg-white rounded-lg shadow-sm p-12 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No posts found</h3>
              <p className="text-gray-600 mb-6">Try adjusting your search or filters</p>
              <button
                onClick={onCreatePost}
                className="inline-flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                <Plus className="w-5 h-5" />
                Create First Post
              </button>
            </div>
          ) : (
            allPosts.map((post, index) => (
              <React.Fragment key={post.id}>
                <div className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                  {/* Post Header */}
                  <div className="p-4 border-b border-gray-100">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        {post.authorPhoto ? (
                          <img src={post.authorPhoto} alt={post.authorName} className="w-10 h-10 rounded-full object-cover" />
                        ) : (
                          <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center text-white font-semibold">
                            {post.authorName.charAt(0)}
                          </div>
                        )}
                        <div>
                          <div className="font-semibold text-gray-900">{post.authorName}</div>
                          {post.authorRating && post.authorTotalReviews && (
                            <div className="flex items-center gap-1">
                              <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                              <span className="text-xs font-medium text-gray-900">{post.authorRating.toFixed(1)}</span>
                              <span className="text-xs text-gray-500">({post.authorTotalReviews} reviews)</span>
                            </div>
                          )}
                          <div className="text-sm text-gray-500">
                            {post.community} · {getTimeAgo(post.createdAt)}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${postTypeColors[post.type]}`}>
                          {postTypeLabels[post.type]}
                        </span>
                        {post.authorId !== user.id && (
                          <button
                            onClick={(e) => toggleFollow(post.authorId, e)}
                            className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                              followingUsers.has(post.authorId)
                                ? 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                : 'bg-green-600 text-white hover:bg-green-700'
                            }`}
                          >
                            {followingUsers.has(post.authorId) ? (
                              <>
                                <UserCheck className="w-3 h-3" />
                                <span>Following</span>
                              </>
                            ) : (
                              <>
                                <UserPlus className="w-3 h-3" />
                                <span>Follow</span>
                              </>
                            )}
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Post Content */}
                  <button
                    onClick={() => onViewPost(post.id)}
                    className="w-full text-left hover:bg-gray-50 transition-colors"
                  >
                    {post.imageUrl && (
                      <div className="aspect-video w-full overflow-hidden">
                        <img src={post.imageUrl} alt={post.title} className="w-full h-full object-cover" />
                      </div>
                    )}
                    <div className="p-4">
                      <h3 className="font-semibold text-gray-900 mb-1">{post.title}</h3>
                      <p className="text-sm text-gray-600 mb-2">{post.description}</p>
                      <div className="flex items-center gap-4 text-sm">
                        <span className="text-gray-500">{post.category}</span>
                        {post.price && (
                          <>
                            <span className="text-gray-300">·</span>
                            <span className="font-semibold text-green-600">{post.price} points</span>
                          </>
                        )}
                      </div>
                    </div>
                  </button>

                  {/* Post Actions */}
                  <div className="px-4 py-3 border-t border-gray-100 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <button className="flex items-center gap-2 text-gray-600 hover:text-green-600 transition-colors">
                        <Heart className="w-5 h-5" />
                        <span className="text-sm font-medium">{post.likes}</span>
                      </button>
                      {post.type === 'sell' ? (
                        <button
                          onClick={() => {
                            setSelectedPostForDropoff(post);
                            setShowDropoffModal(true);
                          }}
                          className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                        >
                          <ShoppingCart className="w-5 h-5" />
                          <span className="text-sm">Buy</span>
                        </button>
                      ) : post.type === 'buy' ? (
                        <button
                          onClick={() => onViewPost(post.id)}
                          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                        >
                          <ThumbsUp className="w-5 h-5" />
                          <span className="text-sm">Offer</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => {
                            if (post.type === 'service-offer' || post.type === 'service-request') {
                              setSelectedChat(post.id);
                            }
                          }}
                          className="flex items-center gap-2 text-gray-600 hover:text-green-600 transition-colors"
                        >
                          <MessageCircle className="w-5 h-5" />
                          {post.type !== 'service-offer' && post.type !== 'service-request' && (
                            <span className="text-sm font-medium">{post.comments}</span>
                          )}
                        </button>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <button className="p-2 text-gray-600 hover:text-green-600 hover:bg-gray-50 rounded-full transition-colors">
                        <Share2 className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => {
                          setShowFlagModal(true);
                          setFlagPostId(post.id);
                        }}
                        className="p-2 text-gray-600 hover:text-red-600 hover:bg-gray-50 rounded-full transition-colors"
                      >
                        <Flag className="w-5 h-5" />
                      </button>
                    </div>
                  </div>

                  {/* Inline Comments Section */}
                  {expandedPostId === post.id && post.type !== 'service-offer' && (
                    <div className="border-t border-gray-100 bg-gray-50">
                      {/* Existing Comments */}
                      {mockComments[post.id] && mockComments[post.id].length > 0 && (
                        <div className="px-4 py-3 space-y-3 max-h-96 overflow-y-auto">
                          {mockComments[post.id].map((comment) => (
                            <div key={comment.id} className="flex gap-3">
                              <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-white text-sm font-semibold flex-shrink-0">
                                {comment.authorName.charAt(0)}
                              </div>
                              <div className="flex-1 bg-white rounded-lg p-3">
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="font-semibold text-sm text-gray-900">{comment.authorName}</span>
                                  <span className="text-xs text-gray-500">{getTimeAgo(comment.timestamp)}</span>
                                </div>
                                <p className="text-sm text-gray-700">{comment.text}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Comment Input */}
                      <div className="px-4 py-3 border-t border-gray-200">
                        <div className="flex gap-3">
                          <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center text-white text-sm font-semibold flex-shrink-0">
                            {user.name.charAt(0)}
                          </div>
                          <div className="flex-1 flex gap-2">
                            <input
                              type="text"
                              value={commentInputs[post.id] || ''}
                              onChange={(e) => setCommentInputs({ ...commentInputs, [post.id]: e.target.value })}
                              placeholder="Write a comment..."
                              className="flex-1 px-3 py-2 border border-gray-300 rounded-full text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent"
                              onKeyPress={(e) => {
                                if (e.key === 'Enter' && commentInputs[post.id]?.trim()) {
                                  // In real app, would save comment here
                                  setCommentInputs({ ...commentInputs, [post.id]: '' });
                                }
                              }}
                            />
                            <button
                              onClick={() => {
                                if (commentInputs[post.id]?.trim()) {
                                  // In real app, would save comment here
                                  setCommentInputs({ ...commentInputs, [post.id]: '' });
                                }
                              }}
                              className="px-4 py-2 bg-green-600 text-white rounded-full text-sm font-medium hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                              disabled={!commentInputs[post.id]?.trim()}
                            >
                              Post
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Welcome Banner - shown only after first post if it's the intro post and user is the author */}
                {index === 0 && introPostItem && post.id === 'intro-post' && !dismissedWelcomeBanner && (
                  <div className="bg-gradient-to-r from-green-600 via-green-500 to-green-600 rounded-2xl p-6 shadow-lg relative">
                    <button
                      onClick={() => setDismissedWelcomeBanner(true)}
                      className="absolute top-4 right-4 p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-full transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0">
                        <Sparkles className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1 pr-8">
                        <h3 className="text-xl font-bold text-white mb-2">🎉 Welcome to CasaGrown!</h3>
                        <p className="text-green-50 mb-4">
                          Your introduction post is now live! Let's grow the community together.
                        </p>
                        <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 mb-4">
                          <div className="flex items-center gap-2 mb-2">
                            <Users className="w-5 h-5 text-white" />
                            <h4 className="font-semibold text-white">Invite Your Neighbors</h4>
                          </div>
                          <p className="text-sm text-green-50 mb-3">
                            The more neighbors join, the more fresh produce and services you'll find! Plus, you'll earn bonus points when they complete their first transaction.
                          </p>
                          <button
                            onClick={() => {
                              const inviteButton = document.querySelector('[title="Invite Friends"]') as HTMLButtonElement;
                              if (inviteButton) {
                                inviteButton.click();
                              }
                            }}
                            className="flex items-center gap-2 px-4 py-2 bg-white text-green-600 rounded-lg hover:bg-green-50 transition-all font-medium shadow-sm"
                          >
                            <Send className="w-4 h-4" />
                            <span>Invite Friends Now</span>
                          </button>
                        </div>
                        <p className="text-xs text-green-100">
                          💡 Tip: The more neighbors you invite, the more vibrant your community becomes
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </React.Fragment>
            ))
          )}
        </div>

        {/* Floating Create Button (Mobile) */}
        <button
          onClick={onCreatePost}
          className="md:hidden fixed bottom-6 right-6 w-14 h-14 bg-green-600 text-white rounded-full shadow-lg hover:bg-green-700 transition-colors flex items-center justify-center z-40"
        >
          <Plus className="w-6 h-6" />
        </button>
      </div>

      {/* Chat Interface for Service Offers */}
      {selectedChat && (() => {
        const selectedPost = mockPosts.find(post => post.id === selectedChat);
        if (!selectedPost) return null;
        
        return (
          <ChatInterface
            currentUserId={user.id}
            currentUserName={user.name}
            otherUserId={selectedChat}
            otherUserName={selectedPost.authorName || 'Unknown'}
            postTitle={selectedPost.title || 'Service Offer'}
            postType={selectedPost.type || 'service-offer'}
            onClose={() => setSelectedChat(null)}
            isCurrentUserSeller={user.id === selectedPost.authorId}
            savedAddress={'123 Garden Lane, Springfield'}
            postData={{
              id: selectedPost.id,
              authorName: selectedPost.authorName,
              authorRating: selectedPost.authorRating,
              authorTotalReviews: selectedPost.authorTotalReviews,
              category: selectedPost.category,
              description: selectedPost.description,
              price: selectedPost.price,
              unit: selectedPost.unit,
              imageUrl: selectedPost.imageUrl
            }}
          />
        );
      })()}

      {/* Flag Modal */}
      {showFlagModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Report Post</h3>
            <p className="text-gray-600 mb-4">
              Please provide a reason for reporting this post.
            </p>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Category <span className="text-red-500">*</span>
                </label>
                <select
                  value={flagCategory}
                  onChange={(e) => setFlagCategory(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white"
                >
                  <option value="">Select a category</option>
                  <option value="spam">Spam</option>
                  <option value="inappropriate">Inappropriate Content</option>
                  <option value="fraud">Fraudulent Activity</option>
                  <option value="other">Other</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Reason <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={flagReason}
                  onChange={(e) => setFlagReason(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
                  placeholder="Enter your reason for reporting this post"
                  rows={4}
                />
              </div>
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowFlagModal(false);
                  setFlagReason('');
                  setFlagCategory('');
                  setFlagPostId(null);
                }}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (!flagCategory || !flagReason.trim()) {
                    return;
                  }
                  setShowFlagModal(false);
                  setFlagReason('');
                  setFlagCategory('');
                  setFlagPostId(null);
                }}
                disabled={!flagCategory || !flagReason.trim()}
                className="flex-1 px-4 py-2 bg-red-600 text-white font-medium rounded-lg hover:bg-red-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
              >
                Submit Report
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Drop-Off Request Modal */}
      {showDropoffModal && selectedPostForDropoff && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 my-8">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Drop-Off Delivery Request</h3>
            <p className="text-gray-600 mb-4">
              Complete the details below to request drop-off delivery from {selectedPostForDropoff.authorName}.
            </p>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Quantity <span className="text-red-500">*</span>
                </label>
                <div className="flex gap-2 items-start">
                  <div className="flex-1">
                    <input
                      type="number"
                      value={dropoffQuantity}
                      onChange={(e) => setDropoffQuantity(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      placeholder="Enter quantity"
                      min="0.1"
                      step="0.1"
                    />
                  </div>
                  {selectedPostForDropoff.unit && (
                    <div className="flex items-center px-3 py-2 bg-gray-100 border border-gray-300 rounded-lg text-gray-700 font-medium whitespace-nowrap">
                      {selectedPostForDropoff.unit}
                    </div>
                  )}
                </div>
                {selectedPostForDropoff.price && (
                  <p className="text-xs text-gray-600 mt-2">
                    <span className="font-medium">Price per {selectedPostForDropoff.unit || 'unit'}:</span> {selectedPostForDropoff.price} points
                  </p>
                )}
                {selectedPostForDropoff.price && dropoffQuantity && (
                  <p className="text-xs text-gray-500 mt-1">
                    Total: {Math.round(parseFloat(dropoffQuantity) * selectedPostForDropoff.price)} points
                  </p>
                )}
              </div>

              {/* Drop-off Address */}
              <div>
                <AddressInput
                  value={dropoffAddress}
                  onChange={setDropoffAddress}
                  label="Drop-off Address"
                  placeholder="Enter your full delivery address"
                  required={true}
                  multiline={true}
                  rows={3}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Include apartment/unit number if applicable
                </p>
              </div>

              {/* Latest Drop-off Date */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Latest Drop-Off Date <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  value={dropoffLatestDate}
                  onChange={(e) => setDropoffLatestDate(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  min={new Date().toISOString().split('T')[0]}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Latest date by which you need the items delivered
                </p>
              </div>

              {/* Drop-off Instructions */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Drop-off Instructions
                </label>
                <textarea
                  value={dropoffInstructions}
                  onChange={(e) => setDropoffInstructions(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
                  placeholder="e.g., Leave at the front porch, ring the doorbell when you drop off"
                  rows={3}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Optional: Add specific instructions for the seller
                </p>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <p className="text-sm text-blue-800">
                  <strong>Note:</strong> The seller will take a geotagged photo when dropping off your items.
                </p>
              </div>

              {/* Points Balance Summary */}
              <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">Your current balance:</span>
                    <span className="font-semibold text-gray-900">{user.points} points</span>
                  </div>
                  {dropoffQuantity && parseFloat(dropoffQuantity) > 0 && selectedPostForDropoff.price && (
                    <>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-700">Request total:</span>
                        <span className="font-semibold text-gray-900">
                          {Math.round(parseFloat(dropoffQuantity) * selectedPostForDropoff.price)} points
                        </span>
                      </div>
                      <div className="pt-2 border-t border-gray-300">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-semibold text-gray-900">Balance after:</span>
                          <span className={`font-bold text-lg ${
                            user.points >= Math.round(parseFloat(dropoffQuantity) * selectedPostForDropoff.price)
                              ? 'text-green-600'
                              : 'text-red-600'
                          }`}>
                            {user.points - Math.round(parseFloat(dropoffQuantity) * selectedPostForDropoff.price)} points
                          </span>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* Insufficient Points Warning */}
              {dropoffQuantity && parseFloat(dropoffQuantity) > 0 && selectedPostForDropoff.price &&
                user.points < Math.round(parseFloat(dropoffQuantity) * selectedPostForDropoff.price) && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0">
                      <svg className="w-5 h-5 text-red-600" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-sm font-semibold text-red-900 mb-1">Insufficient Points</h4>
                      <p className="text-sm text-red-800 mb-3">
                        You need {Math.round(parseFloat(dropoffQuantity) * selectedPostForDropoff.price) - user.points} more points to complete this purchase.
                      </p>
                      <button
                        onClick={() => {
                          // Store the drop-off state in sessionStorage to restore when returning
                          sessionStorage.setItem('pendingDropoffRequest', JSON.stringify({
                            postId: selectedPostForDropoff.id,
                            quantity: dropoffQuantity,
                            address: dropoffAddress,
                            latestDate: dropoffLatestDate,
                            instructions: dropoffInstructions,
                            showInlineChat: showInlineChat
                          }));
                          // Navigate to purchase view
                          if (onBuyPoints) {
                            onBuyPoints();
                          }
                        }}
                        className="text-sm font-medium text-red-700 hover:text-red-900 underline"
                      >
                        Buy Points Now
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Chat Section - Inline */}
            {showInlineChat && (
              <ChatInterface
                currentUserId={user.id}
                currentUserName={user.name}
                otherUserId={selectedPostForDropoff.authorId}
                otherUserName={selectedPostForDropoff.authorName}
                postTitle={selectedPostForDropoff.title}
                postType={selectedPostForDropoff.type}
                onClose={() => setShowInlineChat(false)}
                isCurrentUserSeller={false}
                postData={{
                  id: selectedPostForDropoff.id,
                  authorName: selectedPostForDropoff.authorName,
                  authorRating: selectedPostForDropoff.authorRating,
                  authorTotalReviews: selectedPostForDropoff.authorTotalReviews,
                  category: selectedPostForDropoff.category,
                  description: selectedPostForDropoff.description,
                  price: selectedPostForDropoff.price,
                  unit: selectedPostForDropoff.unit,
                  imageUrl: selectedPostForDropoff.imageUrl
                }}
                dropoffFormData={{
                  quantity: dropoffQuantity,
                  address: dropoffAddress,
                  latestDate: dropoffLatestDate,
                  instructions: dropoffInstructions
                }}
              />
            )}

            <div className="space-y-3">
              {/* Chat with Seller Button - Toggle inline chat */}
              {!showInlineChat && (
                <button
                  onClick={() => setShowInlineChat(true)}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 border-2 border-green-600 text-green-700 font-medium rounded-lg hover:bg-green-50 transition-colors"
                >
                  <MessageCircle className="w-5 h-5" />
                  Chat with Seller
                </button>
              )}

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowDropoffModal(false);
                    setDropoffQuantity('');
                    setDropoffAddress('');
                    setDropoffLatestDate('');
                    setDropoffInstructions('');
                    setSelectedPostForDropoff(null);
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    // Validate
                    if (!dropoffQuantity || !dropoffAddress || !dropoffLatestDate) {
                      alert('Please fill in all required fields');
                      return;
                    }
                    
                    // Check if sufficient points
                    if (selectedPostForDropoff.price && user.points < Math.round(parseFloat(dropoffQuantity) * selectedPostForDropoff.price)) {
                      alert('Insufficient points. Please buy more points or reduce quantity.');
                      return;
                    }
                    
                    // Submit (in real app, would create order)
                    setShowDropoffModal(false);
                    setDropoffQuantity('');
                    setDropoffAddress('');
                    setDropoffLatestDate('');
                    setDropoffInstructions('');
                    setSelectedPostForDropoff(null);
                    setShowInlineChat(false);
                  }}
                  disabled={dropoffQuantity && parseFloat(dropoffQuantity) > 0 && selectedPostForDropoff.price && user.points < Math.round(parseFloat(dropoffQuantity) * selectedPostForDropoff.price)}
                  className="flex-1 px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  Submit Request
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}