import React, { useState } from 'react';
import { Search, X, Send, MessageCircle } from 'lucide-react';
import ChatInterface from './ChatInterface';
import { BuyPointsModal } from './BuyPointsModal';

interface User {
  id: string;
  name: string;
  email: string;
  points: number;
  communityId: string;
  onboarded: boolean;
}

interface ChatsProps {
  user: User;
}

interface Conversation {
  id: string;
  postId: string;
  postTitle: string;
  postType: 'sell' | 'buy' | 'service-request' | 'service-offer' | 'advice' | 'show-and-tell';
  postCategory: string;
  postDescription: string;
  postPrice?: number;
  postUnit?: string;
  postImageUrl?: string;
  postAuthorId: string;
  postAuthorName: string;
  postAuthorRating?: number;
  postAuthorTotalReviews?: number;
  otherUserId: string;
  otherUserName: string;
  otherUserPhoto?: string;
  lastMessage: string;
  lastMessageTime: Date;
  unreadCount: number;
  // For buy form conversations, include drop-off form details
  dropoffFormData?: {
    quantity: string;
    address: string;
    latestDate: string;
    instructions?: string;
  };
}

export default function Chats({ user }: ChatsProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [showBuyPointsModal, setShowBuyPointsModal] = useState(false);

  // Buy Points Modal State
  const [pointsToBuy, setPointsToBuy] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'creditCard' | 'ach' | null>(null);
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [billingZip, setBillingZip] = useState('');
  const [routingNumber, setRoutingNumber] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountType, setAccountType] = useState<'checking' | 'savings'>('checking');
  const [errorMessage, setErrorMessage] = useState('');

  // Mock conversations data - starting with seller's view of buyer-initiated chats
  const mockConversations: Conversation[] = [
    // Conversation 1: USER IS THE SELLER - buyer contacted them about their tomatoes post
    {
      id: 'conv-1',
      postId: '1',
      postTitle: 'Fresh Organic Tomatoes',
      postType: 'sell',
      postCategory: 'Vegetables',
      postDescription: 'Just harvested! 5 lbs of fresh organic heirloom tomatoes from my backyard garden.',
      postPrice: 50,
      postUnit: 'lb',
      postImageUrl: 'https://images.unsplash.com/photo-1645931413394-01bd95d294ca?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGdhcmRlbiUyMHZlZ2V0YWJsZXMlMjB0b21hdG9lc3xlbnwxfHx8fDE3Njk0OTQ0OTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      postAuthorId: user.id, // CURRENT USER IS THE SELLER
      postAuthorName: user.name,
      postAuthorRating: 5.0,
      postAuthorTotalReviews: 47,
      otherUserId: '3',
      otherUserName: 'Michael Chen',
      lastMessage: 'Hi! I\'d like to purchase 3 lbs. Can you deliver to my address?',
      lastMessageTime: new Date(Date.now() - 15 * 60 * 1000), // 15 minutes ago
      unreadCount: 2,
      dropoffFormData: {
        quantity: '3',
        address: '456 Oak Street, Apt 2B, Springfield, CA 90210',
        latestDate: '2026-02-05',
        instructions: 'Leave at the front door.'
      }
    },
    // Conversation 2: USER IS THE BUYER - they contacted David about his tools post
    {
      id: 'conv-2',
      postId: '3',
      postTitle: 'Premium Garden Tool Set',
      postType: 'sell',
      postCategory: 'Equipment',
      postDescription: 'Professional grade garden tool set including spade, hoe, rake, and pruning shears. Barely used, excellent condition.',
      postPrice: 150,
      postUnit: 'set',
      postImageUrl: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYXJkZW4lMjB0b29scyUyMHNldHxlbnwxfHx8fDE3Njk0OTQ0OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      postAuthorId: '4', // DAVID IS THE SELLER
      postAuthorName: 'David Martinez',
      postAuthorRating: 4.9,
      postAuthorTotalReviews: 23,
      otherUserId: user.id, // CURRENT USER IS THE BUYER
      otherUserName: user.name,
      lastMessage: 'Yes, it\'s still available! When would you like to pick it up?',
      lastMessageTime: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      unreadCount: 1
      // No dropoffFormData - buyer hasn't submitted request yet (editable form view)
    },
    // Conversation 3: SERVICE OFFER - User is offering lawn mowing
    {
      id: 'conv-3',
      postId: '5',
      postTitle: 'Professional Lawn Mowing Service',
      postType: 'service-offer',
      postCategory: 'Lawn Care',
      postDescription: 'Offering professional lawn mowing services. I have commercial-grade equipment and 5 years of experience.',
      postPrice: 30,
      postUnit: 'hour',
      postImageUrl: 'https://images.unsplash.com/photo-1558904541-efa843a96f01?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXduJTIwbW93aW5nJTIwc2VydmljZXxlbnwxfHx8fDE3Njk0OTQ0OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      postAuthorId: user.id, // CURRENT USER IS THE SERVICE PROVIDER
      postAuthorName: user.name,
      postAuthorRating: 4.8,
      postAuthorTotalReviews: 15,
      otherUserId: '5',
      otherUserName: 'Jennifer Wilson',
      lastMessage: 'Hi! I\'m interested in your lawn mowing service. Are you available next Saturday?',
      lastMessageTime: new Date(Date.now() - 45 * 60 * 1000), // 45 minutes ago
      unreadCount: 1
    },
    // Conversation 5: BUYER VIEW - User has submitted an order for Sarah's strawberries
    {
      id: 'conv-5',
      postId: '8',
      postTitle: 'Fresh Strawberries',
      postType: 'sell',
      postCategory: 'Fruits',
      postDescription: 'Sweet and juicy strawberries picked this morning. Perfect for jams or fresh eating!',
      postPrice: 40,
      postUnit: 'lb',
      postImageUrl: 'https://images.unsplash.com/photo-1464965911861-746a04b4bca6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHN0cmF3YmVycmllc3xlbnwxfHx8fDE3Njk0OTQ0OTN8MA&ixlib=rb-4.1.0&q=80&w=1080',
      postAuthorId: '6',
      postAuthorName: 'Sarah Thompson',
      postAuthorRating: 4.9,
      postAuthorTotalReviews: 31,
      otherUserId: user.id, // CURRENT USER IS THE BUYER
      otherUserName: user.name,
      lastMessage: '📦 Drop-off request submitted! Waiting for seller confirmation...',
      lastMessageTime: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
      unreadCount: 0,
      dropoffFormData: {
        quantity: '2',
        address: '123 Garden Lane, Springfield, CA 90210',
        latestDate: '2026-02-03',
        instructions: 'Please ring doorbell upon delivery.'
      }
    },
    // Conversation 4: SERVICE REQUEST - User is requesting garden consultation
    {
      id: 'conv-4',
      postId: '7',
      postTitle: 'Garden Design Consultation Needed',
      postType: 'service-request',
      postCategory: 'Consultation',
      postDescription: 'Looking for someone experienced in garden design to help plan my new vegetable garden layout.',
      postPrice: 40,
      postUnit: 'hour',
      postImageUrl: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYXJkZW4lMjBkZXNpZ24lMjBjb25zdWx0YXRpb258ZW58MXx8fHwxNzY5NDk0NDkyfDA&ixlib=rb-4.1.0&q=80&w=1080',
      postAuthorId: user.id, // CURRENT USER IS REQUESTING SERVICE
      postAuthorName: user.name,
      otherUserId: '6',
      otherUserName: 'Robert Green',
      lastMessage: 'I\'d be happy to help! I have 10 years of experience in garden design.',
      lastMessageTime: new Date(Date.now() - 3 * 60 * 60 * 1000), // 3 hours ago
      unreadCount: 0
    }
  ];

  const getTimeAgo = (date: Date) => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    if (seconds < 60) return 'just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  };

  // Filter conversations based on search
  const filteredConversations = mockConversations.filter(conv => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      conv.postTitle.toLowerCase().includes(query) ||
      conv.otherUserName.toLowerCase().includes(query) ||
      conv.postCategory.toLowerCase().includes(query) ||
      conv.lastMessage.toLowerCase().includes(query)
    );
  });

  // If a conversation is selected, show the chat interface
  if (selectedConversation) {
    // Determine if current user is the seller (post author)
    const isCurrentUserSeller = user.id === selectedConversation.postAuthorId;

    return (
      <div className="min-h-screen bg-gray-50">
        <ChatInterface
          currentUserId={user.id}
          currentUserName={user.name}
          otherUserId={selectedConversation.otherUserId}
          otherUserName={selectedConversation.otherUserName}
          postTitle={selectedConversation.postTitle}
          postType={selectedConversation.postType}
          onClose={() => setSelectedConversation(null)}
          isCurrentUserSeller={isCurrentUserSeller}
          postData={{
            id: selectedConversation.postId,
            authorName: selectedConversation.postAuthorName,
            authorRating: selectedConversation.postAuthorRating,
            authorTotalReviews: selectedConversation.postAuthorTotalReviews,
            category: selectedConversation.postCategory,
            description: selectedConversation.postDescription,
            price: selectedConversation.postPrice,
            unit: selectedConversation.postUnit,
            imageUrl: selectedConversation.postImageUrl
          }}
          dropoffFormData={selectedConversation.dropoffFormData}
          currentUserPoints={user.points}
          onBuyPoints={() => {
            setShowBuyPointsModal(true);
          }}
        />
        {showBuyPointsModal && (
          <BuyPointsModal
            userPoints={user.points}
            pointsToBuy={pointsToBuy}
            setPointsToBuy={setPointsToBuy}
            paymentMethod={paymentMethod}
            setPaymentMethod={setPaymentMethod}
            cardNumber={cardNumber}
            setCardNumber={setCardNumber}
            cardExpiry={cardExpiry}
            setCardExpiry={setCardExpiry}
            cardCvv={cardCvv}
            setCardCvv={setCardCvv}
            billingZip={billingZip}
            setBillingZip={setBillingZip}
            routingNumber={routingNumber}
            setRoutingNumber={setRoutingNumber}
            accountNumber={accountNumber}
            setAccountNumber={setAccountNumber}
            accountType={accountType}
            setAccountType={setAccountType}
            errorMessage={errorMessage}
            onCancel={() => setShowBuyPointsModal(false)}
            onPurchase={() => {
              // In a real app, this would process the purchase
              alert('Points purchased successfully!');
              setShowBuyPointsModal(false);
              // Reset form
              setPointsToBuy('');
              setPaymentMethod(null);
              setCardNumber('');
              setCardExpiry('');
              setCardCvv('');
              setBillingZip('');
              setRoutingNumber('');
              setAccountNumber('');
              setErrorMessage('');
            }}
          />
        )}
      </div>
    );
  }

  // Show conversations list
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Chats</h1>
          <p className="text-gray-600">Conversations about your posts and requests</p>
        </div>

        {/* Search Bar */}
        <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search conversations..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Conversations List */}
        <div className="space-y-3">
          {filteredConversations.length === 0 ? (
            <div className="bg-white rounded-lg shadow-sm p-12 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MessageCircle className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No conversations found</h3>
              <p className="text-gray-600">
                {searchQuery ? 'Try adjusting your search' : 'Your conversations will appear here'}
              </p>
            </div>
          ) : (
            filteredConversations.map((conv) => (
              <button
                key={conv.id}
                onClick={() => setSelectedConversation(conv)}
                className="w-full bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-shadow text-left"
              >
                <div className="flex gap-4">
                  {/* Other User Avatar */}
                  <div className="flex-shrink-0">
                    {conv.otherUserPhoto ? (
                      <img
                        src={conv.otherUserPhoto}
                        alt={conv.otherUserName}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                    ) : (
                      <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center text-white font-semibold">
                        {conv.otherUserName.charAt(0)}
                      </div>
                    )}
                  </div>

                  {/* Conversation Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-1">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-gray-900 truncate">
                          {conv.otherUserName}
                        </h3>
                        <p className="text-sm text-gray-600 truncate">
                          Re: {conv.postTitle}
                        </p>
                      </div>
                      <div className="flex-shrink-0 ml-2 text-right">
                        <span className="text-xs text-gray-500">
                          {getTimeAgo(conv.lastMessageTime)}
                        </span>
                        {conv.unreadCount > 0 && (
                          <div className="mt-1 inline-flex items-center justify-center w-5 h-5 bg-green-600 text-white text-xs font-bold rounded-full">
                            {conv.unreadCount}
                          </div>
                        )}
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 truncate">
                      {conv.lastMessage}
                    </p>
                    
                    {/* Show drop-off details if present */}
                    {conv.dropoffFormData && (
                      <div className="mt-2 text-xs text-gray-500 bg-gray-50 rounded p-2">
                        <span className="font-medium">Drop-off request:</span> {conv.dropoffFormData.quantity} {conv.postUnit}
                        {conv.postPrice && ` • ${Math.round(parseFloat(conv.dropoffFormData.quantity) * conv.postPrice)} points`}
                        <p className="mt-1">{conv.dropoffFormData.instructions}</p>
                      </div>
                    )}
                  </div>
                </div>
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
}