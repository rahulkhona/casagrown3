import React, { useState, useEffect } from 'react';
import { ArrowLeft, Upload, Image as ImageIcon, Video, MapPin, Calendar, Clock, DollarSign, ChevronDown, X, Search, Plus, Trash2, Share2, Copy, Check } from 'lucide-react';
import { copyToClipboard } from '../utils/clipboard';

interface User {
  id: string;
  name: string;
  email: string;
  communities: string[];
}

interface DelegatedUser {
  id: string;
  name: string;
  community: string;
}

interface CreatePostProps {
  user: User;
  onBack: () => void;
  onComplete: () => void;
  initialPostType?: PostType;
  delegatedUsers?: DelegatedUser[]; // Users who delegated to current user
  postingAsDelegateFor?: string | null; // Pre-selected delegated user ID
}

type PostType = 'sell' | 'buy' | 'service-request' | 'service-offer' | 'advice' | 'show-and-tell';

interface DateAvailability {
  date: string;
  timeRange: string;
}

interface FulfillmentOptions {
  canDropoff: boolean;
  allowPickup: boolean;
  canMeetNearby: boolean;
  allowSelfHarvest: boolean;
  dropoffDates: string[]; // Only dates, no time
  pickupAvailability: DateAvailability[];
  meetNearbyAvailability: DateAvailability[];
  selfHarvestAvailability: DateAvailability[];
}

export default function CreatePost({ user, onBack, onComplete, initialPostType, delegatedUsers = [], postingAsDelegateFor = null }: CreatePostProps) {
  const [postType, setPostType] = useState<PostType | null>(initialPostType || null);
  const [selectedCommunity, setSelectedCommunity] = useState<string>('');
  const [selectedCommunities, setSelectedCommunities] = useState<string[]>([]); // For multi-community selection
  const [showCommunityDropdown, setShowCommunityDropdown] = useState(false);
  const [communitySearchQuery, setCommunitySearchQuery] = useState('');
  const [postingOnBehalfOf, setPostingOnBehalfOf] = useState<string>(postingAsDelegateFor || ''); // ID of user being posted for
  const [showBehalfOfDropdown, setShowBehalfOfDropdown] = useState(false);
  const [category, setCategory] = useState('');
  const [customCategory, setCustomCategory] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [quantity, setQuantity] = useState('');
  const [unit, setUnit] = useState('');
  const [mediaType, setMediaType] = useState<'photo' | 'video' | null>(null);
  const [pickupDays, setPickupDays] = useState<string[]>([]);
  const [pickupTime, setPickupTime] = useState('');
  const [allowsDropoff, setAllowsDropoff] = useState(false); // For sell posts
  const [fulfillmentPreference, setFulfillmentPreference] = useState<'pickup' | 'dropoff' | 'either'>('either'); // For buy posts
  
  // For sell posts - fulfillment options
  const [fulfillmentOptions, setFulfillmentOptions] = useState<FulfillmentOptions>({
    canDropoff: true, // Default to dropoff as first choice
    allowPickup: false,
    canMeetNearby: false,
    allowSelfHarvest: false,
    dropoffDates: [],
    pickupAvailability: [],
    meetNearbyAvailability: [],
    selfHarvestAvailability: []
  });

  // For buy posts
  const [buyFulfillmentOptions, setBuyFulfillmentOptions] = useState<FulfillmentOptions>({
    canDropoff: true, // Default to dropoff as first choice
    allowPickup: false,
    canMeetNearby: false,
    allowSelfHarvest: false,
    dropoffDates: [],
    pickupAvailability: [],
    meetNearbyAvailability: [],
    selfHarvestAvailability: []
  });
  const [latestDropoffDate, setLatestDropoffDate] = useState('');
  const [latestDropoffTime, setLatestDropoffTime] = useState('');
  
  // Validation errors
  const [errors, setErrors] = useState<{[key: string]: string}>({});
  
  // Share modal
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareLink, setShareLink] = useState('');
  const [linkCopied, setLinkCopied] = useState(false);

  const categories = {
    sell: ['Vegetables', 'Fruits', 'Herbs', 'Seeds', 'Gardening Equipment', 'Pots & Planters', 'Soil & Compost'],
    buy: ['Vegetables', 'Fruits', 'Herbs', 'Seeds', 'Gardening Equipment', 'Pots & Planters', 'Soil & Compost'],
    'service-request': ['Harvesting', 'Lawn Mowing', 'Weeding', 'Planting', 'Garden Design', 'Other'],
    'service-offer': ['Harvesting', 'Lawn Mowing', 'Weeding', 'Planting', 'Garden Design', 'Other'],
    advice: ['Growing Tips', 'Pest Control', 'Soil Health', 'Composting', 'General Question'],
    'show-and-tell': ['Garden Stories', 'Discoveries', 'Tips', 'Experiences']
  };

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  // Set default community to "All Communities" for show-and-tell posts
  useEffect(() => {
    if (postType === 'show-and-tell' && !selectedCommunity) {
      setSelectedCommunity('All Communities');
    }
  }, [postType]);

  // Auto-set community when posting on behalf of someone
  useEffect(() => {
    if (postingOnBehalfOf && delegatedUsers.length > 0) {
      const delegatedUser = delegatedUsers.find(u => u.id === postingOnBehalfOf);
      if (delegatedUser) {
        setSelectedCommunity(delegatedUser.community);
        // Force drop-off only for delegated posts
        setFulfillmentOptions({
          canDropoff: true,
          allowPickup: false,
          canMeetNearby: false,
          allowSelfHarvest: false,
          dropoffDates: [],
          pickupAvailability: [],
          meetNearbyAvailability: [],
          selfHarvestAvailability: []
        });
      }
    }
  }, [postingOnBehalfOf, delegatedUsers]);


  const handleDayToggle = (day: string) => {
    setPickupDays(prev =>
      prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day]
    );
  };

  // Helper functions for fulfillment options
  const addDateToOption = (option: keyof FulfillmentOptions, date: string, timeRange: string = '') => {
    setFulfillmentOptions(prev => {
      if (option === 'canDropoff') {
        return {
          ...prev,
          dropoffDates: [...prev.dropoffDates, date]
        };
      }
      
      // Map the option to the correct availability key
      let availabilityKey: keyof FulfillmentOptions;
      if (option === 'allowPickup') {
        availabilityKey = 'pickupAvailability';
      } else if (option === 'canMeetNearby') {
        availabilityKey = 'meetNearbyAvailability';
      } else if (option === 'allowSelfHarvest') {
        availabilityKey = 'selfHarvestAvailability';
      } else {
        availabilityKey = option;
      }
      
      const availability = prev[availabilityKey] as DateAvailability[];
      return {
        ...prev,
        [availabilityKey]: [...availability, { date, timeRange }]
      };
    });
  };

  const removeDateFromOption = (option: keyof FulfillmentOptions, index: number) => {
    setFulfillmentOptions(prev => {
      if (option === 'canDropoff') {
        return {
          ...prev,
          dropoffDates: prev.dropoffDates.filter((_, i) => i !== index)
        };
      }
      
      // Map the option to the correct availability key
      let availabilityKey: keyof FulfillmentOptions;
      if (option === 'allowPickup') {
        availabilityKey = 'pickupAvailability';
      } else if (option === 'canMeetNearby') {
        availabilityKey = 'meetNearbyAvailability';
      } else if (option === 'allowSelfHarvest') {
        availabilityKey = 'selfHarvestAvailability';
      } else {
        availabilityKey = option;
      }
      
      const availability = prev[availabilityKey] as DateAvailability[];
      return {
        ...prev,
        [availabilityKey]: availability.filter((_, i) => i !== index)
      };
    });
  };

  const updateTimeRange = (option: keyof FulfillmentOptions, index: number, timeRange: string) => {
    setFulfillmentOptions(prev => {
      // Map the option to the correct availability key
      let availabilityKey: keyof FulfillmentOptions;
      if (option === 'allowPickup') {
        availabilityKey = 'pickupAvailability';
      } else if (option === 'canMeetNearby') {
        availabilityKey = 'meetNearbyAvailability';
      } else if (option === 'allowSelfHarvest') {
        availabilityKey = 'selfHarvestAvailability';
      } else {
        availabilityKey = option;
      }
      
      const availability = [...(prev[availabilityKey] as DateAvailability[])];
      availability[index] = { ...availability[index], timeRange };
      return {
        ...prev,
        [availabilityKey]: availability
      };
    });
  };

  const updateDate = (option: keyof FulfillmentOptions, index: number, date: string) => {
    setFulfillmentOptions(prev => {
      if (option === 'canDropoff') {
        const dates = [...prev.dropoffDates];
        dates[index] = date;
        return {
          ...prev,
          dropoffDates: dates
        };
      }
      
      // Map the option to the correct availability key
      let availabilityKey: keyof FulfillmentOptions;
      if (option === 'allowPickup') {
        availabilityKey = 'pickupAvailability';
      } else if (option === 'canMeetNearby') {
        availabilityKey = 'meetNearbyAvailability';
      } else if (option === 'allowSelfHarvest') {
        availabilityKey = 'selfHarvestAvailability';
      } else {
        availabilityKey = option;
      }
      
      const availability = [...(prev[availabilityKey] as DateAvailability[])];
      availability[index] = { ...availability[index], date };
      return {
        ...prev,
        [availabilityKey]: availability
      };
    });
  };

  const handleSubmit = () => {
    // Clear previous errors
    const newErrors: {[key: string]: string} = {};
    
    // Validate fields - community is optional for show-and-tell posts
    if (!selectedCommunity && postType !== 'show-and-tell') {
      newErrors.communities = 'Please select a community';
    }
    
    if (!category) {
      newErrors.category = 'Please select a category';
    }
    
    // Title is only required for posts that show the title field
    if (postType !== 'service-request' && postType !== 'service-offer' && !title.trim()) {
      newErrors.title = 'Title is required';
    }
    
    if (!description.trim()) {
      newErrors.description = 'Description is required';
    }
    
    // Validate price for sell posts only
    if (postType === 'sell' && !price) {
      newErrors.price = 'Price is required';
    }
    
    // Validate quantity for sell posts
    if (postType === 'sell' && !quantity) {
      newErrors.quantity = 'Quantity is required';
    }
    
    // Check if there are any errors
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      // Scroll to first error
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    
    // Clear errors and show share modal
    setErrors({});
    
    // Generate a mock share link
    const postId = Math.random().toString(36).substring(7);
    const link = `${window.location.origin}/post/${postId}`;
    setShareLink(link);
    setShowShareModal(true);
  };
  
  const handleCopyLink = async () => {
    const success = await copyToClipboard(shareLink);
    if (success) {
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2000);
    }
  };
  
  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Check out this post on CasaGrown',
          text: title || 'Check out this post on CasaGrown',
          url: shareLink,
        });
      } catch (error) {
        // User cancelled or error occurred
        console.log('Share failed:', error);
      }
    }
  };
  
  const handleShareComplete = () => {
    setShowShareModal(false);
    onComplete();
  };

  if (!postType) {
    return (
      <div className="min-h-screen bg-gray-50 py-8 px-4">
        <div className="max-w-2xl mx-auto">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Feed</span>
          </button>

          <div className="bg-white rounded-2xl shadow-sm p-6 sm:p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Create a Post</h2>
            <p className="text-gray-600 mb-8">What would you like to share with your community?</p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <button
                onClick={() => setPostType('sell')}
                className="p-6 border-2 border-gray-200 rounded-xl hover:border-green-500 hover:bg-green-50 transition-all text-left group"
              >
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4 group-hover:bg-green-200">
                  <DollarSign className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-1">Looking to Sell</h3>
                <p className="text-sm text-gray-600">List produce or gardening items for sale</p>
              </button>

              <button
                onClick={() => setPostType('buy')}
                className="p-6 border-2 border-gray-200 rounded-xl hover:border-blue-500 hover:bg-blue-50 transition-all text-left group"
              >
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4 group-hover:bg-blue-200">
                  <svg className="w-6 h-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
                <h3 className="font-semibold text-gray-900 mb-1">Looking to Buy</h3>
                <p className="text-sm text-gray-600">Post what you're looking to purchase</p>
              </button>

              <button
                onClick={() => setPostType('service-request')}
                className="p-6 border-2 border-gray-200 rounded-xl hover:border-purple-500 hover:bg-purple-50 transition-all text-left group"
              >
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-4 group-hover:bg-purple-200">
                  <svg className="w-6 h-6 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                </div>
                <h3 className="font-semibold text-gray-900 mb-1">Need a Service</h3>
                <p className="text-sm text-gray-600">Request gardening help from neighbors</p>
              </button>

              <button
                onClick={() => setPostType('service-offer')}
                className="p-6 border-2 border-gray-200 rounded-xl hover:border-orange-500 hover:bg-orange-50 transition-all text-left group"
              >
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mb-4 group-hover:bg-orange-200">
                  <svg className="w-6 h-6 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" />
                  </svg>
                </div>
                <h3 className="font-semibold text-gray-900 mb-1">Offer a Service</h3>
                <p className="text-sm text-gray-600">Offer your gardening services</p>
              </button>

              <button
                onClick={() => setPostType('advice')}
                className="p-6 border-2 border-gray-200 rounded-xl hover:border-yellow-500 hover:bg-yellow-50 transition-all text-left group"
              >
                <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mb-4 group-hover:bg-yellow-200">
                  <svg className="w-6 h-6 text-yellow-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="font-semibold text-gray-900 mb-1">Ask for Advice</h3>
                <p className="text-sm text-gray-600">Get gardening tips and advice from the community</p>
              </button>

              <button
                onClick={() => setPostType('show-and-tell')}
                className="p-6 border-2 border-gray-200 rounded-xl hover:border-teal-500 hover:bg-teal-50 transition-all text-left group"
              >
                <div className="w-12 h-12 bg-teal-100 rounded-full flex items-center justify-center mb-4 group-hover:bg-teal-200">
                  <svg className="w-6 h-6 text-teal-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </div>
                <h3 className="font-semibold text-gray-900 mb-1">Show & Tell</h3>
                <p className="text-sm text-gray-600">Share your garden stories and discoveries</p>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <button
          onClick={() => setPostType(null)}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Change Post Type</span>
        </button>

        <div className="bg-white rounded-2xl shadow-sm p-6 sm:p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            {postType === 'sell' && 'Sell Produce or Items'}
            {postType === 'buy' && 'What Are You Looking For?'}
            {postType === 'service-request' && 'Request a Service'}
            {postType === 'service-offer' && 'Offer Your Service'}
            {postType === 'advice' && 'Ask for Advice'}
            {postType === 'show-and-tell' && 'Share Your Stories'}
          </h2>

          <div className="space-y-6">
            {/* Posting on Behalf Of - First field for sell posts when user has delegated users */}
            {postType === 'sell' && delegatedUsers.length > 0 && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Posting On Behalf Of {!postingAsDelegateFor && <span className="text-gray-500 text-xs ml-2">(Optional)</span>}
                </label>
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setShowBehalfOfDropdown(!showBehalfOfDropdown)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent flex items-center justify-between hover:bg-gray-50 transition-colors"
                  >
                    <span className={postingOnBehalfOf ? 'text-gray-900' : 'text-gray-500'}>
                      {postingOnBehalfOf 
                        ? delegatedUsers.find(u => u.id === postingOnBehalfOf)?.name 
                        : (postingAsDelegateFor ? 'Select a user' : 'Posting for myself')}
                    </span>
                    <ChevronDown className={`w-4 h-4 text-gray-500 transition-transform ${showBehalfOfDropdown ? 'rotate-180' : ''}`} />
                  </button>
                  {showBehalfOfDropdown && (
                    <>
                      <div
                        className="fixed inset-0 z-10"
                        onClick={() => setShowBehalfOfDropdown(false)}
                      />
                      <div className="absolute z-20 w-full bg-white border border-gray-300 rounded-lg shadow-lg mt-1 max-h-60 overflow-y-auto">
                        {/* Only show "Post for Myself" if NOT coming from delegate button */}
                        {!postingAsDelegateFor && (
                          <button
                            onClick={() => {
                              setPostingOnBehalfOf('');
                              setShowBehalfOfDropdown(false);
                            }}
                            className={`w-full text-left p-3 cursor-pointer hover:bg-gray-50 border-b border-gray-200 ${
                              !postingOnBehalfOf ? 'bg-green-50 text-green-700 font-medium' : 'text-gray-900'
                            }`}
                          >
                            <span className="text-sm">Posting for myself</span>
                          </button>
                        )}
                        {delegatedUsers.map(delegatedUser => (
                          <button
                            key={delegatedUser.id}
                            onClick={() => {
                              setPostingOnBehalfOf(delegatedUser.id);
                              setShowBehalfOfDropdown(false);
                            }}
                            className={`w-full text-left p-3 cursor-pointer hover:bg-gray-50 ${
                              postingOnBehalfOf === delegatedUser.id ? 'bg-green-50 text-green-700 font-medium' : 'text-gray-900'
                            }`}
                          >
                            <div className="flex flex-col">
                              <span className="text-sm font-medium">{delegatedUser.name}</span>
                              <span className="text-xs text-gray-500">{delegatedUser.community}</span>
                            </div>
                          </button>
                        ))}
                      </div>
                    </>
                  )}
                </div>
                {postingOnBehalfOf && (
                  <p className="text-xs text-blue-600 mt-2">
                    You are posting on behalf of {delegatedUsers.find(u => u.id === postingOnBehalfOf)?.name} in their community. 
                    They will be notified when the sale completes. You can only offer drop-off as the fulfillment option.
                  </p>
                )}
              </div>
            )}

            {/* Community Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Post to Community {postType !== 'show-and-tell' && <span className="text-red-500">*</span>}
                {postType === 'show-and-tell' && <span className="text-gray-500 text-xs ml-2">(Optional - leave blank to share with all communities)</span>}
                {postingOnBehalfOf && <span className="text-blue-600 text-xs ml-2">(Auto-selected based on delegation)</span>}
              </label>
              {errors.communities && (
                <p className="text-red-500 text-sm mb-2">{errors.communities}</p>
              )}

              {/* Dropdown */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => !postingOnBehalfOf && setShowCommunityDropdown(!showCommunityDropdown)}
                  disabled={!!postingOnBehalfOf}
                  className={`w-full px-4 py-3 border ${errors.communities ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent flex items-center justify-between transition-colors ${
                    postingOnBehalfOf ? 'bg-gray-100 cursor-not-allowed' : 'hover:bg-gray-50'
                  }`}
                >
                  <span className={selectedCommunity ? 'text-gray-900' : 'text-gray-500'}>
                    {selectedCommunity === 'All Communities' ? 'All Communities' : selectedCommunity || (postType === 'show-and-tell' ? 'All Communities' : 'Select a community')}
                  </span>
                  {!postingOnBehalfOf && <ChevronDown className={`w-4 h-4 text-gray-500 transition-transform ${showCommunityDropdown ? 'rotate-180' : ''}`} />}
                </button>
                {showCommunityDropdown && !postingOnBehalfOf && (
                  <>
                    {/* Backdrop to close dropdown */}
                    <div
                      className="fixed inset-0 z-10"
                      onClick={() => setShowCommunityDropdown(false)}
                    />
                    {/* Dropdown menu */}
                    <div className="absolute z-20 w-full bg-white border border-gray-300 rounded-lg shadow-lg mt-1 max-h-60 overflow-hidden">
                      {/* Search Input */}
                      <div className="p-2 border-b border-gray-200 bg-gray-50">
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                          <input
                            type="text"
                            value={communitySearchQuery}
                            onChange={(e) => setCommunitySearchQuery(e.target.value)}
                            onClick={(e) => e.stopPropagation()}
                            className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-sm"
                            placeholder="Search communities..."
                            autoFocus
                          />
                        </div>
                      </div>
                      
                      {/* Communities List */}
                      <div className="max-h-48 overflow-y-auto p-2">
                        {user.communities.length === 0 ? (
                          <div className="text-center py-4 text-gray-500 text-sm">
                            No communities available
                          </div>
                        ) : (
                          (() => {
                            const filteredCommunities = user.communities.filter((community) =>
                              community.toLowerCase().includes(communitySearchQuery.toLowerCase())
                            );
                            
                            if (filteredCommunities.length === 0) {
                              return (
                                <div className="text-center py-4 text-gray-500 text-sm">
                                  No communities match "{communitySearchQuery}"
                                </div>
                              );
                            }
                            
                            return (
                              <>
                                {/* Show "All Communities" option for show-and-tell posts */}
                                {postType === 'show-and-tell' && (
                                  <button
                                    onClick={() => {
                                      setSelectedCommunity('All Communities');
                                      setShowCommunityDropdown(false);
                                      setErrors(prev => ({ ...prev, communities: '' }));
                                    }}
                                    className={`w-full text-left p-3 cursor-pointer hover:bg-gray-50 rounded transition-colors border-b border-gray-200 mb-2 ${
                                      selectedCommunity === 'All Communities' ? 'bg-green-50 text-green-700 font-medium' : 'text-gray-900'
                                    }`}
                                  >
                                    <div className="flex items-center gap-2">
                                      <span className="text-sm font-medium">🌍 All Communities</span>
                                    </div>
                                    <span className="text-xs text-gray-500">Share with everyone</span>
                                  </button>
                                )}
                                {filteredCommunities.map((community) => (
                                  <button
                                    key={community}
                                    onClick={() => {
                                      setSelectedCommunity(community);
                                      setShowCommunityDropdown(false);
                                      setErrors(prev => ({ ...prev, communities: '' }));
                                    }}
                                    className={`w-full text-left p-3 cursor-pointer hover:bg-gray-50 rounded transition-colors ${
                                      selectedCommunity === community ? 'bg-green-50 text-green-700 font-medium' : 'text-gray-900'
                                    }`}
                                  >
                                    <span className="text-sm">{community}</span>
                                  </button>
                                ))}
                              </>
                            );
                          })()
                        )}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Category */}
            <div>
              <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-2">
                Category <span className="text-red-500">*</span>
              </label>
              {errors.category && (
                <p className="text-red-500 text-sm mb-2">{errors.category}</p>
              )}
              <select
                id="category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className={`w-full px-4 py-3 border ${errors.category ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent`}
                required
              >
                <option value="">Select a category</option>
                {categories[postType].map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
                {postType === 'show-and-tell' && <option value="custom">Create Custom Category...</option>}
              </select>
              {postType === 'show-and-tell' && category === 'custom' && (
                <input
                  type="text"
                  value={customCategory}
                  onChange={(e) => setCustomCategory(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent mt-2"
                  placeholder="Enter custom category"
                  required
                />
              )}
            </div>

            {/* Title/Name */}
            {postType !== 'service-request' && postType !== 'service-offer' && (
              <div>
                <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-2">
                  {postType === 'advice' ? 'Question Title' : postType === 'show-and-tell' ? 'Title' : 'Product/Service Name'} <span className="text-red-500">*</span>
                </label>
                {errors.title && (
                  <p className="text-red-500 text-sm mb-2">{errors.title}</p>
                )}
                <input
                  type="text"
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className={`w-full px-4 py-3 border ${errors.title ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent`}
                  placeholder={postType === 'advice' ? 'e.g., Best time to plant tomatoes?' : 'e.g., Fresh Organic Tomatoes'}
                  required
                />
              </div>
            )}

            {/* Description */}
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
                Description <span className="text-red-500">*</span>
              </label>
              {errors.description && (
                <p className="text-red-500 text-sm mb-2">{errors.description}</p>
              )}
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
                className={`w-full px-4 py-3 border ${errors.description ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none`}
                placeholder="Provide details..."
                required
              />
            </div>

            {/* Quantity and Unit (for sell posts) */}
            {postType === 'sell' && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="quantity" className="block text-sm font-medium text-gray-700 mb-2">
                    Available Quantity <span className="text-red-500">*</span>
                  </label>
                  {errors.quantity && (
                    <p className="text-red-500 text-sm mb-2">{errors.quantity}</p>
                  )}
                  <input
                    type="number"
                    id="quantity"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    className={`w-full px-4 py-3 border ${errors.quantity ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent`}
                    placeholder="0"
                    min="0"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="unit" className="block text-sm font-medium text-gray-700 mb-2">
                    Unit <span className="text-red-500">*</span>
                  </label>
                  <select
                    id="unit"
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    required
                  >
                    <option value="">Select unit</option>
                    <option value="piece">piece</option>
                    <option value="dozen">dozen</option>
                    <option value="lb">lb</option>
                    <option value="box">box</option>
                  </select>
                </div>
              </div>
            )}

            {/* Price (for sell and service posts) */}
            {postType === 'sell' && (
              <div>
                <label htmlFor="price" className="block text-sm font-medium text-gray-700 mb-2">
                  {unit 
                    ? `Price per ${unit} (in points)` 
                    : 'Price (in points)'} <span className="text-red-500">*</span>
                </label>
                {errors.price && (
                  <p className="text-red-500 text-sm mb-2">{errors.price}</p>
                )}
                <div className="relative">
                  <input
                    type="number"
                    id="price"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className={`w-full px-4 py-3 border ${errors.price ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent`}
                    placeholder="0"
                    min="0"
                    required
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 text-sm">points</span>
                </div>
                
                {/* Platform Fee Notice */}
                <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-start gap-2">
                    <svg className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <div className="text-xs text-blue-900">
                      <span className="font-semibold">Platform Fee:</span> A 10% fee (inclusive of credit card processing) will be applied to buyer payments. This helps us maintain the platform and keep CasaGrown running smoothly for everyone.
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Media Upload */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Add Photo or Video
              </label>
              <div className="flex gap-3 mb-3">
                <button
                  onClick={() => setMediaType('photo')}
                  className={`flex-1 p-4 border-2 rounded-lg transition-all ${
                    mediaType === 'photo' ? 'border-green-500 bg-green-50' : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <ImageIcon className={`w-6 h-6 mx-auto mb-2 ${mediaType === 'photo' ? 'text-green-600' : 'text-gray-600'}`} />
                  <div className="text-sm font-medium text-gray-900">Photo</div>
                </button>
                <button
                  onClick={() => setMediaType('video')}
                  className={`flex-1 p-4 border-2 rounded-lg transition-all ${
                    mediaType === 'video' ? 'border-green-500 bg-green-50' : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <Video className={`w-6 h-6 mx-auto mb-2 ${mediaType === 'video' ? 'text-green-600' : 'text-gray-600'}`} />
                  <div className="text-sm font-medium text-gray-900">Video</div>
                </button>
              </div>
              {mediaType && (
                <div className="space-y-2">
                  <label className="flex items-center justify-center gap-2 p-4 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-green-500 hover:bg-green-50 transition-all">
                    <Upload className="w-5 h-5 text-gray-600" />
                    <span className="text-sm font-medium text-gray-700">
                      Upload {mediaType === 'photo' ? 'Photo' : 'Video'}
                    </span>
                    <input type="file" accept={mediaType === 'photo' ? 'image/*' : 'video/*'} className="hidden" />
                  </label>
                  <label className="flex items-center justify-center gap-2 p-4 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-green-500 hover:bg-green-50 transition-all">
                    {mediaType === 'photo' ? (
                      <ImageIcon className="w-5 h-5 text-gray-600" />
                    ) : (
                      <Video className="w-5 h-5 text-gray-600" />
                    )}
                    <span className="text-sm font-medium text-gray-700">
                      Take {mediaType === 'photo' ? 'Photo' : 'Video'}
                    </span>
                    <input 
                      type="file" 
                      accept={mediaType === 'photo' ? 'image/*' : 'video/*'} 
                      capture="environment"
                      className="hidden" 
                    />
                  </label>
                </div>
              )}
            </div>

            {/* Fulfillment Options (for sell posts) */}
            {postType === 'sell' && (
              <div className="space-y-4">
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Drop-off Dates <span className="text-red-500">*</span>
                  <span className="block text-xs text-gray-500 font-normal mt-1">Add dates when you can drop off</span>
                </label>

                {/* Drop Off Dates */}
                <div className="border border-gray-300 rounded-lg p-4">
                  <div className="space-y-2">
                    <p className="text-xs text-gray-600 mb-2">Add dates when you can drop off (no time required)</p>
                    {fulfillmentOptions.dropoffDates.map((date, index) => (
                      <div key={index} className="flex gap-2 items-center">
                        <input
                          type="date"
                          value={date}
                          onChange={(e) => updateDate('canDropoff', index, e.target.value)}
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                        <button
                          onClick={() => removeDateFromOption('canDropoff', index)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                    <button
                      onClick={() => {
                        const today = new Date();
                        today.setDate(today.getDate() + fulfillmentOptions.dropoffDates.length + 1);
                        addDateToOption('canDropoff', today.toISOString().split('T')[0]);
                      }}
                      className="flex items-center gap-2 px-3 py-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors text-sm"
                    >
                      <Plus className="w-4 h-4" />
                      Add date
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Fulfillment Options (for buy posts) */}
            {postType === 'buy' && (
              <div className="space-y-4">
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Drop-off Dates <span className="text-red-500">*</span>
                  <span className="block text-xs text-gray-500 font-normal mt-1">Add dates when you can receive dropoffs</span>
                </label>

                {/* Latest Dropoff Date/Time */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                  <label className="block text-sm font-medium text-gray-900 mb-2">
                    Latest Dropoff Date & Time
                  </label>
                  <p className="text-xs text-gray-600 mb-3">When do you need the item delivered by?</p>
                  <div className="grid grid-cols-2 gap-3">
                    <input
                      type="date"
                      value={latestDropoffDate}
                      onChange={(e) => setLatestDropoffDate(e.target.value)}
                      className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                    <input
                      type="time"
                      value={latestDropoffTime}
                      onChange={(e) => setLatestDropoffTime(e.target.value)}
                      className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>
                </div>

                {/* Accept Dropoff Dates */}
                <div className="border border-gray-300 rounded-lg p-4">
                  <div className="space-y-2">
                    <p className="text-xs text-gray-600 mb-2">Add dates when you can receive dropoffs</p>
                    {buyFulfillmentOptions.dropoffDates.map((date, index) => (
                      <div key={index} className="flex gap-2 items-center">
                        <input
                          type="date"
                          value={date}
                          onChange={(e) => {
                            setBuyFulfillmentOptions(prev => {
                              const dates = [...prev.dropoffDates];
                              dates[index] = e.target.value;
                              return { ...prev, dropoffDates: dates };
                            });
                          }}
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                        <button
                          onClick={() => {
                            setBuyFulfillmentOptions(prev => ({
                              ...prev,
                              dropoffDates: prev.dropoffDates.filter((_, i) => i !== index)
                            }));
                          }}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                    <button
                      onClick={() => {
                        const today = new Date();
                        today.setDate(today.getDate() + buyFulfillmentOptions.dropoffDates.length + 1);
                        setBuyFulfillmentOptions(prev => ({
                          ...prev,
                          dropoffDates: [...prev.dropoffDates, today.toISOString().split('T')[0]]
                        }));
                      }}
                      className="flex items-center gap-2 px-3 py-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors text-sm"
                    >
                      <Plus className="w-4 h-4" />
                      Add date
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Submit Buttons */}
            <div className="flex gap-3 pt-4">
              <button
                onClick={onBack}
                className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmit}
                className="flex-1 px-6 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
              >
                Post to Community
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Share Modal */}
      {showShareModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Post Created!</h2>
              <p className="text-gray-600">Share this post with your friends</p>
            </div>
            
            {/* Copy Link */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Post Link
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={shareLink}
                  readOnly
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-sm"
                />
                <button
                  onClick={handleCopyLink}
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
                >
                  {linkCopied ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
            </div>
            
            {/* Share Button */}
            <button
              onClick={handleNativeShare}
              className="w-full px-6 py-3 mb-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
            >
              <Share2 className="w-5 h-5" />
              Share Post
            </button>
            
            {/* Done Button */}
            <button
              onClick={handleShareComplete}
              className="w-full px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  );
}