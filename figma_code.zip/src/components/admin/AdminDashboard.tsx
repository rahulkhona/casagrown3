import React, { useState } from 'react';
import { Settings, Gift, DollarSign, Flag, MapPin, ShoppingBag, ArrowLeft } from 'lucide-react';
import RewardsConfig from './RewardsConfig';
import PlatformFees from './PlatformFees';
import FlaggedPosts from './FlaggedPosts';
import CategoryDenyList from './CategoryDenyList';
import RedemptionStoreAdmin from './RedemptionStoreAdmin';

interface AdminDashboardProps {
  onBack: () => void;
}

type AdminPage = 'overview' | 'rewards' | 'fees' | 'flagged' | 'denylist' | 'store';

export default function AdminDashboard({ onBack }: AdminDashboardProps) {
  const [currentPage, setCurrentPage] = useState<AdminPage>('overview');

  const adminCards = [
    {
      id: 'rewards' as AdminPage,
      title: 'Profile Rewards',
      description: 'Configure points awarded at each profile creation stage',
      icon: Gift,
      color: 'green',
    },
    {
      id: 'fees' as AdminPage,
      title: 'Platform Fees',
      description: 'Set platform charges for sellers in points',
      icon: DollarSign,
      color: 'blue',
    },
    {
      id: 'flagged' as AdminPage,
      title: 'Flagged Posts',
      description: 'Monitor and moderate disputed flagged content',
      icon: Flag,
      color: 'red',
    },
    {
      id: 'denylist' as AdminPage,
      title: 'Category Deny List',
      description: 'Restrict categories by state and zipcode',
      icon: MapPin,
      color: 'purple',
    },
    {
      id: 'store' as AdminPage,
      title: 'Redemption Store',
      description: 'Manage products available for redemption',
      icon: ShoppingBag,
      color: 'orange',
    },
  ];

  if (currentPage === 'rewards') {
    return <RewardsConfig onBack={() => setCurrentPage('overview')} />;
  }

  if (currentPage === 'fees') {
    return <PlatformFees onBack={() => setCurrentPage('overview')} />;
  }

  if (currentPage === 'flagged') {
    return <FlaggedPosts onBack={() => setCurrentPage('overview')} />;
  }

  if (currentPage === 'denylist') {
    return <CategoryDenyList onBack={() => setCurrentPage('overview')} />;
  }

  if (currentPage === 'store') {
    return <RedemptionStoreAdmin onBack={() => setCurrentPage('overview')} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to App</span>
        </button>

        <div className="bg-white rounded-2xl shadow-sm p-6 sm:p-8 mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <Settings className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
              <p className="text-gray-600">Manage platform settings and policies</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {adminCards.map((card) => {
            const Icon = card.icon;
            const colorClasses = {
              green: 'bg-green-100 text-green-600 hover:border-green-500 hover:bg-green-50',
              blue: 'bg-blue-100 text-blue-600 hover:border-blue-500 hover:bg-blue-50',
              red: 'bg-red-100 text-red-600 hover:border-red-500 hover:bg-red-50',
              purple: 'bg-purple-100 text-purple-600 hover:border-purple-500 hover:bg-purple-50',
              orange: 'bg-orange-100 text-orange-600 hover:border-orange-500 hover:bg-orange-50',
            }[card.color];

            return (
              <button
                key={card.id}
                onClick={() => setCurrentPage(card.id)}
                className={`p-6 border-2 border-gray-200 rounded-xl transition-all text-left group ${colorClasses}`}
              >
                <div className={`w-12 h-12 ${card.color === 'green' ? 'bg-green-100' : card.color === 'blue' ? 'bg-blue-100' : card.color === 'red' ? 'bg-red-100' : card.color === 'purple' ? 'bg-purple-100' : 'bg-orange-100'} rounded-full flex items-center justify-center mb-4`}>
                  <Icon className={`w-6 h-6 ${card.color === 'green' ? 'text-green-600' : card.color === 'blue' ? 'text-blue-600' : card.color === 'red' ? 'text-red-600' : card.color === 'purple' ? 'text-purple-600' : 'text-orange-600'}`} />
                </div>
                <h3 className="font-semibold text-gray-900 mb-1">{card.title}</h3>
                <p className="text-sm text-gray-600">{card.description}</p>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
