import React, { useState } from 'react';
import { ArrowLeft, DollarSign, Save, Info, Percent } from 'lucide-react';

interface PlatformFeesProps {
  onBack: () => void;
}

export default function PlatformFees({ onBack }: PlatformFeesProps) {
  const [feeType, setFeeType] = useState<'percentage' | 'fixed'>('percentage');
  const [percentageFee, setPercentageFee] = useState(5);
  const [fixedFee, setFixedFee] = useState(10);
  const [minimumFee, setMinimumFee] = useState(5);
  const [maximumFee, setMaximumFee] = useState(100);
  const [hasChanges, setHasChanges] = useState(false);

  const handleSave = () => {
    // In real app, save to backend
    alert('Platform fee configuration saved successfully!');
    setHasChanges(false);
  };

  const calculateFee = (salePrice: number) => {
    if (feeType === 'percentage') {
      const fee = Math.round((salePrice * percentageFee) / 100);
      if (minimumFee && fee < minimumFee) return minimumFee;
      if (maximumFee && fee > maximumFee) return maximumFee;
      return fee;
    } else {
      return fixedFee;
    }
  };

  const examplePrices = [50, 100, 200, 500, 1000];

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Dashboard</span>
        </button>

        <div className="bg-white rounded-2xl shadow-sm p-6 sm:p-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Platform Fee Configuration</h2>
              <p className="text-gray-600">Set how much the platform charges sellers</p>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6 flex gap-3">
            <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-blue-900">
              <p className="font-medium mb-1">About Platform Fees</p>
              <p>These fees are deducted from the seller's earnings when a transaction is completed. Fees help sustain the platform and maintain the community.</p>
            </div>
          </div>

          <div className="space-y-6 mb-6">
            {/* Fee Type Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Fee Type
              </label>
              <div className="grid grid-cols-2 gap-4">
                <button
                  onClick={() => {
                    setFeeType('percentage');
                    setHasChanges(true);
                  }}
                  className={`p-4 border-2 rounded-lg transition-all ${
                    feeType === 'percentage'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <Percent className={`w-6 h-6 mx-auto mb-2 ${feeType === 'percentage' ? 'text-blue-600' : 'text-gray-600'}`} />
                  <div className="text-sm font-medium text-gray-900">Percentage Fee</div>
                  <div className="text-xs text-gray-600 mt-1">% of sale price</div>
                </button>
                <button
                  onClick={() => {
                    setFeeType('fixed');
                    setHasChanges(true);
                  }}
                  className={`p-4 border-2 rounded-lg transition-all ${
                    feeType === 'fixed'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <DollarSign className={`w-6 h-6 mx-auto mb-2 ${feeType === 'fixed' ? 'text-blue-600' : 'text-gray-600'}`} />
                  <div className="text-sm font-medium text-gray-900">Fixed Fee</div>
                  <div className="text-xs text-gray-600 mt-1">Same for all sales</div>
                </button>
              </div>
            </div>

            {/* Percentage Fee Settings */}
            {feeType === 'percentage' && (
              <>
                <div>
                  <label htmlFor="percentage" className="block text-sm font-medium text-gray-700 mb-2">
                    Percentage Fee
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="number"
                      id="percentage"
                      value={percentageFee}
                      onChange={(e) => {
                        setPercentageFee(parseFloat(e.target.value) || 0);
                        setHasChanges(true);
                      }}
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      min="0"
                      max="100"
                      step="0.1"
                    />
                    <span className="text-gray-600">%</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="min-fee" className="block text-sm font-medium text-gray-700 mb-2">
                      Minimum Fee (optional)
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        id="min-fee"
                        value={minimumFee}
                        onChange={(e) => {
                          setMinimumFee(parseInt(e.target.value) || 0);
                          setHasChanges(true);
                        }}
                        className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        min="0"
                      />
                      <span className="text-sm text-gray-600">pts</span>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="max-fee" className="block text-sm font-medium text-gray-700 mb-2">
                      Maximum Fee (optional)
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        id="max-fee"
                        value={maximumFee}
                        onChange={(e) => {
                          setMaximumFee(parseInt(e.target.value) || 0);
                          setHasChanges(true);
                        }}
                        className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        min="0"
                      />
                      <span className="text-sm text-gray-600">pts</span>
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* Fixed Fee Settings */}
            {feeType === 'fixed' && (
              <div>
                <label htmlFor="fixed-fee" className="block text-sm font-medium text-gray-700 mb-2">
                  Fixed Fee Amount
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    id="fixed-fee"
                    value={fixedFee}
                    onChange={(e) => {
                      setFixedFee(parseInt(e.target.value) || 0);
                      setHasChanges(true);
                    }}
                    className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="0"
                  />
                  <span className="text-gray-600">points</span>
                </div>
              </div>
            )}
          </div>

          {/* Fee Preview */}
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <h3 className="font-semibold text-gray-900 mb-3">Fee Preview</h3>
            <div className="space-y-2">
              {examplePrices.map((price) => {
                const fee = calculateFee(price);
                const sellerReceives = price - fee;
                return (
                  <div key={price} className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Sale: {price} points</span>
                    <div className="flex items-center gap-4">
                      <span className="text-red-600">Fee: {fee} pts</span>
                      <span className="font-medium text-gray-900">Seller gets: {sellerReceives} pts</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="border-t border-gray-200 pt-6">
            <div className="flex justify-end">
              <button
                onClick={handleSave}
                disabled={!hasChanges}
                className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-colors ${
                  hasChanges
                    ? 'bg-blue-600 text-white hover:bg-blue-700'
                    : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                }`}
              >
                <Save className="w-5 h-5" />
                Save Changes
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
