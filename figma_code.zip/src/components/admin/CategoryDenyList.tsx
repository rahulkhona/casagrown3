import React, { useState } from 'react';
import { ArrowLeft, MapPin, Save, Plus, Trash2, Search } from 'lucide-react';

interface CategoryDenyListProps {
  onBack: () => void;
}

interface DenyListRule {
  id: string;
  category: string;
  productName?: string; // Optional specific product name
  postType: string;
  state: string;
  zipCodes: string[];
  reason: string;
  createdDate: string;
}

export default function CategoryDenyList({ onBack }: CategoryDenyListProps) {
  const [rules, setRules] = useState<DenyListRule[]>([
    {
      id: '1',
      category: 'Eggs',
      postType: 'sell',
      state: 'CA',
      zipCodes: ['90001', '90002', '90003'],
      reason: 'State requires commercial license for egg sales',
      createdDate: '2026-01-15',
    },
    {
      id: '2',
      category: 'Dairy',
      productName: 'Raw Milk',
      postType: 'sell',
      state: 'All States',
      zipCodes: [],
      reason: 'Federal regulation prohibits raw milk sales',
      createdDate: '2026-01-10',
    },
    {
      id: '3',
      category: 'Cannabis',
      postType: 'sell',
      state: 'All States',
      zipCodes: [],
      reason: 'Platform policy - prohibited category',
      createdDate: '2026-01-01',
    },
    {
      id: '4',
      category: 'Vegetables',
      productName: 'Wild Mushrooms',
      postType: 'sell',
      state: 'WA',
      zipCodes: [],
      reason: 'State requires certification for wild mushroom sales',
      createdDate: '2026-01-20',
    },
  ]);

  const [showAddForm, setShowAddForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [hasChanges, setHasChanges] = useState(false);

  // Form state
  const [newCategory, setNewCategory] = useState('');
  const [newProductName, setNewProductName] = useState(''); // New field for product name
  const [newPostType, setNewPostType] = useState('sell');
  const [newState, setNewState] = useState('');
  const [newZipCodes, setNewZipCodes] = useState('');
  const [newReason, setNewReason] = useState('');

  // Categories matching CreatePost sell/buy categories
  const categories = [
    'Vegetables', 
    'Fruits', 
    'Herbs', 
    'Seeds', 
    'Gardening Equipment', 
    'Pots & Planters', 
    'Soil & Compost',
    // Additional restricted items not in standard categories
    'Eggs',
    'Dairy',
    'Meat',
    'Raw Milk',
    'Fertilizer',
    'Pesticides',
    'Cannabis',
    'Alcohol',
    'Tobacco'
  ];

  const usStates = [
    'All States', 'AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA',
    'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD', 'MA', 'MI',
    'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ', 'NM', 'NY', 'NC', 'ND',
    'OH', 'OK', 'OR', 'PA', 'RI', 'SC', 'SD', 'TN', 'TX', 'UT', 'VT', 'VA',
    'WA', 'WV', 'WI', 'WY'
  ];

  const postTypes = ['sell', 'buy', 'service-request', 'service-offer'];

  const handleAddRule = () => {
    if (!newCategory || !newState || !newReason) {
      alert('Please fill in all required fields');
      return;
    }

    const zipCodesArray = newZipCodes
      .split(',')
      .map(zip => zip.trim())
      .filter(zip => zip.length > 0);

    const newRule: DenyListRule = {
      id: Date.now().toString(),
      category: newCategory,
      productName: newProductName, // Include product name if provided
      postType: newPostType,
      state: newState,
      zipCodes: zipCodesArray,
      reason: newReason,
      createdDate: new Date().toISOString().split('T')[0],
    };

    setRules(prev => [newRule, ...prev]);
    setShowAddForm(false);
    setNewCategory('');
    setNewProductName(''); // Reset product name
    setNewPostType('sell');
    setNewState('');
    setNewZipCodes('');
    setNewReason('');
    setHasChanges(true);
  };

  const handleDeleteRule = (id: string) => {
    if (confirm('Are you sure you want to delete this rule?')) {
      setRules(prev => prev.filter(rule => rule.id !== id));
      setHasChanges(true);
    }
  };

  const handleSave = () => {
    // In real app, save to backend
    alert('Category deny list saved successfully!');
    setHasChanges(false);
  };

  const filteredRules = rules.filter(rule =>
    rule.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    rule.state.toLowerCase().includes(searchQuery.toLowerCase()) ||
    rule.reason.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Dashboard</span>
        </button>

        <div className="bg-white rounded-2xl shadow-sm p-6 sm:p-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <MapPin className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Category Deny List</h2>
                <p className="text-gray-600">Restrict categories by state and zipcode</p>
              </div>
            </div>
            <button
              onClick={() => setShowAddForm(true)}
              className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white font-medium rounded-lg hover:bg-purple-700 transition-colors"
            >
              <Plus className="w-5 h-5" />
              Add Rule
            </button>
          </div>

          {/* Search */}
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Search by category, state, or reason..."
              />
            </div>
          </div>

          {/* Rules List */}
          <div className="space-y-4 mb-6">
            {filteredRules.length === 0 ? (
              <div className="text-center py-12">
                <MapPin className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-600">No deny list rules found</p>
              </div>
            ) : (
              filteredRules.map((rule) => (
                <div
                  key={rule.id}
                  className="border border-gray-200 rounded-lg p-4 hover:border-purple-300 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold text-gray-900">{rule.category}</h3>
                        {rule.productName && (
                          <span className="px-2 py-0.5 bg-gray-100 text-gray-700 rounded text-xs font-medium">
                            {rule.productName}
                          </span>
                        )}
                        <span className="px-2 py-0.5 bg-purple-100 text-purple-700 rounded text-xs font-medium">
                          {rule.postType}
                        </span>
                        <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs font-medium">
                          {rule.state}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{rule.reason}</p>
                      {rule.zipCodes.length > 0 && (
                        <div className="flex flex-wrap gap-1 mb-2">
                          <span className="text-xs text-gray-500">Zip codes:</span>
                          {rule.zipCodes.map((zip) => (
                            <span key={zip} className="px-2 py-0.5 bg-gray-100 text-gray-700 rounded text-xs">
                              {zip}
                            </span>
                          ))}
                        </div>
                      )}
                      <p className="text-xs text-gray-500">
                        Created: {new Date(rule.createdDate).toLocaleDateString()}
                      </p>
                    </div>
                    <button
                      onClick={() => handleDeleteRule(rule.id)}
                      className="ml-4 p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {hasChanges && (
            <div className="border-t border-gray-200 pt-6">
              <div className="flex justify-end">
                <button
                  onClick={handleSave}
                  className="flex items-center gap-2 px-6 py-3 bg-purple-600 text-white font-medium rounded-lg hover:bg-purple-700 transition-colors"
                >
                  <Save className="w-5 h-5" />
                  Save Changes
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Add Rule Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-6">Add Deny List Rule</h3>
              
              <div className="space-y-4 mb-6">
                <div>
                  <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-2">
                    Category <span className="text-red-500">*</span>
                  </label>
                  <select
                    id="category"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    <option value="">Select a category</option>
                    {categories.map((cat) => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="product-name" className="block text-sm font-medium text-gray-700 mb-2">
                    Product Name (optional)
                  </label>
                  <input
                    type="text"
                    id="product-name"
                    value={newProductName}
                    onChange={(e) => setNewProductName(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    placeholder="Enter a specific product name"
                  />
                </div>

                <div>
                  <label htmlFor="post-type" className="block text-sm font-medium text-gray-700 mb-2">
                    Post Type <span className="text-red-500">*</span>
                  </label>
                  <select
                    id="post-type"
                    value={newPostType}
                    onChange={(e) => setNewPostType(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    {postTypes.map((type) => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="state" className="block text-sm font-medium text-gray-700 mb-2">
                    State <span className="text-red-500">*</span>
                  </label>
                  <select
                    id="state"
                    value={newState}
                    onChange={(e) => setNewState(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    <option value="">Select a state</option>
                    {usStates.map((state) => (
                      <option key={state} value={state}>{state}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="zip-codes" className="block text-sm font-medium text-gray-700 mb-2">
                    Zip Codes (optional)
                  </label>
                  <input
                    type="text"
                    id="zip-codes"
                    value={newZipCodes}
                    onChange={(e) => setNewZipCodes(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    placeholder="e.g., 90001, 90002, 90003"
                  />
                  <p className="text-xs text-gray-500 mt-1">Leave blank to apply to entire state. Separate multiple zip codes with commas.</p>
                </div>

                <div>
                  <label htmlFor="reason" className="block text-sm font-medium text-gray-700 mb-2">
                    Reason <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    id="reason"
                    value={newReason}
                    onChange={(e) => setNewReason(e.target.value)}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
                    placeholder="Explain why this category is restricted..."
                  />
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowAddForm(false);
                    setNewCategory('');
                    setNewProductName(''); // Reset product name
                    setNewPostType('sell');
                    setNewState('');
                    setNewZipCodes('');
                    setNewReason('');
                  }}
                  className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddRule}
                  className="flex-1 px-4 py-3 bg-purple-600 text-white font-medium rounded-lg hover:bg-purple-700 transition-colors"
                >
                  Add Rule
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}