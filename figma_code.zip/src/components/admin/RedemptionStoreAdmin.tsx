import React, { useState } from 'react';
import { ArrowLeft, ShoppingBag, Save, Plus, Edit2, Trash2, Search } from 'lucide-react';

interface RedemptionStoreAdminProps {
  onBack: () => void;
}

interface StoreProduct {
  id: string;
  name: string;
  type: string; // Now a custom string instead of limited options
  pointCost: number;
  value: number;
  description: string;
  imageUrl: string;
  available: boolean;
  stock?: number;
}

export default function RedemptionStoreAdmin({ onBack }: RedemptionStoreAdminProps) {
  const [products, setProducts] = useState<StoreProduct[]>([
    {
      id: '1',
      name: 'Amazon Gift Card',
      type: 'Gift Cards',
      pointCost: 1000,
      value: 10,
      description: '$10 Amazon gift card',
      imageUrl: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=400',
      available: true,
      stock: 50,
    },
    {
      id: '2',
      name: 'Whole Foods Gift Card',
      type: 'Gift Cards',
      pointCost: 2500,
      value: 25,
      description: '$25 Whole Foods gift card',
      imageUrl: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400',
      available: true,
      stock: 30,
    },
    {
      id: '3',
      name: 'Local Food Bank Donation',
      type: 'Charity',
      pointCost: 500,
      value: 5,
      description: 'Donate $5 to your local food bank',
      imageUrl: 'https://images.unsplash.com/photo-1593113598332-cd288d649433?w=400',
      available: true,
    },
    {
      id: '4',
      name: 'Tree Planting Initiative',
      type: 'Charity',
      pointCost: 1000,
      value: 10,
      description: 'Plant 5 trees through environmental charity',
      imageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=400',
      available: true,
    },
    {
      id: '5',
      name: 'CasaGrown T-Shirt',
      type: 'Merchandise',
      pointCost: 1500,
      value: 15,
      description: 'Official CasaGrown cotton t-shirt',
      imageUrl: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400',
      available: true,
      stock: 25,
    },
  ]);

  const [productTypes, setProductTypes] = useState<string[]>([
    'Gift Cards',
    'Charity',
    'Merchandise',
    'Services',
    'Subscriptions'
  ]);

  const [showAddForm, setShowAddForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<StoreProduct | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [hasChanges, setHasChanges] = useState(false);

  // Form state
  const [formName, setFormName] = useState('');
  const [formType, setFormType] = useState('');
  const [formPointCost, setFormPointCost] = useState('');
  const [formValue, setFormValue] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formImageUrl, setFormImageUrl] = useState('');
  const [formStock, setFormStock] = useState('');
  const [formAvailable, setFormAvailable] = useState(true);
  const [formNewType, setFormNewType] = useState('');
  const [isCreatingNewType, setIsCreatingNewType] = useState(false);

  const resetForm = () => {
    setFormName('');
    setFormType('');
    setFormPointCost('');
    setFormValue('');
    setFormDescription('');
    setFormImageUrl('');
    setFormStock('');
    setFormAvailable(true);
    setFormNewType('');
    setIsCreatingNewType(false);
    setEditingProduct(null);
  };

  const loadProductToForm = (product: StoreProduct) => {
    setFormName(product.name);
    setFormType(product.type);
    setFormPointCost(product.pointCost.toString());
    setFormValue(product.value.toString());
    setFormDescription(product.description);
    setFormImageUrl(product.imageUrl);
    setFormStock(product.stock?.toString() || '');
    setFormAvailable(product.available);
    setEditingProduct(product);
    setShowAddForm(true);
  };

  const handleSubmit = () => {
    if (!formName || !formType || !formPointCost || !formValue || !formDescription) {
      alert('Please fill in all required fields');
      return;
    }

    const productData: StoreProduct = {
      id: editingProduct?.id || Date.now().toString(),
      name: formName,
      type: formType,
      pointCost: parseInt(formPointCost),
      value: parseInt(formValue),
      description: formDescription,
      imageUrl: formImageUrl || 'https://images.unsplash.com/photo-1607083206869-4c7672e72a8a?w=400',
      available: formAvailable,
      ...(formStock ? { stock: parseInt(formStock) } : {}),
    };

    if (editingProduct) {
      setProducts(prev => prev.map(p => p.id === editingProduct.id ? productData : p));
    } else {
      setProducts(prev => [productData, ...prev]);
    }

    setShowAddForm(false);
    resetForm();
    setHasChanges(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this product?')) {
      setProducts(prev => prev.filter(p => p.id !== id));
      setHasChanges(true);
    }
  };

  const handleSave = () => {
    // In real app, save to backend
    alert('Redemption store products saved successfully!');
    setHasChanges(false);
  };

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || product.type === filterType;
    return matchesSearch && matchesType;
  });

  // Get unique types from products for the filter
  const uniqueProductTypes = Array.from(new Set(products.map(p => p.type))).sort();

  // Type color mapping
  const getTypeColor = (type: string) => {
    const colorMap: Record<string, string> = {
      'Gift Cards': 'bg-blue-100 text-blue-700',
      'Charity': 'bg-green-100 text-green-700',
      'Merchandise': 'bg-purple-100 text-purple-700',
      'Services': 'bg-orange-100 text-orange-700',
      'Subscriptions': 'bg-pink-100 text-pink-700',
    };
    return colorMap[type] || 'bg-gray-100 text-gray-700';
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Dashboard</span>
        </button>

        <div className="bg-white rounded-2xl shadow-sm p-6 sm:p-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <ShoppingBag className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Redemption Store Management</h2>
                <p className="text-gray-600">Manage products available for redemption</p>
              </div>
            </div>
            <button
              onClick={() => setShowAddForm(true)}
              className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white font-medium rounded-lg hover:bg-orange-700 transition-colors"
            >
              <Plus className="w-5 h-5" />
              Add Product
            </button>
          </div>

          {/* Search and Filter */}
          <div className="flex gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                placeholder="Search products..."
              />
            </div>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            >
              <option value="all">All Types</option>
              {uniqueProductTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
            {filteredProducts.length === 0 ? (
              <div className="col-span-full text-center py-12">
                <ShoppingBag className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-600">No products found</p>
              </div>
            ) : (
              filteredProducts.map((product) => (
                <div
                  key={product.id}
                  className={`border-2 rounded-lg overflow-hidden transition-colors ${
                    product.available ? 'border-gray-200' : 'border-gray-300 opacity-60'
                  }`}
                >
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="w-full h-40 object-cover"
                  />
                  <div className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-gray-900">{product.name}</h3>
                      <span className={`px-2 py-0.5 rounded text-xs font-medium whitespace-nowrap ${getTypeColor(product.type)}`}>
                        {product.type}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">{product.description}</p>
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <p className="text-xs text-gray-500">Points</p>
                        <p className="font-semibold text-orange-600">{product.pointCost}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Value</p>
                        <p className="font-semibold text-gray-900">${product.value}</p>
                      </div>
                      {product.stock !== undefined && (
                        <div>
                          <p className="text-xs text-gray-500">Stock</p>
                          <p className="font-semibold text-gray-900">{product.stock}</p>
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => loadProductToForm(product)}
                        className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        <Edit2 className="w-4 h-4" />
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(product.id)}
                        className="flex items-center justify-center px-3 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {hasChanges && (
            <div className="border-t border-gray-200 pt-6">
              <div className="flex justify-end">
                <button
                  onClick={handleSave}
                  className="flex items-center gap-2 px-6 py-3 bg-orange-600 text-white font-medium rounded-lg hover:bg-orange-700 transition-colors"
                >
                  <Save className="w-5 h-5" />
                  Save Changes
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Add/Edit Product Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-6">
                {editingProduct ? 'Edit Product' : 'Add New Product'}
              </h3>
              
              <div className="space-y-4 mb-6">
                <div>
                  <label htmlFor="product-name" className="block text-sm font-medium text-gray-700 mb-2">
                    Product Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    id="product-name"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="e.g., Amazon Gift Card"
                  />
                </div>

                <div>
                  <label htmlFor="product-type" className="block text-sm font-medium text-gray-700 mb-2">
                    Product Type <span className="text-red-500">*</span>
                  </label>
                  {!isCreatingNewType ? (
                    <select
                      id="product-type"
                      value={formType}
                      onChange={(e) => {
                        if (e.target.value === '__create_new__') {
                          setIsCreatingNewType(true);
                          setFormType('');
                        } else {
                          setFormType(e.target.value);
                        }
                      }}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    >
                      <option value="">Select a type</option>
                      {productTypes.map(type => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                      <option value="__create_new__">+ Create New Type</option>
                    </select>
                  ) : (
                    <div className="space-y-2">
                      <input
                        type="text"
                        value={formNewType}
                        onChange={(e) => setFormNewType(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                        placeholder="Enter new product type"
                        autoFocus
                      />
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            if (formNewType.trim()) {
                              if (!productTypes.includes(formNewType.trim())) {
                                setProductTypes(prev => [...prev, formNewType.trim()].sort());
                              }
                              setFormType(formNewType.trim());
                              setFormNewType('');
                              setIsCreatingNewType(false);
                            }
                          }}
                          className="flex-1 px-3 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors"
                        >
                          Add Type
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setIsCreatingNewType(false);
                            setFormNewType('');
                          }}
                          className="flex-1 px-3 py-2 border border-gray-300 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-50 transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="point-cost" className="block text-sm font-medium text-gray-700 mb-2">
                      Point Cost <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      id="point-cost"
                      value={formPointCost}
                      onChange={(e) => setFormPointCost(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="1000"
                      min="0"
                    />
                  </div>

                  <div>
                    <label htmlFor="value" className="block text-sm font-medium text-gray-700 mb-2">
                      Dollar Value <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      id="value"
                      value={formValue}
                      onChange={(e) => setFormValue(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="10"
                      min="0"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="stock" className="block text-sm font-medium text-gray-700 mb-2">
                    Stock Quantity (optional)
                  </label>
                  <input
                    type="number"
                    id="stock"
                    value={formStock}
                    onChange={(e) => setFormStock(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="50"
                    min="0"
                  />
                </div>

                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
                    Description <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    id="description"
                    value={formDescription}
                    onChange={(e) => setFormDescription(e.target.value)}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                    placeholder="Describe the product..."
                  />
                </div>

                <div>
                  <label htmlFor="image-url" className="block text-sm font-medium text-gray-700 mb-2">
                    Image URL
                  </label>
                  <input
                    type="text"
                    id="image-url"
                    value={formImageUrl}
                    onChange={(e) => setFormImageUrl(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="https://example.com/image.jpg"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="available"
                    checked={formAvailable}
                    onChange={(e) => setFormAvailable(e.target.checked)}
                    className="w-4 h-4 text-orange-600 border-gray-300 rounded focus:ring-orange-500"
                  />
                  <label htmlFor="available" className="text-sm font-medium text-gray-700">
                    Available for redemption
                  </label>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowAddForm(false);
                    resetForm();
                  }}
                  className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSubmit}
                  className="flex-1 px-4 py-3 bg-orange-600 text-white font-medium rounded-lg hover:bg-orange-700 transition-colors"
                >
                  {editingProduct ? 'Update Product' : 'Add Product'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
