import React, { useState } from 'react';
import { ArrowLeft, Flag, CheckCircle, XCircle, MessageSquare, User, Calendar, MapPin, Search, Ban } from 'lucide-react';

interface FlaggedPostsProps {
  onBack: () => void;
}

interface FlaggedPost {
  id: string;
  postId: string;
  postTitle: string;
  postAuthor: string;
  postAuthorEmail: string;
  postCommunity: string;
  zipCode: string;
  postType: string;
  flaggedBy: string;
  flagReason: string;
  flagCategory: string;
  flagDate: string;
  flagDetails: string;
  status: 'pending' | 'approved' | 'removed';
  disputeCount: number;
}

interface UserFlagStats {
  email: string;
  name: string;
  flagCount: number;
  isBanned: boolean;
}

export default function FlaggedPosts({ onBack }: FlaggedPostsProps) {
  const [flaggedPosts, setFlaggedPosts] = useState<FlaggedPost[]>([
    {
      id: '1',
      postId: 'post-123',
      postTitle: 'Fresh Organic Tomatoes',
      postAuthor: 'John Smith',
      postAuthorEmail: 'john@example.com',
      postCommunity: 'Lincoln Park Community',
      zipCode: '60614',
      postType: 'sell',
      flaggedBy: 'Sarah Johnson',
      flagReason: 'Inappropriate Content',
      flagCategory: 'Spam or Misleading',
      flagDate: '2026-01-25',
      flagDetails: 'This appears to be spam advertising non-local produce',
      status: 'pending',
      disputeCount: 2,
    },
    {
      id: '2',
      postId: 'post-456',
      postTitle: 'Garden Maintenance Service',
      postAuthor: 'Mike Chen',
      postAuthorEmail: 'mike@example.com',
      postCommunity: 'Downtown Gardens',
      zipCode: '60601',
      postType: 'service-offer',
      flaggedBy: 'Emily Rodriguez',
      flagReason: 'Policy Violation',
      flagCategory: 'Prohibited Service',
      flagDate: '2026-01-24',
      flagDetails: 'Offering commercial landscaping which violates neighbor-to-neighbor policy',
      status: 'pending',
      disputeCount: 1,
    },
    {
      id: '3',
      postId: 'post-789',
      postTitle: 'Looking for Fresh Eggs',
      postAuthor: 'Lisa Parker',
      postAuthorEmail: 'lisa@example.com',
      postCommunity: 'Riverside Community',
      zipCode: '60618',
      postType: 'buy',
      flaggedBy: 'David Kim',
      flagReason: 'Other',
      flagCategory: 'Other',
      flagDate: '2026-01-26',
      flagDetails: 'Duplicate post - already posted yesterday',
      status: 'pending',
      disputeCount: 0,
    },
    {
      id: '4',
      postId: 'post-999',
      postTitle: 'Selling Garden Tools',
      postAuthor: 'John Smith',
      postAuthorEmail: 'john@example.com',
      postCommunity: 'Lincoln Park Community',
      zipCode: '60614',
      postType: 'sell',
      flaggedBy: 'Tom Wilson',
      flagReason: 'Spam',
      flagCategory: 'Spam or Misleading',
      flagDate: '2026-01-27',
      flagDetails: 'User posts too frequently with suspicious items',
      status: 'pending',
      disputeCount: 3,
    },
    {
      id: '5',
      postId: 'post-888',
      postTitle: 'Free Compost',
      postAuthor: 'John Smith',
      postAuthorEmail: 'john@example.com',
      postCommunity: 'Lincoln Park Community',
      zipCode: '60614',
      postType: 'sell',
      flaggedBy: 'Rachel Green',
      flagReason: 'Spam',
      flagCategory: 'Spam or Misleading',
      flagDate: '2026-01-26',
      flagDetails: 'Another spam post from same user',
      status: 'pending',
      disputeCount: 1,
    },
  ]);

  const [bannedUsers, setBannedUsers] = useState<Set<string>>(new Set());
  const [selectedPost, setSelectedPost] = useState<FlaggedPost | null>(null);
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'approved' | 'removed'>('pending');
  const [adminNote, setAdminNote] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterZipCode, setFilterZipCode] = useState('');
  const [filterUser, setFilterUser] = useState('');
  const [showBanUserModal, setShowBanUserModal] = useState(false);
  const [userToBan, setUserToBan] = useState<UserFlagStats | null>(null);
  const [banReason, setBanReason] = useState('');

  const handleApprove = (postId: string) => {
    setFlaggedPosts(prev =>
      prev.map(post =>
        post.id === postId ? { ...post, status: 'approved' as const } : post
      )
    );
    setSelectedPost(null);
    alert('Post approved - flag dismissed');
  };

  const handleRemove = (postId: string) => {
    if (!adminNote.trim()) {
      alert('Please provide a reason for removing this post');
      return;
    }
    setFlaggedPosts(prev =>
      prev.map(post =>
        post.id === postId ? { ...post, status: 'removed' as const } : post
      )
    );
    setSelectedPost(null);
    setAdminNote('');
    alert('Post removed and author notified');
  };

  const handleBanUser = () => {
    if (!userToBan || !banReason.trim()) {
      alert('Please provide a reason for banning this user');
      return;
    }
    setBannedUsers(prev => new Set(prev).add(userToBan.email));
    setShowBanUserModal(false);
    setUserToBan(null);
    setBanReason('');
    alert(`User ${userToBan.name} has been banned`);
  };

  const handleUnbanUser = (email: string) => {
    if (confirm('Are you sure you want to unban this user?')) {
      setBannedUsers(prev => {
        const newSet = new Set(prev);
        newSet.delete(email);
        return newSet;
      });
      alert('User unbanned successfully');
    }
  };

  // Get user flag statistics
  const getUserFlagStats = (): UserFlagStats[] => {
    const userMap = new Map<string, UserFlagStats>();
    
    flaggedPosts.forEach(post => {
      if (!userMap.has(post.postAuthorEmail)) {
        userMap.set(post.postAuthorEmail, {
          email: post.postAuthorEmail,
          name: post.postAuthor,
          flagCount: 0,
          isBanned: bannedUsers.has(post.postAuthorEmail),
        });
      }
      const stats = userMap.get(post.postAuthorEmail)!;
      stats.flagCount++;
    });

    return Array.from(userMap.values()).sort((a, b) => b.flagCount - a.flagCount);
  };

  const filteredPosts = flaggedPosts.filter(post => {
    const matchesStatus = filterStatus === 'all' || post.status === filterStatus;
    const matchesSearch = searchQuery === '' ||
      post.postTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.postAuthor.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.flagCategory.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.flagDetails.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesZipCode = filterZipCode === '' || post.zipCode.includes(filterZipCode);
    const matchesUser = filterUser === '' ||
      post.postAuthor.toLowerCase().includes(filterUser.toLowerCase()) ||
      post.postAuthorEmail.toLowerCase().includes(filterUser.toLowerCase());
    
    return matchesStatus && matchesSearch && matchesZipCode && matchesUser;
  });

  const pendingCount = flaggedPosts.filter(p => p.status === 'pending').length;
  const userStats = getUserFlagStats();
  const uniqueZipCodes = Array.from(new Set(flaggedPosts.map(p => p.zipCode))).sort();

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Dashboard</span>
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-sm p-6 sm:p-8">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                    <Flag className="w-6 h-6 text-red-600" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">Flagged Posts</h2>
                    <p className="text-gray-600">Monitor and moderate reported content</p>
                  </div>
                </div>
                {pendingCount > 0 && (
                  <div className="px-4 py-2 bg-red-100 text-red-700 rounded-lg font-medium">
                    {pendingCount} Pending
                  </div>
                )}
              </div>

              {/* Search and Filters */}
              <div className="space-y-3 mb-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    placeholder="Search by title, author, category, or details..."
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <select
                    value={filterZipCode}
                    onChange={(e) => setFilterZipCode(e.target.value)}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent text-sm"
                  >
                    <option value="">All Zip Codes</option>
                    {uniqueZipCodes.map(zip => (
                      <option key={zip} value={zip}>{zip}</option>
                    ))}
                  </select>
                  <input
                    type="text"
                    value={filterUser}
                    onChange={(e) => setFilterUser(e.target.value)}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent text-sm"
                    placeholder="Filter by user..."
                  />
                </div>
              </div>

              {/* Filter Tabs */}
              <div className="flex gap-2 mb-6 border-b border-gray-200">
                {(['all', 'pending', 'approved', 'removed'] as const).map((status) => (
                  <button
                    key={status}
                    onClick={() => setFilterStatus(status)}
                    className={`px-4 py-2 font-medium transition-colors capitalize ${
                      filterStatus === status
                        ? 'text-green-600 border-b-2 border-green-600'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    {status}
                    {status === 'pending' && pendingCount > 0 && (
                      <span className="ml-2 px-2 py-0.5 bg-red-100 text-red-700 rounded-full text-xs">
                        {pendingCount}
                      </span>
                    )}
                  </button>
                ))}
              </div>

              {/* Flagged Posts List */}
              <div className="space-y-4">
                {filteredPosts.length === 0 ? (
                  <div className="text-center py-12">
                    <Flag className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-600">No {filterStatus !== 'all' ? filterStatus : ''} flagged posts found</p>
                  </div>
                ) : (
                  filteredPosts.map((post) => (
                    <div
                      key={post.id}
                      className={`border-2 rounded-lg p-4 transition-colors ${
                        post.status === 'pending'
                          ? 'border-red-200 bg-red-50'
                          : post.status === 'approved'
                          ? 'border-green-200 bg-green-50'
                          : 'border-gray-300 bg-gray-50'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-semibold text-gray-900">{post.postTitle}</h3>
                            <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                              post.postType === 'sell' ? 'bg-green-100 text-green-700' :
                              post.postType === 'buy' ? 'bg-blue-100 text-blue-700' :
                              'bg-purple-100 text-purple-700'
                            }`}>
                              {post.postType}
                            </span>
                            {post.disputeCount > 0 && (
                              <span className="px-2 py-0.5 bg-orange-100 text-orange-700 rounded text-xs font-medium">
                                {post.disputeCount} dispute{post.disputeCount > 1 ? 's' : ''}
                              </span>
                            )}
                            {bannedUsers.has(post.postAuthorEmail) && (
                              <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded text-xs font-medium">
                                BANNED USER
                              </span>
                            )}
                          </div>
                          <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-2">
                            <div className="flex items-center gap-1">
                              <User className="w-4 h-4" />
                              Author: {post.postAuthor}
                            </div>
                            <div className="flex items-center gap-1">
                              <MapPin className="w-4 h-4" />
                              {post.postCommunity} ({post.zipCode})
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              Flagged: {new Date(post.flagDate).toLocaleDateString()}
                            </div>
                          </div>
                          <div className="bg-white rounded p-3 mb-2">
                            <p className="text-sm font-medium text-gray-900 mb-1">
                              Flag Reason: {post.flagCategory}
                            </p>
                            <p className="text-sm text-gray-600">
                              Flagged by {post.flaggedBy}: "{post.flagDetails}"
                            </p>
                          </div>
                        </div>
                        <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                          post.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                          post.status === 'approved' ? 'bg-green-100 text-green-700' :
                          'bg-red-100 text-red-700'
                        }`}>
                          {post.status}
                        </div>
                      </div>

                      {post.status === 'pending' && (
                        <div className="flex gap-3 pt-3 border-t border-gray-200">
                          <button
                            onClick={() => setSelectedPost(post)}
                            className="flex-1 px-4 py-2 bg-white border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors text-sm"
                          >
                            Review
                          </button>
                          <button
                            onClick={() => handleApprove(post.id)}
                            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors text-sm"
                          >
                            <CheckCircle className="w-4 h-4" />
                            Approve
                          </button>
                          <button
                            onClick={() => setSelectedPost(post)}
                            className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white font-medium rounded-lg hover:bg-red-700 transition-colors text-sm"
                          >
                            <XCircle className="w-4 h-4" />
                            Remove
                          </button>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* User Stats Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-sm p-6 sticky top-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                  <User className="w-5 h-5 text-purple-600" />
                </div>
                <h3 className="font-bold text-gray-900">User Flag Statistics</h3>
              </div>
              
              <div className="space-y-3">
                {userStats.length === 0 ? (
                  <p className="text-sm text-gray-600 text-center py-4">No flagged users</p>
                ) : (
                  userStats.map((user) => (
                    <div
                      key={user.email}
                      className={`p-3 rounded-lg border-2 transition-colors ${
                        user.isBanned
                          ? 'border-red-200 bg-red-50'
                          : user.flagCount >= 3
                          ? 'border-orange-200 bg-orange-50'
                          : 'border-gray-200 bg-gray-50'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <p className="font-semibold text-gray-900 text-sm">{user.name}</p>
                          <p className="text-xs text-gray-600">{user.email}</p>
                        </div>
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                          user.flagCount >= 5 ? 'bg-red-100 text-red-700' :
                          user.flagCount >= 3 ? 'bg-orange-100 text-orange-700' :
                          'bg-gray-100 text-gray-700'
                        }`}>
                          {user.flagCount} flag{user.flagCount > 1 ? 's' : ''}
                        </span>
                      </div>
                      {user.isBanned ? (
                        <button
                          onClick={() => handleUnbanUser(user.email)}
                          className="w-full px-3 py-1.5 bg-green-600 text-white text-xs font-medium rounded hover:bg-green-700 transition-colors"
                        >
                          Unban User
                        </button>
                      ) : (
                        <button
                          onClick={() => {
                            setUserToBan(user);
                            setShowBanUserModal(true);
                          }}
                          className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 bg-red-600 text-white text-xs font-medium rounded hover:bg-red-700 transition-colors"
                        >
                          <Ban className="w-3 h-3" />
                          Ban User
                        </button>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Review Modal */}
      {selectedPost && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Review Flagged Post</h3>
              
              <div className="space-y-4 mb-6">
                <div>
                  <p className="text-sm font-medium text-gray-700">Post Title</p>
                  <p className="text-gray-900">{selectedPost.postTitle}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700">Author</p>
                  <p className="text-gray-900">{selectedPost.postAuthor} ({selectedPost.postAuthorEmail})</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700">Community & Location</p>
                  <p className="text-gray-900">{selectedPost.postCommunity} - Zip: {selectedPost.zipCode}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700">Flag Category</p>
                  <p className="text-gray-900">{selectedPost.flagCategory}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700">Flag Details</p>
                  <p className="text-gray-900">{selectedPost.flagDetails}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700">Flagged By</p>
                  <p className="text-gray-900">{selectedPost.flaggedBy}</p>
                </div>
                
                <div>
                  <label htmlFor="admin-note" className="block text-sm font-medium text-gray-700 mb-2">
                    Admin Note (required for removal)
                  </label>
                  <textarea
                    id="admin-note"
                    value={adminNote}
                    onChange={(e) => setAdminNote(e.target.value)}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
                    placeholder="Explain why this post is being removed..."
                  />
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setSelectedPost(null);
                    setAdminNote('');
                  }}
                  className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={() => handleApprove(selectedPost.id)}
                  className="flex items-center justify-center gap-2 flex-1 px-4 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
                >
                  <CheckCircle className="w-5 h-5" />
                  Approve Post
                </button>
                <button
                  onClick={() => handleRemove(selectedPost.id)}
                  className="flex items-center justify-center gap-2 flex-1 px-4 py-3 bg-red-600 text-white font-medium rounded-lg hover:bg-red-700 transition-colors"
                >
                  <XCircle className="w-5 h-5" />
                  Remove Post
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Ban User Modal */}
      {showBanUserModal && userToBan && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full">
            <div className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                  <Ban className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Ban User</h3>
                  <p className="text-sm text-gray-600">{userToBan.name}</p>
                </div>
              </div>
              
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 mb-4">
                <p className="text-sm text-orange-800">
                  <strong>Warning:</strong> This user has {userToBan.flagCount} flagged post{userToBan.flagCount > 1 ? 's' : ''}. 
                  Banning will prevent them from posting or commenting.
                </p>
              </div>

              <div className="mb-6">
                <label htmlFor="ban-reason" className="block text-sm font-medium text-gray-700 mb-2">
                  Reason for Ban <span className="text-red-500">*</span>
                </label>
                <textarea
                  id="ban-reason"
                  value={banReason}
                  onChange={(e) => setBanReason(e.target.value)}
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
                  placeholder="Explain why this user is being banned..."
                />
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowBanUserModal(false);
                    setUserToBan(null);
                    setBanReason('');
                  }}
                  className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleBanUser}
                  className="flex items-center justify-center gap-2 flex-1 px-4 py-3 bg-red-600 text-white font-medium rounded-lg hover:bg-red-700 transition-colors"
                >
                  <Ban className="w-5 h-5" />
                  Ban User
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
