import React, { useState } from 'react';
import { ArrowLeft, Gift, Save, Info } from 'lucide-react';

interface RewardsConfigProps {
  onBack: () => void;
}

interface RewardStage {
  id: string;
  stage: string;
  description: string;
  points: number;
}

export default function RewardsConfig({ onBack }: RewardsConfigProps) {
  const [rewards, setRewards] = useState<RewardStage[]>([
    { id: '1', stage: 'Account Creation', description: 'User completes initial signup', points: 50 },
    { id: '2', stage: 'Email Verification', description: 'User verifies their email address', points: 25 },
    { id: '3', stage: 'Profile Photo', description: 'User uploads a profile photo', points: 30 },
    { id: '4', stage: 'Bio & Interests', description: 'User completes bio and selects interests', points: 40 },
    { id: '5', stage: 'Community Join', description: 'User joins their first community', points: 50 },
    { id: '6', stage: 'Location Set', description: 'User sets their location/address', points: 20 },
    { id: '7', stage: 'First Post', description: 'User creates their first post', points: 100 },
  ]);

  const [hasChanges, setHasChanges] = useState(false);

  const handlePointsChange = (id: string, newPoints: string) => {
    const pointsValue = parseInt(newPoints) || 0;
    setRewards(prev => 
      prev.map(reward => 
        reward.id === id ? { ...reward, points: pointsValue } : reward
      )
    );
    setHasChanges(true);
  };

  const handleSave = () => {
    // In real app, save to backend
    alert('Reward configuration saved successfully!');
    setHasChanges(false);
  };

  const totalPoints = rewards.reduce((sum, reward) => sum + reward.points, 0);

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Dashboard</span>
        </button>

        <div className="bg-white rounded-2xl shadow-sm p-6 sm:p-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <Gift className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Profile Rewards Configuration</h2>
              <p className="text-gray-600">Set points awarded at each profile creation stage</p>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6 flex gap-3">
            <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-blue-900">
              <p className="font-medium mb-1">About Profile Rewards</p>
              <p>These points are automatically awarded to users as they complete each stage of setting up their profile. This encourages user engagement and profile completion.</p>
            </div>
          </div>

          <div className="space-y-4 mb-6">
            {rewards.map((reward, index) => (
              <div key={reward.id} className="border border-gray-200 rounded-lg p-4 hover:border-green-300 transition-colors">
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-sm font-semibold text-green-700">{index + 1}</span>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 mb-1">{reward.stage}</h3>
                    <p className="text-sm text-gray-600">{reward.description}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={reward.points}
                      onChange={(e) => handlePointsChange(reward.id, e.target.value)}
                      className="w-24 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-right"
                      min="0"
                    />
                    <span className="text-sm text-gray-600">pts</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="border-t border-gray-200 pt-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <p className="text-sm text-gray-600">Total Points Available</p>
                <p className="text-2xl font-bold text-gray-900">{totalPoints} points</p>
              </div>
              <button
                onClick={handleSave}
                disabled={!hasChanges}
                className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-colors ${
                  hasChanges
                    ? 'bg-green-600 text-white hover:bg-green-700'
                    : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                }`}
              >
                <Save className="w-5 h-5" />
                Save Changes
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
