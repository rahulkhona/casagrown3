import React, { useState } from 'react';
import { Package, Clock, CheckCircle, QrCode, Star, Scan, Camera, MapPin, AlertCircle, MessageCircle, X } from 'lucide-react';
import ChatInterface from './ChatInterface';

interface User {
  id: string;
  name: string;
}

interface OrdersPageProps {
  user: User;
}

interface Order {
  id: string;
  type: 'buy' | 'sell';
  status: 'pending' | 'completed' | 'disputed' | 'cancelled';
  product: string;
  category: string;
  quantity: string;
  price: number;
  otherParty: string;
  otherPartyId: string;
  fulfillmentMethod: 'pickup' | 'dropoff';
  pickupLocation?: string;
  dropoffAddress?: string;
  dropoffTimeWindow?: string;
  pickupDate: string;
  passcode: string;
  createdAt: Date;
  lastResponseAt?: Date;
  dropoffCompletedAt?: Date;
  dropoffPhoto?: string;
  dropoffGeoTag?: { lat: number; lng: number };
  disputeReason?: string;
  disputePhoto?: string;
  disputeStatus?: 'buyer-initiated' | 'seller-refunded' | 'buyer-resolved' | 'escalated-to-admin';
  rating?: number;
  sellerAccepted?: boolean;
  cancelledBy?: string;
  cancelledAt?: Date;
  cancellationReason?: string;
}

const mockOrders: Order[] = [
  {
    id: '1',
    type: 'buy',
    status: 'pending',
    product: 'Fresh Organic Tomatoes',
    category: 'Vegetables',
    quantity: '5 lbs',
    price: 50,
    otherParty: 'Sarah Johnson',
    otherPartyId: 'user123',
    fulfillmentMethod: 'dropoff',
    dropoffAddress: '123 Main St, Apt 4B',
    dropoffTimeWindow: 'Monday 2-4 PM',
    pickupDate: 'Monday, 2 PM',
    passcode: '4829',
    createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
    lastResponseAt: new Date(Date.now() - 10 * 60 * 1000),
    dropoffCompletedAt: new Date(Date.now() - 10 * 60 * 1000),
    dropoffPhoto: 'https://images.unsplash.com/photo-1592841200221-a6898f307baa?w=400',
    dropoffGeoTag: { lat: 40.7128, lng: -74.0060 },
    sellerAccepted: true
  },
  {
    id: '2',
    type: 'sell',
    status: 'pending',
    product: 'Fresh Zucchini',
    category: 'Vegetables',
    quantity: '10 pieces',
    price: 35,
    otherParty: 'Robert Kim',
    otherPartyId: 'user456',
    fulfillmentMethod: 'pickup',
    pickupLocation: '789 Elm St',
    pickupDate: 'Tuesday, 3 PM',
    passcode: '5617',
    createdAt: new Date(Date.now() - 30 * 60 * 1000),
    lastResponseAt: new Date(Date.now() - 5 * 60 * 1000),
    sellerAccepted: true
  },
  {
    id: '5',
    type: 'sell',
    status: 'pending',
    product: 'Homegrown Cucumbers',
    category: 'Vegetables',
    quantity: '8 pieces',
    price: 40,
    otherParty: 'Jennifer Lee',
    otherPartyId: 'user555',
    fulfillmentMethod: 'dropoff',
    dropoffAddress: '456 Maple Ave, Unit 2',
    dropoffTimeWindow: 'Tuesday 1-3 PM',
    pickupDate: 'Tuesday, 1 PM',
    passcode: '9283',
    createdAt: new Date(Date.now() - 20 * 60 * 1000),
    lastResponseAt: new Date(Date.now() - 2 * 60 * 1000),
    sellerAccepted: false // Awaiting seller acceptance
    // NO dropoffCompletedAt - seller needs to drop off and take photo!
  },
  {
    id: '8',
    type: 'buy',
    status: 'pending',
    product: 'Fresh Basil',
    category: 'Herbs',
    quantity: '2 bunches',
    price: 20,
    otherParty: 'Alex Thompson',
    otherPartyId: 'user999',
    fulfillmentMethod: 'pickup',
    pickupLocation: '444 Cedar Ln',
    pickupDate: 'Wednesday, 2 PM',
    passcode: '7452',
    createdAt: new Date(Date.now() - 48 * 60 * 60 * 1000), // 48 hours ago
    lastResponseAt: new Date(Date.now() - 48 * 60 * 60 * 1000), // No response from seller!
    sellerAccepted: false
  },
  {
    id: '6',
    type: 'buy',
    status: 'pending',
    product: 'Garden Fresh Lettuce',
    category: 'Vegetables',
    quantity: '2 heads',
    price: 25,
    otherParty: 'Emily Chen',
    otherPartyId: 'user777',
    fulfillmentMethod: 'pickup',
    pickupLocation: '321 Oak Street',
    pickupDate: 'Monday, 11 AM',
    passcode: '3847',
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    lastResponseAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
    dropoffCompletedAt: new Date(Date.now() - 15 * 60 * 1000), // Completed 15 mins ago - can still dispute!
    dropoffPhoto: 'https://images.unsplash.com/photo-1622206151226-18ca2c9ab4a1?w=400',
    sellerAccepted: true
  },
  {
    id: '7',
    type: 'sell',
    status: 'pending',
    product: 'Fresh Bell Peppers',
    category: 'Vegetables',
    quantity: '6 pieces',
    price: 30,
    otherParty: 'David Martinez',
    otherPartyId: 'user888',
    fulfillmentMethod: 'dropoff',
    dropoffAddress: '555 Pine Ave',
    dropoffTimeWindow: 'Monday 10 AM - 12 PM',
    pickupDate: 'Monday, 10 AM',
    passcode: '6291',
    createdAt: new Date(Date.now() - 45 * 60 * 1000),
    lastResponseAt: new Date(Date.now() - 20 * 60 * 1000),
    dropoffCompletedAt: new Date(Date.now() - 20 * 60 * 1000),
    dropoffPhoto: 'https://images.unsplash.com/photo-1563565375-f3fdfdbefa83?w=400',
    dropoffGeoTag: { lat: 40.7580, lng: -73.9855 },
    disputeReason: 'The peppers are bruised and some are moldy',
    disputePhoto: 'https://images.unsplash.com/photo-1587735243615-c03f25aaff15?w=400',
    sellerAccepted: true
    // This is a seller view - buyer already disputed!
  },
  {
    id: '3',
    type: 'sell',
    status: 'completed',
    product: 'Fresh Strawberries',
    category: 'Fruits',
    quantity: '3 lbs',
    price: 40,
    otherParty: 'Michael Chen',
    otherPartyId: 'user789',
    fulfillmentMethod: 'pickup',
    pickupLocation: '456 Oak Ave',
    pickupDate: 'Saturday, 10 AM',
    passcode: '7361',
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    lastResponseAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    rating: 5,
    sellerAccepted: true
  },
  {
    id: '4',
    type: 'buy',
    status: 'completed',
    product: 'Gardening Gloves',
    category: 'Equipment',
    quantity: '1 pair',
    price: 15,
    otherParty: 'Lisa Wong',
    otherPartyId: 'user101',
    fulfillmentMethod: 'pickup',
    pickupLocation: '789 Pine Rd',
    pickupDate: 'Wednesday, 4 PM',
    passcode: '2948',
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    lastResponseAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    rating: 4,
    sellerAccepted: true
  },
];

export default function OrdersPage({ user }: OrdersPageProps) {
  const [activeTab, setActiveTab] = useState<'pending' | 'completed' | 'disputed'>('pending');
  const [showPasscode, setShowPasscode] = useState<string | null>(null);
  const [showRating, setShowRating] = useState<string | null>(null);
  const [selectedRating, setSelectedRating] = useState(0);
  const [ratingComment, setRatingComment] = useState('');
  const [showVerification, setShowVerification] = useState<string | null>(null);
  const [manualPasscode, setManualPasscode] = useState('');
  const [chatWithOrder, setChatWithOrder] = useState<Order | null>(null);
  
  // Drop-off related states
  const [showDropoffCapture, setShowDropoffCapture] = useState<string | null>(null);
  const [dropoffPhoto, setDropoffPhoto] = useState<string | null>(null);
  const [isCapturingGeoTag, setIsCapturingGeoTag] = useState(false);
  
  // Dispute related states
  const [showDisputeModal, setShowDisputeModal] = useState<string | null>(null);
  const [disputeReason, setDisputeReason] = useState('');
  const [disputePhoto, setDisputePhoto] = useState<string | null>(null);
  
  // Cancel order states
  const [showCancelModal, setShowCancelModal] = useState<string | null>(null);
  const [cancellationReason, setCancellationReason] = useState('');

  const pendingOrders = mockOrders.filter(o => o.status === 'pending');
  const completedOrders = mockOrders.filter(o => o.status === 'completed');
  const disputedOrders = mockOrders.filter(o => o.status === 'disputed');

  const handleCompleteOrder = (orderId: string) => {
    // Mark order as complete and show rating modal
    setShowPasscode(null);
    setShowVerification(null);
    setManualPasscode('');
    setSelectedRating(0);
    setRatingComment('');
    setShowRating(orderId);
  };

  const handleSubmitRating = () => {
    // Rating submitted
    setShowRating(null);
    setSelectedRating(0);
    setRatingComment('');
  };

  const handleDropoffPhotoCapture = (file: File | null) => {
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setDropoffPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDisputePhotoCapture = (file: File | null) => {
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setDisputePhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleConfirmDropoff = (orderId: string) => {
    if (!dropoffPhoto) {
      alert('Please take a photo of the dropped-off items');
      return;
    }
    
    setIsCapturingGeoTag(true);
    
    // Capture geolocation
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          // In real app, save to backend with photo and geotag
          setShowDropoffCapture(null);
          setDropoffPhoto(null);
          setIsCapturingGeoTag(false);
        },
        (error) => {
          alert('Unable to get location. Please enable location services.');
          setIsCapturingGeoTag(false);
        }
      );
    } else {
      alert('Geolocation is not supported by your browser');
      setIsCapturingGeoTag(false);
    }
  };

  const handleSubmitDispute = (orderId: string) => {
    if (!disputeReason.trim()) {
      alert('Please describe the problem');
      return;
    }
    if (!disputePhoto) {
      alert('Please take a photo of the received items');
      return;
    }
    
    // Find the order and open chat with seller in dispute mode
    const order = mockOrders.find(o => o.id === orderId);
    if (order) {
      // Store dispute info in the order (in real app, would save to backend)
      order.disputeReason = disputeReason;
      order.disputePhoto = disputePhoto;
      
      setShowDisputeModal(null);
      setChatWithOrder(order);
      // Reset form
      setDisputeReason('');
      setDisputePhoto(null);
    }
  };

  const handleRefundDispute = (orderId: string) => {
    if (confirm('Are you sure you want to refund this order? Points will not be deducted from the buyer.')) {
      alert('Refund processed. Points will not be transferred.');
    }
  };

  const handleResolveDispute = (orderId: string) => {
    if (confirm('Are you sure the issue has been resolved? Points will be transferred to the seller.')) {
      alert('Dispute marked as resolved. Points have been transferred.');
    }
  };

  const handleEscalateToAdmin = (orderId: string) => {
    if (confirm('Are you sure you want to escalate this to CasaGrown admin for arbitration?')) {
      alert('Dispute escalated to CasaGrown admin. You will be notified of the decision.');
    }
  };

  const handleCancelOrder = (orderId: string) => {
    // Find the order
    const order = mockOrders.find(o => o.id === orderId);
    if (!order) return;
    
    // Check if cancellation is allowed
    if (order.dropoffCompletedAt) {
      alert('Cannot cancel order - seller has already delivered. Please use the dispute option if there\'s an issue.');
      return;
    }
    
    // Open cancel modal
    setShowCancelModal(orderId);
  };

  const handleConfirmCancel = () => {
    if (!showCancelModal) return;
    
    const order = mockOrders.find(o => o.id === showCancelModal);
    if (order) {
      // In real app, would update backend
      alert(`Order cancelled successfully. ${order.type === 'buy' ? order.otherParty : 'Buyer'} will be notified. Points will be refunded.`);
      
      setShowCancelModal(null);
      setCancellationReason('');
    }
  };

  const formatTimestamp = (date: Date) => {
    const now = new Date().getTime();
    const timestamp = date.getTime();
    const diff = now - timestamp;
    
    const minutes = Math.floor(diff / (60 * 1000));
    const hours = Math.floor(diff / (60 * 60 * 1000));
    const days = Math.floor(diff / (24 * 60 * 60 * 1000));
    
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  const getTimeRemaining = (dropoffTime: Date) => {
    const now = new Date().getTime();
    const dropoff = dropoffTime.getTime();
    const fourHours = 4 * 60 * 60 * 1000;
    const disputeDeadline = dropoff + fourHours;
    const remaining = disputeDeadline - now;
    
    if (remaining <= 0) return 'Dispute period ended';
    
    const hours = Math.floor(remaining / (60 * 60 * 1000));
    const minutes = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000));
    
    return `${hours}h ${minutes}m to dispute`;
  };

  if (chatWithOrder) {
    // Check if this is a dispute conversation
    const isDispute = !!(chatWithOrder.disputeReason && chatWithOrder.disputePhoto);
    
    return (
      <ChatInterface 
        currentUserId={user.id}
        currentUserName={user.name}
        otherUserId={chatWithOrder.otherPartyId}
        otherUserName={chatWithOrder.otherParty}
        postTitle={chatWithOrder.product}
        postType="sell"
        onClose={() => setChatWithOrder(null)}
        // Dispute mode props
        isDisputeMode={isDispute}
        isBuyerInDispute={chatWithOrder.type === 'buy'}
        dropoffPhoto={chatWithOrder.dropoffPhoto}
        disputePhoto={chatWithOrder.disputePhoto}
        disputeReason={chatWithOrder.disputeReason}
        onResolveDispute={() => {
          handleResolveDispute(chatWithOrder.id);
          setChatWithOrder(null);
        }}
        onRefundDispute={() => {
          handleRefundDispute(chatWithOrder.id);
          setChatWithOrder(null);
        }}
        onEscalateDispute={() => {
          handleEscalateToAdmin(chatWithOrder.id);
          setChatWithOrder(null);
        }}
        // Seller address props
        isCurrentUserSeller={chatWithOrder.type === 'sell'}
        savedAddress={chatWithOrder.pickupLocation || chatWithOrder.dropoffAddress || '123 Garden Lane, Springfield'}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">My Orders</h1>

        {/* Tabs */}
        <div className="flex gap-4 mb-6 border-b border-gray-200">
          <button
            onClick={() => setActiveTab('pending')}
            className={`pb-3 px-4 font-medium transition-colors relative ${
              activeTab === 'pending'
                ? 'text-green-600 border-b-2 border-green-600'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Pending
            {pendingOrders.length > 0 && (
              <span className="ml-2 px-2 py-0.5 bg-orange-100 text-orange-700 rounded-full text-xs font-bold">
                {pendingOrders.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('completed')}
            className={`pb-3 px-4 font-medium transition-colors ${
              activeTab === 'completed'
                ? 'text-green-600 border-b-2 border-green-600'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Completed
          </button>
          <button
            onClick={() => setActiveTab('disputed')}
            className={`pb-3 px-4 font-medium transition-colors relative ${
              activeTab === 'disputed'
                ? 'text-green-600 border-b-2 border-green-600'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Disputed
            {disputedOrders.length > 0 && (
              <span className="ml-2 px-2 py-0.5 bg-red-100 text-red-700 rounded-full text-xs font-bold">
                {disputedOrders.length}
              </span>
            )}
          </button>
        </div>

        {/* Orders List */}
        <div className="space-y-4">
          {activeTab === 'pending' && pendingOrders.length === 0 && (
            <div className="text-center py-12 bg-white rounded-xl">
              <Package className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-600">No pending orders</p>
            </div>
          )}

          {activeTab === 'pending' && pendingOrders.map((order) => (
            <div key={order.id} className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      order.type === 'buy' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'
                    }`}>
                      {order.type === 'buy' ? 'Buying' : 'Selling'}
                    </span>
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      order.fulfillmentMethod === 'pickup' ? 'bg-purple-100 text-purple-700' : 'bg-orange-100 text-orange-700'
                    }`}>
                      {order.fulfillmentMethod === 'pickup' ? 'Pickup' : 'Dropoff'}
                    </span>
                    {order.dropoffCompletedAt && (
                      <span className="px-2 py-1 rounded text-xs font-medium bg-yellow-100 text-yellow-700">
                        {getTimeRemaining(order.dropoffCompletedAt)}
                      </span>
                    )}
                  </div>
                  <h3 className="font-semibold text-gray-900 text-lg">{order.product}</h3>
                  <p className="text-sm text-gray-600">{order.quantity} • {order.category}</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-green-600">{order.price}</div>
                  <div className="text-sm text-gray-500">points</div>
                </div>
              </div>

              <div className="border-t border-gray-100 pt-4 space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-600">
                    {order.type === 'buy' ? 'Seller: ' : 'Buyer: '}
                    <span className="font-medium text-gray-900">{order.otherParty}</span>
                  </span>
                </div>
                
                {/* Seller Acceptance Status */}
                {order.type === 'buy' && order.sellerAccepted === false && (
                  <div className="flex items-center gap-2 text-sm">
                    <AlertCircle className="w-4 h-4 text-orange-500" />
                    <span className="text-orange-700 font-medium">Awaiting Seller Acceptance</span>
                  </div>
                )}
                
                {/* Last Response Timestamp */}
                {order.lastResponseAt && (
                  <div className="flex items-center gap-2 text-sm">
                    <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="text-gray-600">
                      Last activity: <span className="font-medium">{formatTimestamp(order.lastResponseAt)}</span>
                    </span>
                  </div>
                )}
                
                {order.fulfillmentMethod === 'pickup' && order.pickupLocation && (
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-600">{order.pickupLocation}</span>
                  </div>
                )}
                
                {order.fulfillmentMethod === 'dropoff' && order.dropoffAddress && (
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-600">Dropoff: {order.dropoffAddress}</span>
                  </div>
                )}
                
                <div className="flex items-center gap-2 text-sm">
                  <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  <span className="text-gray-600">
                    {order.fulfillmentMethod === 'dropoff' && order.dropoffTimeWindow 
                      ? order.dropoffTimeWindow 
                      : order.pickupDate}
                  </span>
                </div>
              </div>

              {/* Drop-off completed - awaiting buyer confirmation */}
              {order.dropoffCompletedAt && order.type === 'buy' && !order.disputeReason && (
                <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <h4 className="font-medium text-yellow-900 mb-1">Items Delivered</h4>
                      <p className="text-sm text-yellow-700 mb-3">
                        The seller has marked this order as delivered. Please verify and confirm receipt, or dispute if there's an issue.
                      </p>
                      {order.dropoffPhoto && (
                        <img 
                          src={order.dropoffPhoto} 
                          alt="Dropoff verification" 
                          className="w-full h-48 object-cover rounded-lg mb-3"
                        />
                      )}
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleCompleteOrder(order.id)}
                          className="flex-1 px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors text-sm"
                        >
                          Confirm Receipt
                        </button>
                        <button
                          onClick={() => setShowDisputeModal(order.id)}
                          className="flex-1 px-4 py-2 bg-red-600 text-white font-medium rounded-lg hover:bg-red-700 transition-colors text-sm"
                        >
                          Dispute Delivery
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Seller side - Buyer has disputed */}
              {order.disputeReason && order.type === 'sell' && (
                <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <h4 className="font-medium text-red-900 mb-1">Buyer Dispute</h4>
                      <p className="text-sm text-red-700 mb-2">
                        The buyer has raised a concern about this delivery. Click "Chat" below to discuss and resolve the issue.
                      </p>
                      <p className="text-sm text-red-800 font-medium italic">
                        "{order.disputeReason}"
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Action buttons */}
              <div className="mt-4 flex flex-col gap-2">
                <div className="flex gap-3">
                  <button
                    onClick={() => setChatWithOrder(order)}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <MessageCircle className="w-4 h-4" />
                    Chat
                  </button>

                  {/* Seller - Mark as dropped off */}
                  {order.type === 'sell' && order.fulfillmentMethod === 'dropoff' && !order.dropoffCompletedAt && (
                    <button
                      onClick={() => setShowDropoffCapture(order.id)}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-orange-600 text-white font-medium rounded-lg hover:bg-orange-700 transition-colors"
                    >
                      <Camera className="w-4 h-4" />
                      Mark as Dropped Off
                    </button>
                  )}

                  {/* Pickup orders - show passcode */}
                  {order.fulfillmentMethod === 'pickup' && (
                    <>
                      {order.type === 'sell' ? (
                        <button
                          onClick={() => setShowPasscode(order.id)}
                          className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
                        >
                          <QrCode className="w-4 h-4" />
                          Show QR/Passcode
                        </button>
                      ) : (
                        <button
                          onClick={() => setShowVerification(order.id)}
                          className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
                        >
                          <Scan className="w-4 h-4" />
                          Verify Pickup
                        </button>
                      )}
                    </>
                  )}
                </div>
                
                {/* Cancel Order Button - shown only if delivery hasn't been completed yet */}
                {!order.dropoffCompletedAt && (
                  <button
                    onClick={() => handleCancelOrder(order.id)}
                    className="w-full px-4 py-2 border-2 border-red-500 text-red-600 font-medium rounded-lg hover:bg-red-50 transition-colors text-sm"
                  >
                    <X className="w-4 h-4 inline mr-1" />
                    Cancel Order
                  </button>
                )}
              </div>
            </div>
          ))}

          {activeTab === 'completed' && completedOrders.map((order) => (
            <div key={order.id} className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      order.type === 'buy' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'
                    }`}>
                      {order.type === 'buy' ? 'Bought' : 'Sold'}
                    </span>
                    <CheckCircle className="w-4 h-4 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 text-lg">{order.product}</h3>
                  <p className="text-sm text-gray-600">{order.quantity} • {order.category}</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-gray-900">{order.price}</div>
                  <div className="text-sm text-gray-500">points</div>
                </div>
              </div>

              {order.rating && (
                <div className="flex items-center gap-1 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < order.rating! ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
              )}

              {!order.rating && (
                <button
                  onClick={() => setShowRating(order.id)}
                  className="mt-2 px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors"
                >
                  Rate {order.type === 'buy' ? 'Seller' : 'Buyer'}
                </button>
              )}
            </div>
          ))}

          {activeTab === 'disputed' && disputedOrders.length === 0 && (
            <div className="text-center py-12 bg-white rounded-xl">
              <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-600">No disputed orders</p>
            </div>
          )}
        </div>

        {/* Dropoff Photo Capture Modal */}
        {showDropoffCapture && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-2xl max-w-md w-full p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-gray-900">Confirm Dropoff</h3>
                <button
                  onClick={() => {
                    setShowDropoffCapture(null);
                    setDropoffPhoto(null);
                  }}
                  className="p-1 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>

              <p className="text-sm text-gray-600 mb-4">
                Take a photo of the items at the dropoff location. Your location will be captured automatically.
              </p>

              {!dropoffPhoto ? (
                <label className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-green-500 hover:bg-green-50 transition-all">
                  <Camera className="w-12 h-12 text-gray-400 mb-3" />
                  <span className="text-sm font-medium text-gray-700">Take Photo</span>
                  <input
                    type="file"
                    accept="image/*"
                    capture="environment"
                    className="hidden"
                    onChange={(e) => handleDropoffPhotoCapture(e.target.files?.[0] || null)}
                  />
                </label>
              ) : (
                <div className="mb-4">
                  <img src={dropoffPhoto} alt="Dropoff" className="w-full h-64 object-cover rounded-lg mb-2" />
                  <button
                    onClick={() => setDropoffPhoto(null)}
                    className="text-sm text-blue-600 hover:text-blue-700"
                  >
                    Retake Photo
                  </button>
                </div>
              )}

              <button
                onClick={() => handleConfirmDropoff(showDropoffCapture)}
                disabled={!dropoffPhoto || isCapturingGeoTag}
                className="w-full mt-4 px-4 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
              >
                {isCapturingGeoTag ? 'Capturing Location...' : 'Confirm Dropoff'}
              </button>
            </div>
          </div>
        )}

        {/* Dispute Modal */}
        {showDisputeModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-2xl max-w-md w-full p-6 max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-gray-900">Dispute Delivery</h3>
                <button
                  onClick={() => {
                    setShowDisputeModal(null);
                    setDisputeReason('');
                    setDisputePhoto(null);
                  }}
                  className="p-1 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>

              <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 mb-4">
                <p className="text-sm text-orange-800">
                  <strong>Note:</strong> A dispute will be opened with the seller via chat. Take a photo of the items as received and describe the issue.
                </p>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Describe the Problem <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={disputeReason}
                  onChange={(e) => setDisputeReason(e.target.value)}
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
                  placeholder="e.g., Items are damaged, wrong quantity, quality doesn't match description..."
                />
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Photo Evidence <span className="text-red-500">*</span>
                </label>
                {!disputePhoto ? (
                  <label className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-red-500 hover:bg-red-50 transition-all">
                    <Camera className="w-8 h-8 text-gray-400 mb-2" />
                    <span className="text-sm font-medium text-gray-700">Take Photo of Items</span>
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      className="hidden"
                      onChange={(e) => handleDisputePhotoCapture(e.target.files?.[0] || null)}
                    />
                  </label>
                ) : (
                  <div>
                    <img src={disputePhoto} alt="Dispute evidence" className="w-full h-48 object-cover rounded-lg mb-2" />
                    <button
                      onClick={() => setDisputePhoto(null)}
                      className="text-sm text-blue-600 hover:text-blue-700"
                    >
                      Retake Photo
                    </button>
                  </div>
                )}
              </div>

              <button
                onClick={() => handleSubmitDispute(showDisputeModal)}
                disabled={!disputeReason.trim() || !disputePhoto}
                className="w-full px-4 py-3 bg-red-600 text-white font-medium rounded-lg hover:bg-red-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
              >
                Submit Dispute
              </button>
            </div>
          </div>
        )}

        {/* Rating Modal */}
        {showRating && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-2xl max-w-md w-full p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Rate Transaction</h3>
              
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  How was your experience?
                </label>
                <div className="flex justify-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => setSelectedRating(star)}
                      className="transition-transform hover:scale-110"
                    >
                      <Star
                        className={`w-10 h-10 ${
                          star <= selectedRating
                            ? 'fill-yellow-400 text-yellow-400'
                            : 'text-gray-300'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Comments (optional)
                </label>
                <textarea
                  value={ratingComment}
                  onChange={(e) => setRatingComment(e.target.value)}
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
                  placeholder="Share your experience..."
                />
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowRating(null);
                    setSelectedRating(0);
                    setRatingComment('');
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSubmitRating}
                  disabled={selectedRating === 0}
                  className="flex-1 px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
                >
                  Submit Rating
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Passcode/QR Modal */}
        {showPasscode && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-2xl max-w-md w-full p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Pickup Verification</h3>
              <p className="text-gray-600 mb-6">
                Share this code with the buyer to complete the transaction
              </p>
              
              <div className="bg-green-50 border-2 border-green-500 rounded-xl p-8 text-center mb-6">
                <div className="text-5xl font-bold text-green-600 tracking-wider mb-2">
                  {mockOrders.find(o => o.id === showPasscode)?.passcode}
                </div>
                <div className="text-sm text-gray-600">Verification Code</div>
              </div>

              <button
                onClick={() => setShowPasscode(null)}
                className="w-full px-4 py-2 bg-gray-100 text-gray-700 font-medium rounded-lg hover:bg-gray-200 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        )}

        {/* Verification Modal (Buyer) */}
        {showVerification && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-2xl max-w-md w-full p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Verify Pickup</h3>
              <p className="text-gray-600 mb-6">
                Enter the verification code provided by the seller
              </p>
              
              <input
                type="text"
                value={manualPasscode}
                onChange={(e) => setManualPasscode(e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg text-center text-2xl font-bold tracking-wider mb-6 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="0000"
                maxLength={4}
              />

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowVerification(null);
                    setManualPasscode('');
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    const order = mockOrders.find(o => o.id === showVerification);
                    if (order && manualPasscode === order.passcode) {
                      handleCompleteOrder(showVerification);
                    } else {
                      alert('Invalid code. Please try again.');
                    }
                  }}
                  disabled={manualPasscode.length !== 4}
                  className="flex-1 px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
                >
                  Verify
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* Cancel Order Modal */}
        {showCancelModal && (() => {
          const order = mockOrders.find(o => o.id === showCancelModal);
          if (!order) return null;
          
          return (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
              <div className="bg-white rounded-2xl max-w-md w-full p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Cancel Order</h3>
                <p className="text-gray-600 mb-4">
                  Are you sure you want to cancel your order for <span className="font-semibold">{order.product}</span>?
                </p>
                
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4">
                  <p className="text-sm text-yellow-800">
                    <strong>Note:</strong> {order.type === 'buy' ? order.otherParty : 'The buyer'} will be notified of the cancellation. Your points will be refunded immediately.
                  </p>
                </div>
                
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Reason for cancellation (optional)
                  </label>
                  <textarea
                    value={cancellationReason}
                    onChange={(e) => setCancellationReason(e.target.value)}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
                    placeholder="e.g., No longer needed, found alternative, seller not responding..."
                  />
                </div>
                
                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      setShowCancelModal(null);
                      setCancellationReason('');
                    }}
                    className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Keep Order
                  </button>
                  <button
                    onClick={handleConfirmCancel}
                    className="flex-1 px-4 py-2 bg-red-600 text-white font-medium rounded-lg hover:bg-red-700 transition-colors"
                  >
                    Confirm Cancel
                  </button>
                </div>
              </div>
            </div>
          );
        })()}
      </div>
    </div>
  );
}