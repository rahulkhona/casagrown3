import React from 'react';
import logoImage from 'figma:asset/3ac37b0699e9d282cf5693465931b5a50117a050.png';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  onClick?: () => void;
}

export default function Logo({ size = 'md', showText = true, onClick }: LogoProps) {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-16 h-16'
  };

  const textSizeClasses = {
    sm: 'text-lg',
    md: 'text-xl',
    lg: 'text-2xl'
  };

  const className = `flex items-center gap-2 ${onClick ? 'cursor-pointer hover:opacity-80 transition-opacity' : ''}`;

  return (
    <div 
      className={className}
      onClick={onClick}
    >
      <img 
        src={logoImage}
        alt="CasaGrown Logo"
        className={`${sizeClasses[size]} object-contain`}
      />
      {showText && (
        <span className={`font-bold text-gray-900 ${textSizeClasses[size]}`}>CasaGrown</span>
      )}
    </div>
  );
}
