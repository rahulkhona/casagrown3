import React from 'react';
import { CreditCard, Building2, AlertCircle } from 'lucide-react';

// Service fee configuration
const PAYMENT_FEES = {
  creditCard: { type: 'percentage', value: 0.03, label: '3% processing fee' },
  ach: { type: 'flat', value: 1.00, label: '$1.00 processing fee' }
};

interface BuyPointsModalProps {
  userPoints: number;
  pointsToBuy: string;
  setPointsToBuy: (value: string) => void;
  paymentMethod: 'creditCard' | 'ach' | null;
  setPaymentMethod: (value: 'creditCard' | 'ach' | null) => void;
  cardNumber: string;
  setCardNumber: (value: string) => void;
  cardExpiry: string;
  setCardExpiry: (value: string) => void;
  cardCvv: string;
  setCardCvv: (value: string) => void;
  billingZip: string;
  setBillingZip: (value: string) => void;
  routingNumber: string;
  setRoutingNumber: (value: string) => void;
  accountNumber: string;
  setAccountNumber: (value: string) => void;
  accountType: 'checking' | 'savings';
  setAccountType: (value: 'checking' | 'savings') => void;
  errorMessage: string;
  onCancel: () => void;
  onPurchase: () => void;
}

export function BuyPointsModal({
  userPoints,
  pointsToBuy,
  setPointsToBuy,
  paymentMethod,
  setPaymentMethod,
  cardNumber,
  setCardNumber,
  cardExpiry,
  setCardExpiry,
  cardCvv,
  setCardCvv,
  billingZip,
  setBillingZip,
  routingNumber,
  setRoutingNumber,
  accountNumber,
  setAccountNumber,
  accountType,
  setAccountType,
  errorMessage,
  onCancel,
  onPurchase
}: BuyPointsModalProps) {
  const calculateCosts = () => {
    const pointsNum = parseInt(pointsToBuy) || 0;
    const baseAmount = pointsNum * 0.10;
    const totalAmount = baseAmount; // No fees
    
    return { baseAmount, totalAmount };
  };

  const { baseAmount, totalAmount } = calculateCosts();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 my-8 max-h-[90vh] overflow-y-auto">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Buy Points</h3>
        <p className="text-gray-600 mb-6">
          Add more points to your account to complete transactions.
        </p>

        <div className="space-y-6">
          {/* Points Amount */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Points to Purchase
            </label>
            <input
              type="number"
              value={pointsToBuy}
              onChange={(e) => setPointsToBuy(e.target.value)}
              className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="Enter amount"
              min="1"
            />
            <p className="text-sm text-gray-600 mt-2">
              Buy minimum 100 points to keep credit card fees low
            </p>
          </div>

          {/* Payment Method Selection */}
          <div>
            <h4 className="text-lg font-semibold text-gray-900 mb-3">Select Payment Method</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
              {/* Credit Card Option */}
              <button
                type="button"
                onClick={() => setPaymentMethod('creditCard')}
                className={`p-4 border-2 rounded-xl transition-all text-left ${
                  paymentMethod === 'creditCard'
                    ? 'border-green-600 bg-green-50'
                    : 'border-gray-200 hover:border-green-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                    <CreditCard className="w-4 h-4 text-blue-600" />
                  </div>
                  <div className="font-semibold text-gray-900">Credit Card</div>
                </div>
              </button>

              {/* ACH Option */}
              <button
                type="button"
                onClick={() => setPaymentMethod('ach')}
                className={`p-4 border-2 rounded-xl transition-all text-left ${
                  paymentMethod === 'ach'
                    ? 'border-green-600 bg-green-50'
                    : 'border-gray-200 hover:border-green-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                    <Building2 className="w-4 h-4 text-purple-600" />
                  </div>
                  <div className="font-semibold text-gray-900">Bank Transfer (ACH)</div>
                </div>
              </button>
            </div>

            {/* Credit Card Form */}
            {paymentMethod === 'creditCard' && (
              <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                <h5 className="font-semibold text-gray-900">Credit Card Information</h5>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Card Number
                  </label>
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\s/g, '');
                      if (/^\d*$/.test(value) && value.length <= 16) {
                        setCardNumber(value.replace(/(\d{4})/g, '$1 ').trim());
                      }
                    }}
                    placeholder="1234 5678 9012 3456"
                    maxLength={19}
                    className="w-full px-3 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Expiry
                    </label>
                    <input
                      type="text"
                      value={cardExpiry}
                      onChange={(e) => {
                        let value = e.target.value.replace(/\D/g, '');
                        if (value.length >= 2) {
                          value = value.slice(0, 2) + '/' + value.slice(2, 4);
                        }
                        if (value.length <= 5) {
                          setCardExpiry(value);
                        }
                      }}
                      placeholder="MM/YY"
                      maxLength={5}
                      className="w-full px-3 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      CVV
                    </label>
                    <input
                      type="text"
                      value={cardCvv}
                      onChange={(e) => {
                        const value = e.target.value.replace(/\D/g, '');
                        if (value.length <= 3) {
                          setCardCvv(value);
                        }
                      }}
                      placeholder="123"
                      maxLength={3}
                      className="w-full px-3 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      ZIP Code
                    </label>
                    <input
                      type="text"
                      value={billingZip}
                      onChange={(e) => {
                        const value = e.target.value.replace(/\D/g, '');
                        if (value.length <= 5) {
                          setBillingZip(value);
                        }
                      }}
                      placeholder="12345"
                      maxLength={5}
                      className="w-full px-3 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* ACH Form */}
            {paymentMethod === 'ach' && (
              <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                <h5 className="font-semibold text-gray-900">Bank Account Information</h5>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Routing Number
                  </label>
                  <input
                    type="text"
                    value={routingNumber}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, '');
                      if (value.length <= 9) {
                        setRoutingNumber(value);
                      }
                    }}
                    placeholder="123456789"
                    maxLength={9}
                    className="w-full px-3 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Account Number
                  </label>
                  <input
                    type="text"
                    value={accountNumber}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, '');
                      if (value.length <= 17) {
                        setAccountNumber(value);
                      }
                    }}
                    placeholder="Account number"
                    maxLength={17}
                    className="w-full px-3 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Account Type
                  </label>
                  <select
                    value={accountType}
                    onChange={(e) => setAccountType(e.target.value as 'checking' | 'savings')}
                    className="w-full px-3 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="checking">Checking</option>
                    <option value="savings">Savings</option>
                  </select>
                </div>
              </div>
            )}
          </div>

          {/* Cost Breakdown */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h5 className="font-semibold text-gray-900 mb-3">Cost Breakdown</h5>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-gray-700">
                <span>{parseInt(pointsToBuy) || 0} points × $0.10</span>
                <span className="font-medium">${baseAmount.toFixed(2)}</span>
              </div>
              <div className="pt-2 border-t-2 border-blue-300">
                <div className="flex items-center justify-between">
                  <span className="text-lg font-semibold text-gray-900">Total Amount</span>
                  <span className="text-2xl font-bold text-gray-900">
                    ${totalAmount.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Points Summary */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h5 className="font-semibold text-gray-900 mb-3">Points Summary</h5>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-gray-700">Current Points</span>
                <span className="font-semibold text-gray-900">{userPoints}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-700">Points to Add</span>
                <span className="font-semibold text-gray-900">{parseInt(pointsToBuy) || 0}</span>
              </div>
              <div className="pt-2 border-t border-gray-300">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-gray-900">New Balance</span>
                  <span className="font-bold text-xl text-green-600">
                    {userPoints + (parseInt(pointsToBuy) || 0)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3">
              <p className="text-sm text-red-800">{errorMessage}</p>
            </div>
          )}

          {/* Buttons */}
          <div className="flex gap-3">
            <button
              onClick={onCancel}
              className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={onPurchase}
              disabled={!pointsToBuy || parseInt(pointsToBuy) <= 0 || !paymentMethod}
              className="flex-1 px-4 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
            >
              <span className="flex items-center justify-center gap-2">
                <CreditCard className="w-5 h-5" />
                Complete Purchase
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}