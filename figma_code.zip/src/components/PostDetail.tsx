import React, { useState, useEffect } from 'react';
import { ArrowLeft, Heart, Flag, Share2, MessageCircle, ShoppingCart, MapPin, Calendar, User, Plus, Check, CreditCard, Building2, AlertCircle, X } from 'lucide-react';
import ChatInterface from './ChatInterface';
import { BuyPointsModal } from './BuyPointsModal';
import AddressInput from './AddressInput';

// Service fee configuration
const PAYMENT_FEES = {
  creditCard: { type: 'percentage', value: 0.03, label: '3% processing fee' },
  ach: { type: 'flat', value: 1.00, label: '$1.00 processing fee' }
};

interface User {
  id: string;
  name: string;
  points: number;
}

interface PostDetailProps {
  user: User;
  postId: string;
  onBack: () => void;
  updateUserPoints: (points: number) => void;
  onCreatePost?: (postType?: 'sell' | 'buy' | 'service-request' | 'service-offer' | 'advice') => void;
}

interface Comment {
  id: string;
  authorName: string;
  authorPhoto?: string;
  content: string;
  createdAt: Date;
}

interface UserPost {
  id: string;
  title: string;
  description: string;
  price: number;
  category: string;
  imageUrl?: string;
}

export default function PostDetail({ user, postId, onBack, updateUserPoints, onCreatePost }: PostDetailProps) {
  const [showChatInterface, setShowChatInterface] = useState(false);
  const [showOfferModal, setShowOfferModal] = useState(false);
  const [showInsufficientPointsModal, setShowInsufficientPointsModal] = useState(false);
  const [showBuyPointsModal, setShowBuyPointsModal] = useState(false);
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [quantity, setQuantity] = useState('');
  const [quantityUnit, setQuantityUnit] = useState('lbs');
  const [pickupLocation, setPickupLocation] = useState('');
  const [pickupDate, setPickupDate] = useState('');
  const [pickupTime, setPickupTime] = useState('');
  const [offerPrice, setOfferPrice] = useState('');
  const [isLiked, setIsLiked] = useState(false);
  const [selectedPosts, setSelectedPosts] = useState<string[]>([]);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [successMessage, setSuccessMessage] = useState({ title: '', body: '' });
  const [errorMessage, setErrorMessage] = useState('');
  const [pointsToBuy, setPointsToBuy] = useState('100');
  const [showFlagModal, setShowFlagModal] = useState(false);
  const [flagReason, setFlagReason] = useState('');
  const [flagCategory, setFlagCategory] = useState<string>('');
  
  // Payment method states for Buy Points modal
  const [paymentMethod, setPaymentMethod] = useState<'creditCard' | 'ach' | null>(null);
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [billingZip, setBillingZip] = useState('');
  const [routingNumber, setRoutingNumber] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountType, setAccountType] = useState<'checking' | 'savings'>('checking');
  
  // Payment method states for transaction checkout
  const [transactionPaymentMethod, setTransactionPaymentMethod] = useState<'creditCard' | 'ach' | null>(null);
  const [transactionCardNumber, setTransactionCardNumber] = useState('');
  const [transactionCardExpiry, setTransactionCardExpiry] = useState('');
  const [transactionCardCvv, setTransactionCardCvv] = useState('');
  const [transactionBillingZip, setTransactionBillingZip] = useState('');
  const [transactionRoutingNumber, setTransactionRoutingNumber] = useState('');
  const [transactionAccountNumber, setTransactionAccountNumber] = useState('');
  const [transactionAccountType, setTransactionAccountType] = useState<'checking' | 'savings'>('checking');
  
  // Drop-off related states
  const [fulfillmentMethod, setFulfillmentMethod] = useState<'dropoff' | 'pickup' | 'meetup' | 'selfharvest'>('dropoff');
  const [dropoffAddress, setDropoffAddress] = useState('');
  const [dropoffTimeWindow, setDropoffTimeWindow] = useState('');
  const [dropoffLatestDate, setDropoffLatestDate] = useState('');
  const [meetupLocation, setMeetupLocation] = useState('');
  const [meetupDate, setMeetupDate] = useState('');
  const [meetupTime, setMeetupTime] = useState('');
  const [selfHarvestDate, setSelfHarvestDate] = useState('');
  const [selfHarvestTime, setSelfHarvestTime] = useState('');
  const [sellerAddressConfirmed, setSellerAddressConfirmed] = useState(false);
  const [showSellerAddressModal, setShowSellerAddressModal] = useState(false);
  const [sellerAddress, setSellerAddress] = useState('123 Garden Lane, Springfield');
  const [buyAgreementDetails, setBuyAgreementDetails] = useState('');
  const [sellerHasAgreed, setSellerHasAgreed] = useState(false);
  
  // Drop-off request modal states
  const [showDropoffRequestModal, setShowDropoffRequestModal] = useState(false);
  const [dropoffRequestQuantity, setDropoffRequestQuantity] = useState('');
  const [dropoffRequestAddress, setDropoffRequestAddress] = useState('');
  const [dropoffRequestDate, setDropoffRequestDate] = useState('');
  const [dropoffRequestLatestDate, setDropoffRequestLatestDate] = useState('');
  const [dropoffRequestPreferredDates, setDropoffRequestPreferredDates] = useState<string[]>([]);
  const [tempDropoffDate, setTempDropoffDate] = useState('');
  
  // Mock posts data - this would come from a database based on postId
  const mockPosts: Record<string, any> = {
    '1': {
      id: '1',
      type: 'sell',
      authorId: '2',
      authorName: 'Sarah Johnson',
      authorPhoto: undefined,
      community: 'Lincoln High School Community',
      category: 'Vegetables',
      title: 'Fresh Organic Tomatoes',
      description: 'Just harvested! 5 lbs of fresh organic heirloom tomatoes from my backyard garden. These are completely organic, no pesticides used. Perfect for salads, sauces, or just eating fresh!',
      price: 50,
      unit: 'lbs',
      imageUrl: 'https://images.unsplash.com/photo-1645931413394-01bd95d294ca?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGdhcmRlbiUyMHZlZ2V0YWJsZXMlMjB0b21hdG9lc3xlbnwxfHx8fDE3Njk0OTQ0OTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      likes: 12,
      pickupDays: ['Monday', 'Tuesday', 'Wednesday', 'Friday'],
      pickupTime: '9 AM - 6 PM',
      allowsDropoff: true,
      fulfillmentOptions: {
        canDropoff: true,
        allowPickup: true,
        canMeetNearby: true,
        allowSelfHarvest: false,
        dropoffDates: ['2026-02-01', '2026-02-03', '2026-02-05'],
        pickupAvailability: [
          { date: '2026-01-30', timeRange: '9 AM - 12 PM' },
          { date: '2026-01-31', timeRange: '2 PM - 6 PM' },
          { date: '2026-02-02', timeRange: '9 AM - 6 PM' },
          { date: '2026-02-04', timeRange: '10 AM - 4 PM' }
        ],
        meetNearbyAvailability: [
          { date: '2026-02-01', timeRange: '11 AM - 1 PM' },
          { date: '2026-02-03', timeRange: '3 PM - 5 PM' }
        ],
        selfHarvestAvailability: []
      }
    },
    '2': {
      id: '2',
      type: 'buy',
      authorId: '3',
      authorName: 'Michael Chen',
      community: 'Washington High School Community',
      category: 'Fruits',
      title: 'Looking for Fresh Strawberries',
      description: 'Anyone have fresh strawberries available? Need about 2-3 lbs for a family gathering this weekend. Willing to pay up to 40 points.',
      price: 40,
      imageUrl: 'https://images.unsplash.com/photo-1629905707362-03cf1a9f6e2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHBpY2tlZCUyMGZydWl0cyUyMGJhc2tldHxlbnwxfHx8fDE3Njk0OTQ0OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
      likes: 8
    },
    '3': {
      id: '3',
      type: 'sell',
      authorId: '4',
      authorName: 'David Martinez',
      authorPhoto: undefined,
      community: 'Lincoln High School Community',
      category: 'Equipment',
      title: 'Premium Garden Tool Set',
      description: 'Professional grade garden tool set including spade, hoe, rake, and pruning shears. Barely used, excellent condition. Perfect for serious gardeners!',
      price: 150,
      imageUrl: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYXJkZW4lMjB0b29scyUyMHNldHxlbnwxfHx8fDE3Njk0OTQ0OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
      likes: 15,
      pickupDays: ['Saturday', 'Sunday'],
      pickupTime: '10 AM - 4 PM',
      fulfillmentOptions: {
        canDropoff: false,
        allowPickup: true,
        canMeetNearby: false,
        allowSelfHarvest: true,
        dropoffDates: [],
        pickupAvailability: [
          { date: '2026-02-01', timeRange: '10 AM - 12 PM' },
          { date: '2026-02-02', timeRange: '2 PM - 4 PM' }
        ],
        meetNearbyAvailability: [],
        selfHarvestAvailability: [
          { date: '2026-02-01', timeRange: '1 PM - 3 PM' },
          { date: '2026-02-03', timeRange: '10 AM - 2 PM' }
        ]
      }
    },
    'intro-2': {
      id: 'intro-2',
      type: 'show-tell',
      authorId: '2',
      authorName: 'Sarah Johnson',
      authorPhoto: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400',
      authorRating: 5.0,
      authorTotalReviews: 47,
      community: 'Lincoln High School Community',
      category: 'Introduction',
      title: 'Hello from a Tomato Lover! 🍅',
      description: 'Hi neighbors! I\'m Sarah and I\'ve been growing organic vegetables for over a decade. Started with just a few pots on my balcony and now have a full backyard garden!\n\nI specialize in heirloom tomatoes (I have over 15 varieties!), fresh herbs, and I\'m passionate about composting. I believe in completely organic practices and love sharing what I learn.\n\nLooking forward to connecting with all of you, sharing my harvest, and learning from this amazing community. Feel free to reach out if you have any questions about organic gardening or composting!\n\nHappy growing! 🌱',
      imageUrl: 'https://images.unsplash.com/photo-1592841200221-a6898f307baa?w=800',
      videoUrl: undefined,
      createdAt: new Date('2024-01-16'),
      likes: 34
    },
    'intro-4': {
      id: 'intro-4',
      type: 'show-tell',
      authorId: '4',
      authorName: 'David Martinez',
      authorPhoto: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400',
      authorRating: 4.9,
      authorTotalReviews: 23,
      community: 'Lincoln High School Community',
      category: 'Introduction',
      title: 'Former Landscaper Here to Help!',
      description: 'Hello everyone! After 30 years in professional landscaping, I recently retired and I\'m loving every minute of it. Now I spend my time working on my own garden and helping neighbors with theirs.\n\nMy specialties include:\n- Garden design and landscaping\n- Fruit tree care and pruning\n- Equipment maintenance and repair\n- Sustainable gardening practices\n\nI have a full workshop of professional tools that I\'m happy to lend out to community members. I also offer consultation services for anyone planning a garden renovation or dealing with tricky landscaping challenges.\n\nExcited to be part of this community and share my knowledge!',
      imageUrl: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800',
      videoUrl: undefined,
      createdAt: new Date('2024-02-21'),
      likes: 28
    },
    'intro-5': {
      id: 'intro-5',
      type: 'show-tell',
      authorId: '5',
      authorName: 'Jessica Martinez',
      authorPhoto: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400',
      authorRating: 4.8,
      authorTotalReviews: 31,
      community: 'Lincoln High School Community',
      category: 'Introduction',
      title: 'Teen Entrepreneur Ready to Help! 💪',
      description: 'Hi everyone! I\'m Jessica, a junior at Lincoln High, and I\'m building my lawn care and gardening business to save up for college.\n\nServices I offer:\n- Lawn mowing and edging\n- Weeding and garden maintenance\n- Yard cleanup and debris removal\n- Planting assistance\n- Basic landscaping\n\nI love working outdoors and take pride in every job I do. My rates are affordable and I\'m always reliable. Plus, I\'m learning so much from all the experienced gardeners in this community!\n\nIf you need help with your yard or garden, please reach out. References available upon request!\n\n#TeenEntrepreneur #LawnCare #CommunityService',
      imageUrl: 'https://images.unsplash.com/photo-1558904541-efa843a96f01?w=800',
      videoUrl: undefined,
      createdAt: new Date('2024-03-11'),
      likes: 42
    },
    'intro-8': {
      id: 'intro-8',
      type: 'show-tell',
      authorId: '8',
      authorName: 'Amanda Rodriguez',
      authorPhoto: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=400',
      authorRating: 4.5,
      authorTotalReviews: 8,
      community: 'Lincoln High School Community',
      category: 'Introduction',
      title: 'New Gardener, Excited to Learn! 🌱',
      description: 'Hello neighbors! I just moved to the area a few months ago and decided to try my hand at gardening for the first time. This community has been SO welcoming and helpful - thank you all!\n\nI started with just cucumbers (they\'re supposed to be easy, right? 😅) and I\'m amazed that they\'re actually growing! I\'m also trying my hand at container gardening with some herbs.\n\nI\'m still learning the basics, but I love:\n- Taking photos of my garden progress\n- Learning from experienced gardeners\n- Sharing my small victories (and mistakes!)\n- Being part of this sustainable community\n\nIf you have any beginner tips or encouragement, I\'m all ears! And if you need someone to photograph your beautiful garden, I\'m your person! 📸\n\nThank you for making me feel so welcome!',
      imageUrl: 'https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?w=800',
      videoUrl: undefined,
      createdAt: new Date('2024-04-02'),
      likes: 51
    }
  };

  const post = mockPosts[postId] || mockPosts['1'];

  // Auto-set unit from post and calculate offer price based on quantity
  useEffect(() => {
    if (post.unit && post.type === 'sell') {
      setQuantityUnit(post.unit);
    }
  }, [post.unit, post.type]);

  // Auto-calculate offer price when quantity changes
  useEffect(() => {
    if (post.type === 'sell' && post.price) {
      if (quantity) {
        const quantityNum = parseFloat(quantity);
        if (!isNaN(quantityNum) && quantityNum > 0) {
          const calculatedPrice = Math.round(post.price * quantityNum);
          setOfferPrice(calculatedPrice.toString());
        } else {
          setOfferPrice('');
        }
      } else {
        setOfferPrice('');
      }
    }
  }, [quantity, post.type, post.price]);

  // Mock user's existing posts that could match buy requests
  const userPosts: UserPost[] = [
    {
      id: 'up1',
      title: 'Fresh Strawberries - Just Picked',
      description: '3 lbs of organic strawberries from my garden',
      price: 35,
      category: 'Fruits',
      imageUrl: 'https://images.unsplash.com/photo-1629905707362-03cf1a9f6e2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHBpY2tlZCUyMGZydWl0cyUyMGJhc2tldHxlbnwxfHx8fDE3Njk0OTQ0OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080'
    },
    {
      id: 'up2',
      title: 'Organic Strawberry Harvest',
      description: '5 lbs available, freshly picked this morning',
      price: 45,
      category: 'Fruits',
      imageUrl: 'https://images.unsplash.com/photo-1629905707362-03cf1a9f6e2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHBpY2tlZCUyMGZydWl0cyUyMGJhc2tldHxlbnwxfHx8fDE3Njk0OTQ0OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080'
    }
  ];

  const [comments, setComments] = useState<Comment[]>(
    post.type === 'sell' ? [] : [
      {
        id: '1',
        authorName: 'Mike Chen',
        content: 'These look amazing! Are they still available?',
        createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000)
      },
      {
        id: '2',
        authorName: 'Lisa Wong',
        content: 'Great price! Picked some up yesterday and they were delicious!',
        createdAt: new Date(Date.now() - 30 * 60 * 60 * 1000)
      }
    ]
  );

  const handleBuy = () => {
    if (user.points < post.price) {
      alert('Not enough points! Please buy more points.');
      return;
    }
    if (!quantity || !pickupLocation || !pickupDate) {
      alert('Please fill in all fields');
      return;
    }
    // Process purchase
    updateUserPoints(user.points - post.price);
    alert('Purchase successful! Check your orders page.');
    setShowBuyModal(false);
    onBack();
  };

  const handleSharePosts = () => {
    if (selectedPosts.length === 0) {
      alert('Please select at least one post to share');
      return;
    }
    setShowSuccessModal(true);
    // Auto-close and navigate back after 2 seconds
    setTimeout(() => {
      setShowSuccessModal(false);
      onBack();
    }, 2000);
  };

  const handleMakeOffer = () => {
    setShowChatInterface(false);
    // Only pre-fill offer price if it's not already set
    // If quantity is set, calculate based on quantity, otherwise use listing price
    if (!offerPrice) {
      if (quantity && post.price) {
        const quantityNum = parseFloat(quantity);
        if (!isNaN(quantityNum) && quantityNum > 0) {
          const calculatedPrice = Math.round(post.price * quantityNum);
          setOfferPrice(calculatedPrice.toString());
        } else {
          setOfferPrice(post.price.toString());
        }
      } else {
        setOfferPrice(post.price.toString());
      }
    }
    setShowOfferModal(true);
  };

  const handleSubmitOffer = () => {
    // Clear previous errors
    setErrorMessage('');

    // Validate common fields
    if (!quantity || !offerPrice) {
      setErrorMessage('Please fill in all required fields');
      return;
    }

    // Validate based on fulfillment method
    if (fulfillmentMethod === 'pickup') {
      if (!sellerAddressConfirmed || !pickupDate || !pickupTime) {
        setErrorMessage('Please confirm seller address and fill in all pickup details');
        return;
      }
    } else if (fulfillmentMethod === 'dropoff') {
      if (!dropoffAddress || !dropoffLatestDate) {
        setErrorMessage('Please fill in all dropoff details');
        return;
      }
    } else if (fulfillmentMethod === 'meetup') {
      if (!meetupLocation || !meetupDate || !meetupTime) {
        setErrorMessage('Please fill in all meeting details');
        return;
      }
    } else if (fulfillmentMethod === 'selfharvest') {
      if (!sellerAddressConfirmed || !selfHarvestDate || !selfHarvestTime) {
        setErrorMessage('Please confirm seller address and fill in all harvest details');
        return;
      }
    }

    const priceNum = parseInt(offerPrice);
    if (isNaN(priceNum) || priceNum <= 0) {
      setErrorMessage('Please enter a valid price');
      return;
    }

    // Check if user has enough points
    console.log('Points check - User points:', user.points, 'Required:', priceNum);
    if (user.points < priceNum) {
      setShowOfferModal(false);
      setShowInsufficientPointsModal(true);
      return;
    }

    // Build the buy agreement message details
    let agreementDetails = `📋 Buy Agreement Posted:\n\nQuantity: ${quantity} ${quantityUnit}\nPrice: ${offerPrice} points\n`;
    
    if (fulfillmentMethod === 'pickup') {
      agreementDetails += `Pickup: ${pickupDate} at ${pickupTime}\nAddress: ${sellerAddress}`;
    } else if (fulfillmentMethod === 'dropoff') {
      agreementDetails += `Dropoff to: ${dropoffAddress}\nLatest by: ${dropoffLatestDate}${dropoffTimeWindow ? `\nTime window: ${dropoffTimeWindow}` : ''}`;
    } else if (fulfillmentMethod === 'meetup') {
      agreementDetails += `Meetup: ${meetupDate} at ${meetupTime}\nLocation: ${meetupLocation}`;
    } else if (fulfillmentMethod === 'selfharvest') {
      agreementDetails += `Self-Harvest: ${selfHarvestDate} at ${selfHarvestTime}\nAddress: ${sellerAddress}`;
    }

    // Save agreement details to pass to chat
    setBuyAgreementDetails(agreementDetails);

    // Submit the offer directly - no checkout needed since points are deducted when seller confirms
    setSuccessMessage({
      title: 'Buy Agreement Submitted!',
      body: 'Your buy agreement has been sent to the seller. You can continue chatting while waiting for their response. Points will be held in escrow and deducted when the seller confirms the trade.'
    });
    setShowSuccessModal(true);
    setShowOfferModal(false);
    
    setTimeout(() => {
      setShowSuccessModal(false);
      setShowChatInterface(true); // Open chat interface
    }, 2000);
  };

  const handleSubmitDropoffRequest = () => {
    // Clear previous errors
    setErrorMessage('');

    // Validate fields
    if (!dropoffRequestQuantity || !dropoffRequestAddress || !dropoffRequestLatestDate) {
      setErrorMessage('Please fill in all required fields (quantity, address, and latest date)');
      return;
    }

    const total = parseFloat(dropoffRequestQuantity) * post.price;
    if (isNaN(total) || total <= 0) {
      setErrorMessage('Please enter a valid quantity');
      return;
    }

    // Check if user has enough points
    if (user.points < total) {
      setShowDropoffRequestModal(false);
      setShowInsufficientPointsModal(true);
      return;
    }

    // Show success message
    setSuccessMessage({
      title: 'Drop-Off Request Sent!',
      body: `${post.authorName} will review your request for ${dropoffRequestQuantity} ${post.unit} and contact you to confirm the delivery details. You'll be notified once they respond.`
    });
    setShowDropoffRequestModal(false);
    setShowSuccessModal(true);
    
    // Reset form
    setDropoffRequestQuantity('');
    setDropoffRequestAddress('');
    setDropoffRequestDate('');
    setDropoffRequestLatestDate('');
    setDropoffRequestPreferredDates([]);
    setTempDropoffDate('');
    setErrorMessage('');

    setTimeout(() => {
      setShowSuccessModal(false);
      setShowChatInterface(true); // Open chat interface
    }, 2000);
  };

  const handleCompleteCheckout = () => {
    // Clear previous errors
    setErrorMessage('');

    if (!transactionPaymentMethod) {
      setErrorMessage('Please select a payment method');
      return;
    }

    // Validate payment fields
    if (transactionPaymentMethod === 'creditCard') {
      if (!transactionCardNumber || !transactionCardExpiry || !transactionCardCvv || !transactionBillingZip) {
        setErrorMessage('Please fill in all credit card fields');
        return;
      }
      if (transactionCardNumber.replace(/\s/g, '').length !== 16) {
        setErrorMessage('Please enter a valid 16-digit card number');
        return;
      }
      if (transactionCardCvv.length !== 3) {
        setErrorMessage('Please enter a valid 3-digit CVV');
        return;
      }
      if (transactionBillingZip.length !== 5) {
        setErrorMessage('Please enter a valid 5-digit ZIP code');
        return;
      }
    } else if (transactionPaymentMethod === 'ach') {
      if (!transactionRoutingNumber || !transactionAccountNumber) {
        setErrorMessage('Please fill in all ACH fields');
        return;
      }
      if (transactionRoutingNumber.length !== 9) {
        setErrorMessage('Please enter a valid 9-digit routing number');
        return;
      }
    }

    // Process payment and complete offer
    setSuccessMessage({
      title: 'Buy Agreement Submitted!',
      body: 'Your buy agreement has been sent to the seller. You can continue chatting while waiting for their response.'
    });
    setShowSuccessModal(true);
    setShowCheckoutModal(false);
    
    // Reset transaction payment fields
    setTransactionPaymentMethod(null);
    setTransactionCardNumber('');
    setTransactionCardExpiry('');
    setTransactionCardCvv('');
    setTransactionBillingZip('');
    setTransactionRoutingNumber('');
    setTransactionAccountNumber('');
    setTransactionAccountType('checking');
    
    setTimeout(() => {
      setShowSuccessModal(false);
      setShowChatInterface(true); // Reopen chat interface
    }, 2000);
  };

  // Calculate costs with payment fees for Buy Points modal
  const calculatePointsCosts = () => {
    const pointsNum = parseInt(pointsToBuy) || 0;
    const baseAmount = pointsNum * 0.10;
    
    let serviceFee = 0;
    if (paymentMethod === 'creditCard') {
      serviceFee = baseAmount * PAYMENT_FEES.creditCard.value;
    } else if (paymentMethod === 'ach') {
      serviceFee = PAYMENT_FEES.ach.value;
    }
    
    const totalAmount = baseAmount + serviceFee;
    
    return { baseAmount, serviceFee, totalAmount };
  };

  // Calculate costs for transaction checkout
  const calculateTransactionCosts = () => {
    const priceNum = parseInt(offerPrice) || 0;
    const baseAmount = priceNum * 0.10; // Convert points to dollars (10 points = $1)
    
    let serviceFee = 0;
    if (transactionPaymentMethod === 'creditCard') {
      serviceFee = baseAmount * PAYMENT_FEES.creditCard.value;
    } else if (transactionPaymentMethod === 'ach') {
      serviceFee = PAYMENT_FEES.ach.value;
    }
    
    const totalAmount = baseAmount + serviceFee;
    
    return { baseAmount, serviceFee, totalAmount };
  };

  const handleAgreeToSell = () => {
    // Mark seller as agreed
    setSellerHasAgreed(true);
    
    // When seller agrees to sell, show success message
    setSuccessMessage({
      title: 'Agreement Confirmed!',
      body: 'You have agreed to sell. The buyer will be notified and the transaction can proceed.'
    });
    setShowSuccessModal(true);
    setTimeout(() => {
      setShowSuccessModal(false);
    }, 2000);
  };

  const handleBuyPoints = () => {
    const pointsNum = parseInt(pointsToBuy);
    if (isNaN(pointsNum) || pointsNum <= 0) {
      setErrorMessage('Please enter a valid amount');
      return;
    }

    if (!paymentMethod) {
      setErrorMessage('Please select a payment method');
      return;
    }

    // Validate payment fields
    if (paymentMethod === 'creditCard') {
      if (!cardNumber || !cardExpiry || !cardCvv || !billingZip) {
        setErrorMessage('Please fill in all credit card fields');
        return;
      }
      if (cardNumber.replace(/\s/g, '').length !== 16) {
        setErrorMessage('Please enter a valid 16-digit card number');
        return;
      }
      if (cardCvv.length !== 3) {
        setErrorMessage('Please enter a valid 3-digit CVV');
        return;
      }
      if (billingZip.length !== 5) {
        setErrorMessage('Please enter a valid 5-digit ZIP code');
        return;
      }
    } else if (paymentMethod === 'ach') {
      if (!routingNumber || !accountNumber) {
        setErrorMessage('Please fill in all ACH fields');
        return;
      }
      if (routingNumber.length !== 9) {
        setErrorMessage('Please enter a valid 9-digit routing number');
        return;
      }
    }

    // Clear any previous error
    setErrorMessage('');

    // Mock point purchase (in real app, would process payment)
    console.log('Buying points - Current:', user.points, 'Adding:', pointsNum, 'New total:', user.points + pointsNum);
    updateUserPoints(user.points + pointsNum);
    
    // Show success message
    setSuccessMessage({
      title: 'Points Purchased Successfully!',
      body: `${pointsNum} points have been added to your account.`
    });
    setShowSuccessModal(true);
    
    // Close modals
    setShowBuyPointsModal(false);
    setShowInsufficientPointsModal(false);
    
    // Reset form
    setPointsToBuy('100');
    setPaymentMethod(null);
    setCardNumber('');
    setCardExpiry('');
    setCardCvv('');
    setBillingZip('');
    setRoutingNumber('');
    setAccountNumber('');
    
    // Show offer modal again after buying points
    setTimeout(() => {
      setShowSuccessModal(false);
      setShowOfferModal(true);
    }, 1500);
  };

  const handleAddComment = () => {
    if (!commentText.trim()) return;
    const newComment: Comment = {
      id: Date.now().toString(),
      authorName: user.name,
      content: commentText,
      createdAt: new Date()
    };
    setComments([...comments, newComment]);
    setCommentText('');
  };

  const togglePostSelection = (postId: string) => {
    if (selectedPosts.includes(postId)) {
      setSelectedPosts(selectedPosts.filter(id => id !== postId));
    } else {
      setSelectedPosts([...selectedPosts, postId]);
    }
  };

  const getTimeAgo = (date: Date) => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    if (seconds < 60) return 'just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const options: Intl.DateTimeFormatOptions = { weekday: 'short', month: 'short', day: 'numeric' };
    return date.toLocaleDateString('en-US', options);
  };

  const postTypeColors: Record<string, string> = {
    sell: 'bg-green-100 text-green-700',
    buy: 'bg-blue-100 text-blue-700',
    'service-request': 'bg-purple-100 text-purple-700',
    'service-offer': 'bg-orange-100 text-orange-700',
    advice: 'bg-yellow-100 text-yellow-700'
  };

  const postTypeLabels: Record<string, string> = {
    sell: 'For Sale',
    buy: 'Wanted',
    'service-request': 'Service Needed',
    'service-offer': 'Service Offered',
    advice: 'Advice'
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Feed</span>
        </button>

        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          {/* Image */}
          {post.imageUrl && (
            <div className="aspect-video w-full overflow-hidden">
              <img src={post.imageUrl} alt={post.title} className="w-full h-full object-cover" />
            </div>
          )}

          {/* Content */}
          <div className="p-6">
            {/* Author Info */}
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-3">
                {post.authorPhoto ? (
                  <img src={post.authorPhoto} alt={post.authorName} className="w-12 h-12 rounded-full object-cover" />
                ) : (
                  <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center text-white font-semibold">
                    {post.authorName.charAt(0)}
                  </div>
                )}
                <div>
                  <div className="font-semibold text-gray-900">{post.authorName}</div>
                  <div className="text-sm text-gray-500">{post.community}</div>
                  <div className="text-xs text-gray-400">{getTimeAgo(post.createdAt)}</div>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${postTypeColors[post.type]}`}>
                {postTypeLabels[post.type]}
              </span>
            </div>

            {/* Title and Category */}
            <div className="mb-4">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">{post.title}</h1>
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <span>{post.category}</span>
                {post.price && (
                  <>
                    <span className="text-gray-300">·</span>
                    <span className="text-2xl font-bold text-green-600">{post.price} points</span>
                  </>
                )}
              </div>
            </div>

            {/* Description */}
            <p className="text-gray-700 mb-6">{post.description}</p>

            {/* For Sell Posts - Show Pickup Info and Buy/Offer Buttons */}
            {post.type === 'sell' && (
              <>
                {/* Fulfillment Info */}
                <div className="bg-gray-50 rounded-lg p-4 mb-6">
                  <h3 className="font-semibold text-gray-900 mb-3">Delivery Method</h3>
                  <div className="space-y-3 text-sm">
                    {/* Pickup at Address - New format with detailed dates */}
                    {post.fulfillmentOptions?.allowPickup && post.fulfillmentOptions.pickupAvailability?.length > 0 && (
                      <div className="pb-3 border-b border-gray-200 last:border-0">
                        <div className="flex items-center gap-2 text-green-700 font-medium mb-2">
                          <MapPin className="w-4 h-4" />
                          <span>Pickup at seller's address</span>
                        </div>
                        <div className="ml-6 space-y-1">
                          {post.fulfillmentOptions.pickupAvailability.map((item: any, index: number) => (
                            <div key={index} className="flex items-center gap-2 text-gray-700">
                              <Calendar className="w-4 h-4 text-gray-400" />
                              <span>{formatDate(item.date)} • {item.timeRange}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* Fallback for legacy pickup format */}
                    {!post.fulfillmentOptions?.allowPickup && post.pickupDays && post.pickupDays.length > 0 && (
                      <div className="pb-3 border-b border-gray-200 last:border-0">
                        <div className="flex items-center gap-2 text-green-700 font-medium mb-2">
                          <MapPin className="w-4 h-4" />
                          <span>Pickup at seller's address</span>
                        </div>
                        <div className="ml-6 space-y-1">
                          <div className="flex items-center gap-2 text-gray-700">
                            <Calendar className="w-4 h-4 text-gray-400" />
                            <span>Available: {post.pickupDays.join(', ')}</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-700">
                            <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            <span>{post.pickupTime}</span>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {/* Dropoff Option - New format with dates */}
                    {post.fulfillmentOptions?.canDropoff && post.fulfillmentOptions.dropoffDates?.length > 0 && (
                      <div className="pb-3 border-b border-gray-200 last:border-0">
                        <div className="flex items-center gap-2 text-orange-700 font-medium mb-2">
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                          </svg>
                          <span>Seller can drop off to your location</span>
                        </div>
                        <div className="ml-6 space-y-1">
                          {post.fulfillmentOptions.dropoffDates.map((date: string, index: number) => (
                            <div key={index} className="flex items-center gap-2 text-gray-700">
                              <Calendar className="w-4 h-4 text-gray-400" />
                              <span>{formatDate(date)}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* Fallback for legacy dropoff format */}
                    {!post.fulfillmentOptions?.canDropoff && post.allowsDropoff && (
                      <div className="pb-3 border-b border-gray-200 last:border-0">
                        <div className="flex items-center gap-2 text-orange-700 font-medium">
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                          </svg>
                          <span>Seller can drop off to your location</span>
                        </div>
                      </div>
                    )}
                    
                    {/* Meet Nearby Option - New format with dates */}
                    {post.fulfillmentOptions?.canMeetNearby && post.fulfillmentOptions.meetNearbyAvailability?.length > 0 && (
                      <div className="pb-3 border-b border-gray-200 last:border-0">
                        <div className="flex items-center gap-2 text-blue-700 font-medium mb-2">
                          <User className="w-4 h-4" />
                          <span>Can meet at a nearby location</span>
                        </div>
                        <div className="ml-6 space-y-1">
                          {post.fulfillmentOptions.meetNearbyAvailability.map((item: any, index: number) => (
                            <div key={index} className="flex items-center gap-2 text-gray-700">
                              <Calendar className="w-4 h-4" />
                              <span>{formatDate(item.date)} • {item.timeRange}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* Fallback for legacy meetup format */}
                    {!post.fulfillmentOptions?.canMeetNearby && post.allowsMeetup && (
                      <div className="pb-3 border-b border-gray-200 last:border-0">
                        <div className="flex items-center gap-2 text-blue-700 font-medium">
                          <User className="w-4 h-4" />
                          <span>Can meet at a nearby location</span>
                        </div>
                      </div>
                    )}
                    
                    {/* Self-Harvest Option - New format with dates */}
                    {post.fulfillmentOptions?.allowSelfHarvest && post.fulfillmentOptions.selfHarvestAvailability?.length > 0 && (
                      <div className="pb-3 border-b border-gray-200 last:border-0">
                        <div className="flex items-center gap-2 text-purple-700 font-medium mb-2">
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
                          </svg>
                          <span>Self-harvest at seller's location</span>
                        </div>
                        <div className="ml-6 space-y-1">
                          {post.fulfillmentOptions.selfHarvestAvailability.map((item: any, index: number) => (
                            <div key={index} className="flex items-center gap-2 text-gray-700">
                              <Calendar className="w-4 h-4" />
                              <span>{formatDate(item.date)} • {item.timeRange}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* Fallback for legacy self-harvest format */}
                    {!post.fulfillmentOptions?.allowSelfHarvest && post.allowsSelfHarvest && (
                      <div className="pb-3 border-b border-gray-200 last:border-0">
                        <div className="flex items-center gap-2 text-purple-700 font-medium">
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
                          </svg>
                          <span>Self-harvest at seller's location</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 mb-6">
                  {/* Drop-off Request - Primary action */}
                  <button
                    onClick={() => setShowDropoffRequestModal(true)}
                    className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
                  >
                    <ShoppingCart className="w-5 h-5" />
                    Make Drop-Off Request
                  </button>
                  
                  {/* Chat with Seller - Secondary action */}
                  <button
                    onClick={() => setShowChatInterface(true)}
                    className="flex-1 flex items-center justify-center gap-2 px-6 py-3 border-2 border-green-600 text-green-700 font-medium rounded-lg hover:bg-green-50 transition-colors"
                  >
                    <MessageCircle className="w-5 h-5" />
                    Chat with Seller
                  </button>
                </div>
              </>
            )}

            {/* For Buy Posts - Show User's Matching Posts to Share */}
            {post.type === 'buy' && (
              <div className="mb-6">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                  <h3 className="font-semibold text-blue-900 mb-2">Respond to this request</h3>
                  <p className="text-sm text-blue-800">
                    Select your existing posts to share with {post.authorName}, or create a new listing
                  </p>
                </div>

                {/* User's Matching Posts */}
                {userPosts.length > 0 ? (
                  <div className="space-y-3 mb-4">
                    <h4 className="font-medium text-gray-900">Your matching listings:</h4>
                    {userPosts.map((userPost) => (
                      <div
                        key={userPost.id}
                        onClick={() => togglePostSelection(userPost.id)}
                        className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                          selectedPosts.includes(userPost.id)
                            ? 'border-blue-500 bg-blue-50'
                            : 'border-gray-200 hover:border-blue-300'
                        }`}
                      >
                        <div className="flex gap-3">
                          {userPost.imageUrl && (
                            <img
                              src={userPost.imageUrl}
                              alt={userPost.title}
                              className="w-20 h-20 rounded-lg object-cover"
                            />
                          )}
                          <div className="flex-1">
                            <div className="flex items-start justify-between mb-1">
                              <h5 className="font-semibold text-gray-900">{userPost.title}</h5>
                              {selectedPosts.includes(userPost.id) && (
                                <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                                  <Check className="w-4 h-4 text-white" />
                                </div>
                              )}
                            </div>
                            <p className="text-sm text-gray-600 mb-2">{userPost.description}</p>
                            <div className="flex items-center gap-3 text-sm">
                              <span className="text-gray-500">{userPost.category}</span>
                              <span className="text-gray-300">·</span>
                              <span className="font-semibold text-green-600">{userPost.price} points</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="bg-gray-50 rounded-lg p-6 text-center mb-4">
                    <p className="text-gray-600 mb-3">You don't have any matching posts yet</p>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <button
                    onClick={() => onCreatePost?.('sell')}
                    className="flex-1 flex items-center justify-center gap-2 px-6 py-3 border-2 border-dashed border-gray-300 text-gray-700 font-medium rounded-lg hover:border-blue-500 hover:bg-blue-50 hover:text-blue-700 transition-colors"
                  >
                    <Plus className="w-5 h-5" />
                    Create New Listing
                  </button>
                  {selectedPosts.length > 0 && (
                    <button
                      onClick={handleSharePosts}
                      className="flex-1 px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      Share {selectedPosts.length} Post{selectedPosts.length > 1 ? 's' : ''}
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Engagement Stats and Actions */}
            <div className="flex items-center justify-between pb-4 border-b border-gray-200">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setIsLiked(!isLiked)}
                  className={`flex items-center gap-2 transition-colors ${
                    isLiked ? 'text-red-600' : 'text-gray-600 hover:text-red-600'
                  }`}
                >
                  <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
                  <span className="text-sm font-medium">{post.likes + (isLiked ? 1 : 0)}</span>
                </button>
                {post.type !== 'sell' && post.type !== 'buy' && (
                  <div className="flex items-center gap-2 text-gray-600">
                    <MessageCircle className="w-5 h-5" />
                    <span className="text-sm font-medium">{comments.length}</span>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button className="p-2 text-gray-600 hover:text-green-600 hover:bg-gray-50 rounded-full transition-colors">
                  <Share2 className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setShowFlagModal(true)}
                  className="p-2 text-gray-600 hover:text-red-600 hover:bg-gray-50 rounded-full transition-colors"
                >
                  <Flag className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Comments Section - Only for non-sell, non-buy posts */}
            {post.type !== 'sell' && post.type !== 'buy' && (
              <div className="mt-6">
                <h3 className="font-semibold text-gray-900 mb-4">Comments</h3>

                {/* Add Comment */}
                <div className="mb-6">
                  <div className="flex gap-3">
                    <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0">
                      {user.name.charAt(0)}
                    </div>
                    <div className="flex-1">
                      <textarea
                        value={commentText}
                        onChange={(e) => setCommentText(e.target.value)}
                        placeholder="Add a comment..."
                        rows={2}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
                      />
                      <button
                        onClick={handleAddComment}
                        disabled={!commentText.trim()}
                        className="mt-2 px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
                      >
                        Post Comment
                      </button>
                    </div>
                  </div>
                </div>

                {/* Comments List */}
                <div className="space-y-4">
                  {comments.map((comment) => (
                    <div key={comment.id} className="flex gap-3">
                      <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center text-gray-600 font-semibold flex-shrink-0">
                        {comment.authorName.charAt(0)}
                      </div>
                      <div className="flex-1">
                        <div className="bg-gray-50 rounded-lg p-3">
                          <div className="font-semibold text-gray-900 text-sm mb-1">{comment.authorName}</div>
                          <p className="text-gray-700 text-sm">{comment.content}</p>
                        </div>
                        <div className="text-xs text-gray-500 mt-1 ml-3">{getTimeAgo(comment.createdAt)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Offer Modal */}
      {showOfferModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 my-8">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Buy Agreement</h3>
            <p className="text-gray-600 mb-4">
              Complete the details below to send your offer to {post.authorName}.
            </p>

            {/* Error Message */}
            {errorMessage && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-700">{errorMessage}</p>
              </div>
            )}
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Quantity <span className="text-red-500">*</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    placeholder="Enter amount"
                    min="0.1"
                    step="0.1"
                  />
                  <div className="px-4 py-2 border border-gray-200 bg-gray-50 rounded-lg text-gray-700 font-medium min-w-[80px] flex items-center justify-center">
                    {quantityUnit.charAt(0).toUpperCase() + quantityUnit.slice(1)}
                  </div>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Seller's price: {post.price} points per {post.unit}
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Total Offer Price (points) <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  value={offerPrice}
                  onChange={(e) => setOfferPrice(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="Enter total points"
                  min="1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Suggested: {quantity && !isNaN(parseFloat(quantity)) && parseFloat(quantity) > 0 ? Math.round(post.price * parseFloat(quantity)) : '...'} points ({post.price} points per {post.unit} × quantity)
                </p>
              </div>
              
              {/* Fulfillment Method Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Fulfillment Method <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setFulfillmentMethod('dropoff');
                      setSellerAddressConfirmed(false);
                    }}
                    className={`px-4 py-3 rounded-lg border-2 font-medium transition-all text-sm ${
                      fulfillmentMethod === 'dropoff'
                        ? 'border-orange-500 bg-orange-50 text-orange-700'
                        : 'border-gray-300 text-gray-700 hover:border-gray-400'
                    }`}
                  >
                    Drop Off
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setFulfillmentMethod('pickup');
                      setSellerAddressConfirmed(false);
                    }}
                    className={`px-4 py-3 rounded-lg border-2 font-medium transition-all text-sm ${
                      fulfillmentMethod === 'pickup'
                        ? 'border-green-500 bg-green-50 text-green-700'
                        : 'border-gray-300 text-gray-700 hover:border-gray-400'
                    }`}
                  >
                    Pickup at Seller's
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setFulfillmentMethod('meetup');
                      setSellerAddressConfirmed(false);
                    }}
                    className={`px-4 py-3 rounded-lg border-2 font-medium transition-all text-sm ${
                      fulfillmentMethod === 'meetup'
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-gray-300 text-gray-700 hover:border-gray-400'
                    }`}
                  >
                    Meet Nearby
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setFulfillmentMethod('selfharvest');
                      setSellerAddressConfirmed(false);
                    }}
                    className={`px-4 py-3 rounded-lg border-2 font-medium transition-all text-sm ${
                      fulfillmentMethod === 'selfharvest'
                        ? 'border-purple-500 bg-purple-50 text-purple-700'
                        : 'border-gray-300 text-gray-700 hover:border-gray-400'
                    }`}
                  >
                    Self Harvest
                  </button>
                </div>
              </div>
              
              {/* Pickup Fields */}
              {fulfillmentMethod === 'pickup' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Seller Address <span className="text-red-500">*</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowSellerAddressModal(true)}
                      className={`w-full px-4 py-2 rounded-lg font-medium transition-all flex items-center justify-between ${
                        sellerAddressConfirmed
                          ? 'border-2 border-green-500 bg-green-50 text-green-700'
                          : 'border-2 border-gray-300 bg-white text-gray-700 hover:border-green-500'
                      }`}
                    >
                      <span>{sellerAddressConfirmed ? sellerAddress : 'Confirm Seller Address'}</span>
                      {sellerAddressConfirmed && <Check className="w-5 h-5" />}
                    </button>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Pickup Date <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="date"
                      value={pickupDate}
                      onChange={(e) => setPickupDate(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      min={new Date().toISOString().split('T')[0]}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Pickup Time <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="time"
                      value={pickupTime}
                      onChange={(e) => setPickupTime(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>
                </>
              )}

              {/* Drop Off Fields */}
              {fulfillmentMethod === 'dropoff' && (
                <>
                  <AddressInput
                    value={dropoffAddress}
                    onChange={setDropoffAddress}
                    label="Dropoff Address"
                    placeholder="Enter your delivery address"
                    required={true}
                  />
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Latest Drop-Off Date <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="date"
                      value={dropoffLatestDate}
                      onChange={(e) => setDropoffLatestDate(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      min={new Date().toISOString().split('T')[0]}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Latest date by which you need the items delivered
                    </p>
                  </div>

                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                    <p className="text-sm text-orange-800">
                      <strong>Note:</strong> The seller will take a geotagged photo when dropping off your items. You'll have 4 hours to confirm receipt or dispute delivery.
                    </p>
                  </div>
                </>
              )}

              {/* Meet Nearby Fields */}
              {fulfillmentMethod === 'meetup' && (
                <>
                  <div>
                    <AddressInput
                      value={meetupLocation}
                      onChange={setMeetupLocation}
                      label="Meeting Location"
                      placeholder="Enter meeting location"
                      required={true}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      E.g., coffee shop, park, community center
                    </p>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Meeting Date <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="date"
                      value={meetupDate}
                      onChange={(e) => setMeetupDate(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      min={new Date().toISOString().split('T')[0]}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Meeting Time <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="time"
                      value={meetupTime}
                      onChange={(e) => setMeetupTime(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </>
              )}

              {/* Self Harvest Fields */}
              {fulfillmentMethod === 'selfharvest' && (
                <>
                  <div className="bg-purple-50 border border-purple-200 rounded-lg p-3 mb-2">
                    <p className="text-sm text-purple-800">
                      <strong>Self Harvest:</strong> You'll pick the produce directly from the seller's garden.
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Seller Address <span className="text-red-500">*</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowSellerAddressModal(true)}
                      className={`w-full px-4 py-2 rounded-lg font-medium transition-all flex items-center justify-between ${
                        sellerAddressConfirmed
                          ? 'border-2 border-purple-500 bg-purple-50 text-purple-700'
                          : 'border-2 border-gray-300 bg-white text-gray-700 hover:border-purple-500'
                      }`}
                    >
                      <span>{sellerAddressConfirmed ? sellerAddress : 'Confirm Seller Address'}</span>
                      {sellerAddressConfirmed && <Check className="w-5 h-5" />}
                    </button>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Harvest Date <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="date"
                      value={selfHarvestDate}
                      onChange={(e) => setSelfHarvestDate(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      min={new Date().toISOString().split('T')[0]}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Harvest Time <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="time"
                      value={selfHarvestTime}
                      onChange={(e) => setSelfHarvestTime(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    />
                  </div>
                </>
              )}
              
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-700">Your current point balance</span>
                  <span className="font-semibold text-gray-900">{user.points}</span>
                </div>
                {offerPrice && parseInt(offerPrice) > 0 && (
                  <>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-700">Offer Price</span>
                      <span className="font-semibold text-gray-900">{parseInt(offerPrice)}</span>
                    </div>
                    <div className="pt-2 border-t border-gray-200">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-semibold text-gray-900">After Transaction Balance</span>
                        <span className={`font-bold ${user.points >= parseInt(offerPrice) ? 'text-green-600' : 'text-red-600'}`}>
                          {user.points - parseInt(offerPrice)} points
                        </span>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowOfferModal(false);
                  // Reset form
                  setQuantity('');
                  setQuantityUnit('lbs');
                  setOfferPrice('');
                  setPickupLocation('');
                  setPickupDate('');
                  setPickupTime('');
                  setDropoffAddress('');
                  setDropoffLatestDate('');
                  setMeetupLocation('');
                  setMeetupDate('');
                  setMeetupTime('');
                  setSelfHarvestDate('');
                  setSelfHarvestTime('');
                  setSellerAddressConfirmed(false);
                }}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmitOffer}
                className="flex-1 px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
              >
                Submit Offer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Drop-Off Request Modal */}
      {showDropoffRequestModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 my-8">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Drop-Off Delivery Request</h3>
            <p className="text-gray-600 mb-4">
              Complete the details below to request drop-off delivery from {post.authorName}.
            </p>

            {/* Error Message */}
            {errorMessage && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-700">{errorMessage}</p>
              </div>
            )}
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Quantity <span className="text-red-500">*</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    value={dropoffRequestQuantity}
                    onChange={(e) => setDropoffRequestQuantity(e.target.value)}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    placeholder="Enter amount"
                    min="0.1"
                    step="0.1"
                  />
                  <div className="px-4 py-2 border border-gray-200 bg-gray-50 rounded-lg text-gray-700 font-medium min-w-[80px] flex items-center justify-center">
                    {(post.unit || 'items').charAt(0).toUpperCase() + (post.unit || 'items').slice(1)}
                  </div>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Seller's price: {post.price} points per {post.unit}
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Total Offer Price (points) <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  value={dropoffRequestQuantity && !isNaN(parseFloat(dropoffRequestQuantity)) ? Math.round(parseFloat(dropoffRequestQuantity) * post.price) : ''}
                  readOnly
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-900 font-semibold"
                  placeholder="Enter quantity above"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Calculated: {post.price} points per {post.unit} × quantity
                </p>
              </div>

              {/* Drop-off Address */}
              <div>
                <AddressInput
                  value={dropoffRequestAddress}
                  onChange={setDropoffRequestAddress}
                  label="Drop-off Address"
                  placeholder="Enter your full delivery address"
                  required={true}
                  multiline={true}
                  rows={3}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Include apartment/unit number if applicable
                </p>
              </div>

              {/* Latest Drop-off Date */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Latest Drop-Off Date <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  value={dropoffRequestLatestDate}
                  onChange={(e) => setDropoffRequestLatestDate(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  min={new Date().toISOString().split('T')[0]}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Latest date by which you need the items delivered
                </p>
              </div>

              {/* Preferred Drop-off Dates */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Preferred Drop-off Dates (Optional)
                </label>
                <p className="text-xs text-gray-500 mb-2">
                  Add specific dates when you'd prefer delivery
                </p>
                
                {/* List of added dates */}
                {dropoffRequestPreferredDates.length > 0 && (
                  <div className="space-y-2 mb-2">
                    {dropoffRequestPreferredDates.map((date, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-2 bg-orange-50 border border-orange-200 rounded-lg"
                      >
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-orange-600" />
                          <span className="text-sm text-gray-900 font-medium">{formatDate(date)}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setDropoffRequestPreferredDates(
                              dropoffRequestPreferredDates.filter((_, i) => i !== index)
                            );
                          }}
                          className="p-1 hover:bg-orange-100 rounded transition-colors"
                        >
                          <X className="w-3 h-3 text-gray-600" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
                
                {/* Add date input */}
                <div className="flex gap-2">
                  <input
                    type="date"
                    value={tempDropoffDate}
                    onChange={(e) => setTempDropoffDate(e.target.value)}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm"
                    min={new Date().toISOString().split('T')[0]}
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (tempDropoffDate && !dropoffRequestPreferredDates.includes(tempDropoffDate)) {
                        setDropoffRequestPreferredDates([...dropoffRequestPreferredDates, tempDropoffDate]);
                        setTempDropoffDate('');
                      }
                    }}
                    disabled={!tempDropoffDate}
                    className="px-3 py-2 bg-orange-600 text-white font-medium rounded-lg hover:bg-orange-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center gap-1"
                  >
                    <Plus className="w-4 h-4" />
                    <span className="text-sm">Add</span>
                  </button>
                </div>
              </div>

              <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                <p className="text-sm text-orange-800">
                  <strong>Note:</strong> The seller will take a geotagged photo when dropping off your items. You'll have 4 hours to confirm receipt or dispute delivery.
                </p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-700">Your current point balance</span>
                  <span className="font-semibold text-gray-900">{user.points}</span>
                </div>
                {dropoffRequestQuantity && parseFloat(dropoffRequestQuantity) > 0 && (
                  <>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-700">Request Price</span>
                      <span className="font-semibold text-gray-900">{Math.round(parseFloat(dropoffRequestQuantity) * post.price)}</span>
                    </div>
                    <div className="pt-2 border-t border-gray-200">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-semibold text-gray-900">After Transaction Balance</span>
                        <span className={`font-bold ${user.points >= Math.round(parseFloat(dropoffRequestQuantity) * post.price) ? 'text-green-600' : 'text-red-600'}`}>
                          {user.points - Math.round(parseFloat(dropoffRequestQuantity) * post.price)} points
                        </span>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
            
            <div className="space-y-3">
              {/* Chat with Seller Button */}
              <button
                onClick={() => {
                  setShowDropoffRequestModal(false);
                  setShowChatInterface(true);
                }}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 border-2 border-green-600 text-green-700 font-medium rounded-lg hover:bg-green-50 transition-colors"
              >
                <MessageCircle className="w-5 h-5" />
                Chat with Seller
              </button>
              
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowDropoffRequestModal(false);
                    // Reset form
                    setDropoffRequestQuantity('');
                    setDropoffRequestAddress('');
                    setDropoffRequestDate('');
                    setDropoffRequestLatestDate('');
                    setDropoffRequestPreferredDates([]);
                    setTempDropoffDate('');
                    setErrorMessage('');
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSubmitDropoffRequest}
                  className="flex-1 px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
                >
                  Submit Request
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Success Modal */}
      {showSuccessModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">
              {successMessage.title || 'Posts Shared!'}
            </h3>
            <p className="text-gray-600">
              {successMessage.body || `${post.authorName} will receive a notification with links to your ${selectedPosts.length} listing${selectedPosts.length > 1 ? 's' : ''}.`}
            </p>
          </div>
        </div>
      )}

      {/* Chat Interface */}
      {showChatInterface && (
        <ChatInterface
          currentUserId={user.id}
          currentUserName={user.name}
          otherUserId={post.authorId}
          otherUserName={post.authorName}
          postTitle={post.title}
          postType={post.type}
          onClose={() => setShowChatInterface(false)}
          onMakeOffer={handleMakeOffer}
          onAgreeToSell={handleAgreeToSell}
          isCurrentUserSeller={user.id === post.authorId}
          savedAddress={sellerAddress}
          buyAgreementDetails={buyAgreementDetails}
          sellerHasAgreed={sellerHasAgreed}
        />
      )}

      {/* Checkout Modal */}
      {showCheckoutModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full my-8">
            {/* Header */}
            <div className="bg-gradient-to-r from-green-600 to-green-500 p-6 text-white rounded-t-2xl">
              <h2 className="text-2xl font-bold mb-1">Complete Your Purchase</h2>
              <p className="text-green-50 text-sm">Choose payment method for {offerPrice} points (${calculateTransactionCosts().baseAmount.toFixed(2)})</p>
            </div>

            <div className="p-6 space-y-6">
              {/* Order Summary */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-3">Order Summary</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Item:</span>
                    <span className="font-medium text-gray-900">{post.title}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Quantity:</span>
                    <span className="font-medium text-gray-900">{quantity} {quantityUnit}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Price:</span>
                    <span className="font-medium text-gray-900">{offerPrice} points</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Fulfillment:</span>
                    <span className="font-medium text-gray-900 capitalize">{fulfillmentMethod}</span>
                  </div>
                </div>
              </div>

              {/* Payment Method Selection */}
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Select Payment Method</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Credit Card Option */}
                  <button
                    type="button"
                    onClick={() => setTransactionPaymentMethod('creditCard')}
                    className={`p-4 border-2 rounded-xl transition-all hover:shadow-lg text-left ${
                      transactionPaymentMethod === 'creditCard'
                        ? 'border-green-600 bg-green-50'
                        : 'border-gray-200 hover:border-green-300'
                    }`}
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <CreditCard className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <div className="font-semibold text-gray-900">Credit Card</div>
                        <div className="text-xs text-gray-500">Instant processing</div>
                      </div>
                    </div>
                    <div className="text-sm text-gray-600 mb-1">{PAYMENT_FEES.creditCard.label}</div>
                    <div className="text-xs text-gray-500">
                      Higher fees for fraud protection
                    </div>
                  </button>

                  {/* ACH Option */}
                  <button
                    type="button"
                    onClick={() => setTransactionPaymentMethod('ach')}
                    className={`p-4 border-2 rounded-xl transition-all hover:shadow-lg text-left ${
                      transactionPaymentMethod === 'ach'
                        ? 'border-green-600 bg-green-50'
                        : 'border-gray-200 hover:border-green-300'
                    }`}
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                        <Building2 className="w-5 h-5 text-purple-600" />
                      </div>
                      <div>
                        <div className="font-semibold text-gray-900">Bank Transfer (ACH)</div>
                        <div className="text-xs text-gray-500">Lower fees</div>
                      </div>
                    </div>
                    <div className="text-sm text-gray-600 mb-1">{PAYMENT_FEES.ach.label}</div>
                    <div className="text-xs text-gray-500">
                      Takes 1-3 business days
                    </div>
                  </button>
                </div>
              </div>

              {/* Credit Card Form */}
              {transactionPaymentMethod === 'creditCard' && (
                <div className="bg-gray-50 rounded-lg p-4 space-y-4">
                  <h3 className="font-semibold text-gray-900">Credit Card Information</h3>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Card Number
                    </label>
                    <input
                      type="text"
                      value={transactionCardNumber}
                      onChange={(e) => {
                        const value = e.target.value.replace(/\s/g, '');
                        if (/^\d*$/.test(value) && value.length <= 16) {
                          setTransactionCardNumber(value.replace(/(\d{4})/g, '$1 ').trim());
                        }
                      }}
                      placeholder="1234 5678 9012 3456"
                      maxLength={19}
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="col-span-1">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Expiry
                      </label>
                      <input
                        type="text"
                        value={transactionCardExpiry}
                        onChange={(e) => {
                          let value = e.target.value.replace(/\D/g, '');
                          if (value.length >= 2) {
                            value = value.slice(0, 2) + '/' + value.slice(2, 4);
                          }
                          if (value.length <= 5) {
                            setTransactionCardExpiry(value);
                          }
                        }}
                        placeholder="MM/YY"
                        maxLength={5}
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      />
                    </div>
                    
                    <div className="col-span-1">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        CVV
                      </label>
                      <input
                        type="text"
                        value={transactionCardCvv}
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, '');
                          if (value.length <= 3) {
                            setTransactionCardCvv(value);
                          }
                        }}
                        placeholder="123"
                        maxLength={3}
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      />
                    </div>

                    <div className="col-span-1">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        ZIP Code
                      </label>
                      <input
                        type="text"
                        value={transactionBillingZip}
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, '');
                          if (value.length <= 5) {
                            setTransactionBillingZip(value);
                          }
                        }}
                        placeholder="12345"
                        maxLength={5}
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* ACH Form */}
              {transactionPaymentMethod === 'ach' && (
                <div className="bg-gray-50 rounded-lg p-4 space-y-4">
                  <h3 className="font-semibold text-gray-900">Bank Account Information</h3>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Account Type
                    </label>
                    <div className="flex gap-4">
                      <button
                        type="button"
                        onClick={() => setTransactionAccountType('checking')}
                        className={`flex-1 px-4 py-3 border-2 rounded-lg font-medium transition-all ${
                          transactionAccountType === 'checking'
                            ? 'border-green-600 bg-green-50 text-green-700'
                            : 'border-gray-300 text-gray-700 hover:border-gray-400'
                        }`}
                      >
                        Checking
                      </button>
                      <button
                        type="button"
                        onClick={() => setTransactionAccountType('savings')}
                        className={`flex-1 px-4 py-3 border-2 rounded-lg font-medium transition-all ${
                          transactionAccountType === 'savings'
                            ? 'border-green-600 bg-green-50 text-green-700'
                            : 'border-gray-300 text-gray-700 hover:border-gray-400'
                        }`}
                      >
                        Savings
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Routing Number
                    </label>
                    <input
                      type="text"
                      value={transactionRoutingNumber}
                      onChange={(e) => {
                        const value = e.target.value.replace(/\D/g, '');
                        if (value.length <= 9) {
                          setTransactionRoutingNumber(value);
                        }
                      }}
                      placeholder="9 digits"
                      maxLength={9}
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Found on the bottom of your check
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Account Number
                    </label>
                    <input
                      type="text"
                      value={transactionAccountNumber}
                      onChange={(e) => {
                        const value = e.target.value.replace(/\D/g, '');
                        if (value.length <= 17) {
                          setTransactionAccountNumber(value);
                        }
                      }}
                      placeholder="Account number"
                      maxLength={17}
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>
                </div>
              )}

              {/* Service Fee Explanation */}
              {transactionPaymentMethod && (
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <div className="flex gap-3">
                    <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-amber-900 mb-1">About Service Fees</h4>
                      <p className="text-sm text-amber-800">
                        CasaGrown passes along payment processing fees from our payment providers (Stripe, Plaid) to keep 
                        the platform sustainable. These fees cover the cost of secure payment processing, fraud protection, 
                        and regulatory compliance. We do not profit from these fees - they go directly to our payment processors.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Cost Breakdown */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-3">Cost Breakdown</h3>
                <div className="space-y-2 mb-3">
                  <div className="flex items-center justify-between text-gray-700">
                    <span>{offerPrice} points × $0.10</span>
                    <span className="font-medium">${calculateTransactionCosts().baseAmount.toFixed(2)}</span>
                  </div>
                  {transactionPaymentMethod && calculateTransactionCosts().serviceFee > 0 && (
                    <div className="flex items-center justify-between text-gray-700">
                      <span>
                        Service fee ({transactionPaymentMethod === 'creditCard' ? PAYMENT_FEES.creditCard.label : PAYMENT_FEES.ach.label})
                      </span>
                      <span className="font-medium">${calculateTransactionCosts().serviceFee.toFixed(2)}</span>
                    </div>
                  )}
                </div>
                <div className="pt-3 border-t-2 border-blue-300">
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-semibold text-gray-900">Total Amount</span>
                    <span className="text-2xl font-bold text-gray-900">
                      ${calculateTransactionCosts().totalAmount.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Error Message */}
              {errorMessage && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <p className="text-sm text-red-800">{errorMessage}</p>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowCheckoutModal(false);
                    setShowOfferModal(true);
                    setErrorMessage('');
                  }}
                  className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Back
                </button>
                <button
                  onClick={handleCompleteCheckout}
                  disabled={!transactionPaymentMethod}
                  className="flex-1 px-4 py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
                >
                  Complete Purchase
                </button>
              </div>

              <p className="text-center text-xs text-gray-500">
                This is a mock payment for MVP testing. No actual charges will be made.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Insufficient Points Modal */}
      {showInsufficientPointsModal && (() => {
        const requiredPoints = offerPrice && parseInt(offerPrice) > 0 
          ? parseInt(offerPrice) 
          : dropoffRequestQuantity && parseFloat(dropoffRequestQuantity) > 0
            ? Math.round(parseFloat(dropoffRequestQuantity) * post.price)
            : 0;
        const pointsNeeded = requiredPoints - user.points;
        
        return (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl max-w-md w-full p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Insufficient Points</h3>
              <p className="text-gray-600 mb-4">
                You need {requiredPoints} points to make this offer, but you only have {user.points} points.
              </p>
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                <p className="text-sm text-yellow-800">
                  You need {pointsNeeded} more points to complete this transaction.
                </p>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowInsufficientPointsModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    setShowInsufficientPointsModal(false);
                    setShowBuyPointsModal(true);
                  }}
                  className="flex-1 px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
                >
                  Buy Points
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Buy Points Modal */}
      {showBuyPointsModal && (
        <BuyPointsModal
          userPoints={user.points}
          pointsToBuy={pointsToBuy}
          setPointsToBuy={setPointsToBuy}
          paymentMethod={paymentMethod}
          setPaymentMethod={setPaymentMethod}
          cardNumber={cardNumber}
          setCardNumber={setCardNumber}
          cardExpiry={cardExpiry}
          setCardExpiry={setCardExpiry}
          cardCvv={cardCvv}
          setCardCvv={setCardCvv}
          billingZip={billingZip}
          setBillingZip={setBillingZip}
          routingNumber={routingNumber}
          setRoutingNumber={setRoutingNumber}
          accountNumber={accountNumber}
          setAccountNumber={setAccountNumber}
          accountType={accountType}
          setAccountType={setAccountType}
          errorMessage={errorMessage}
          onCancel={() => {
            setShowBuyPointsModal(false);
            setErrorMessage('');
            setPaymentMethod(null);
            setCardNumber('');
            setCardExpiry('');
            setCardCvv('');
            setBillingZip('');
            setRoutingNumber('');
            setAccountNumber('');
          }}
          onPurchase={handleBuyPoints}
        />
      )}

      {/* Flag Modal */}
      {showFlagModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Report Post</h3>
            <p className="text-gray-600 mb-4">
              Please provide a reason for reporting this post.
            </p>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Category <span className="text-red-500">*</span>
                </label>
                <select
                  value={flagCategory}
                  onChange={(e) => setFlagCategory(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white"
                >
                  <option value="">Select a category</option>
                  <option value="spam">Spam</option>
                  <option value="inappropriate">Inappropriate Content</option>
                  <option value="fraud">Fraudulent Activity</option>
                  <option value="other">Other</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Reason <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={flagReason}
                  onChange={(e) => setFlagReason(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
                  placeholder="Enter your reason for reporting this post"
                  rows={4}
                />
              </div>
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowFlagModal(false);
                  // Reset form
                  setFlagReason('');
                  setFlagCategory('');
                }}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (!flagCategory || !flagReason.trim()) {
                    return;
                  }
                  setShowFlagModal(false);
                  setFlagReason('');
                  setFlagCategory('');
                }}
                disabled={!flagCategory || !flagReason.trim()}
                className="flex-1 px-4 py-2 bg-red-600 text-white font-medium rounded-lg hover:bg-red-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
              >
                Submit Report
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Seller Address Confirmation Modal */}
      {showSellerAddressModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Confirm Seller Address</h3>
            <p className="text-gray-600 mb-4">
              Please review and confirm the seller's address for {fulfillmentMethod === 'pickup' ? 'pickup' : 'self harvest'}.
            </p>

            <div className="space-y-4 mb-6">
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <div className="font-semibold text-gray-900 mb-1">Seller's Address</div>
                    <div className="text-gray-700">{sellerAddress}</div>
                    <div className="text-sm text-gray-500 mt-2">
                      This is {post.authorName}'s address for {fulfillmentMethod === 'pickup' ? 'pickup' : 'harvesting'}.
                    </div>
                  </div>
                </div>
              </div>

              {fulfillmentMethod === 'selfharvest' && (
                <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                  <p className="text-sm text-purple-800">
                    <strong>Note:</strong> You'll be visiting the seller's garden to harvest the produce yourself.
                  </p>
                </div>
              )}
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={() => setShowSellerAddressModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setSellerAddressConfirmed(true);
                  setShowSellerAddressModal(false);
                }}
                className="flex-1 px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
              >
                Confirm Address
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}