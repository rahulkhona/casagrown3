import React, { useState } from 'react';
import { ArrowLeft, UserPlus, Search, Check, X, User, ShoppingBag, AlertCircle } from 'lucide-react';

interface User {
  id: string;
  name: string;
  community: string;
}

interface Delegation {
  id: string;
  delegateId: string;
  delegateName: string;
  delegateCommunity: string;
  status: 'active' | 'pending';
  dateRequested: string;
  dateAccepted?: string;
}

interface DelegationRequest {
  id: string;
  fromUserId: string;
  fromUserName: string;
  fromUserCommunity: string;
  status: 'pending' | 'accepted' | 'rejected';
  dateRequested: string;
}

interface DelegateManagementProps {
  user: User;
  onBack: () => void;
  delegations: Delegation[];
  delegationRequests: DelegationRequest[];
  onAddDelegation: (delegation: Delegation) => void;
  onRemoveDelegation: (delegationId: string) => void;
  onAcceptDelegation: (requestId: string) => void;
  onRejectDelegation: (requestId: string) => void;
  onInactivateDelegatingFor?: (requestId: string) => void;
}

// Mock user search results
const mockUsers = [
  { id: 'user-2', name: 'Sarah Chen', community: 'Sunset Hills' },
  { id: 'user-3', name: 'Michael Torres', community: 'Sunset Hills' },
  { id: 'user-4', name: 'Emily Johnson', community: 'Green Valley' },
  { id: 'user-5', name: 'David Kim', community: 'Oakwood' },
  { id: 'user-6', name: 'Lisa Anderson', community: 'Sunset Hills' },
  { id: 'user-7', name: 'James Wilson', community: 'Green Valley' },
  { id: 'user-8', name: 'Maria Garcia', community: 'Sunset Hills' },
];

export default function DelegateManagement({
  user,
  onBack,
  delegations,
  delegationRequests,
  onAddDelegation,
  onRemoveDelegation,
  onAcceptDelegation,
  onRejectDelegation,
  onInactivateDelegatingFor
}: DelegateManagementProps) {
  const [activeTab, setActiveTab] = useState<'my-delegates' | 'delegating-for'>('my-delegates');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddDelegate, setShowAddDelegate] = useState(false);
  const [selectedUser, setSelectedUser] = useState<typeof mockUsers[0] | null>(null);

  // Filter users based on search query
  const filteredUsers = mockUsers.filter(u => 
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
    u.id !== user.id &&
    !delegations.some(d => d.delegateId === u.id)
  );

  const handleDelegateUser = () => {
    if (!selectedUser) return;

    const newDelegation: Delegation = {
      id: `delegation-${Date.now()}`,
      delegateId: selectedUser.id,
      delegateName: selectedUser.name,
      delegateCommunity: selectedUser.community,
      status: 'pending',
      dateRequested: new Date().toISOString(),
    };

    onAddDelegation(newDelegation);
    setShowAddDelegate(false);
    setSearchQuery('');
    setSelectedUser(null);
  };

  // Get active delegations where I'm delegating TO someone
  const myDelegates = delegations.filter(d => d.status === 'active' || d.status === 'pending');
  
  // Get requests where someone wants ME to be their delegate
  const delegatingFor = delegationRequests.filter(r => r.status === 'pending' || r.status === 'accepted');

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back</span>
        </button>

        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          {/* Title Section */}
          <div className="bg-gradient-to-r from-green-600 to-green-500 p-8 text-white">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <UserPlus className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-3xl font-bold">Delegate Sales</h1>
                <p className="text-green-50">Manage who can sell on your behalf</p>
              </div>
            </div>
          </div>

          {/* Info Banner */}
          <div className="bg-blue-50 border-b border-blue-200 p-4">
            <div className="flex gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold text-blue-900 mb-1">About Delegation</h4>
                <p className="text-sm text-blue-800">
                  Delegate your selling process to trusted neighbors. They can post sales on your behalf and you'll receive 
                  notifications when transactions complete. You remain in control and can revoke access at any time.
                </p>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="border-b border-gray-200">
            <div className="flex">
              <button
                onClick={() => setActiveTab('my-delegates')}
                className={`flex-1 px-6 py-4 font-medium transition-colors ${
                  activeTab === 'my-delegates'
                    ? 'text-green-600 border-b-2 border-green-600'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                My Delegates ({myDelegates.length})
              </button>
              <button
                onClick={() => setActiveTab('delegating-for')}
                className={`flex-1 px-6 py-4 font-medium transition-colors ${
                  activeTab === 'delegating-for'
                    ? 'text-green-600 border-b-2 border-green-600'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Delegating For ({delegatingFor.filter(d => d.status === 'accepted').length})
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="p-8">
            {activeTab === 'my-delegates' && (
              <div>
                {/* Add Delegate Button */}
                {!showAddDelegate && (
                  <button
                    onClick={() => setShowAddDelegate(true)}
                    className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition-colors mb-6"
                  >
                    <UserPlus className="w-5 h-5" />
                    Add New Delegate
                  </button>
                )}

                {/* Add Delegate Form */}
                {showAddDelegate && (
                  <div className="bg-gray-50 rounded-lg p-6 mb-6">
                    <h3 className="font-semibold text-gray-900 mb-4">Find a Delegate</h3>
                    
                    {/* Search */}
                    <div className="mb-4">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="text"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          placeholder="Search by name..."
                          className="w-full pl-10 pr-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        />
                      </div>
                    </div>

                    {/* Search Results */}
                    {searchQuery && (
                      <div className="mb-4 max-h-64 overflow-y-auto space-y-2">
                        {filteredUsers.length > 0 ? (
                          filteredUsers.map(u => (
                            <button
                              key={u.id}
                              onClick={() => setSelectedUser(u)}
                              className={`w-full flex items-center gap-3 p-4 rounded-lg border-2 transition-all text-left ${
                                selectedUser?.id === u.id
                                  ? 'border-green-600 bg-green-50'
                                  : 'border-gray-200 hover:border-green-300'
                              }`}
                            >
                              <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center">
                                <User className="w-5 h-5 text-gray-600" />
                              </div>
                              <div className="flex-1">
                                <div className="font-semibold text-gray-900">{u.name}</div>
                                <div className="text-sm text-gray-600">{u.community}</div>
                              </div>
                              {selectedUser?.id === u.id && (
                                <Check className="w-5 h-5 text-green-600" />
                              )}
                            </button>
                          ))
                        ) : (
                          <p className="text-center text-gray-500 py-4">No users found</p>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex gap-3">
                      <button
                        onClick={() => {
                          setShowAddDelegate(false);
                          setSearchQuery('');
                          setSelectedUser(null);
                        }}
                        className="flex-1 px-4 py-3 border-2 border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleDelegateUser}
                        disabled={!selectedUser}
                        className="flex-1 px-4 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
                      >
                        Send Request
                      </button>
                    </div>

                    {/* Important Information */}
                    <div className="mt-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <div className="flex items-start gap-3">
                        <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                        <div>
                          <h4 className="font-semibold text-blue-900 mb-2">How Delegation Works</h4>
                          <ul className="text-sm text-blue-800 space-y-1.5">
                            <li>• Your delegate will be able to post items for sale on your behalf in your community</li>
                            <li>• They can only offer drop-off as a fulfillment option</li>
                            <li>• <strong>When a sale completes, the points go to your delegate</strong></li>
                            <li>• Your delegate is responsible for transferring your agreed share of points to you</li>
                            <li>• You'll receive notifications when they post items and complete sales</li>
                            <li>• You can revoke delegation access at any time</li>
                          </ul>
                          <p className="text-sm text-blue-900 font-medium mt-3">
                            💡 Tip: Agree on the points split arrangement with your delegate before accepting (e.g., 70/30, 50/50, etc.)
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Active Delegates List */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-gray-900">Active Delegates</h3>
                  {myDelegates.length > 0 ? (
                    myDelegates.map(delegation => (
                      <div
                        key={delegation.id}
                        className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg"
                      >
                        <div className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center">
                          <User className="w-6 h-6 text-gray-600" />
                        </div>
                        <div className="flex-1">
                          <div className="font-semibold text-gray-900">{delegation.delegateName}</div>
                          <div className="text-sm text-gray-600">{delegation.delegateCommunity}</div>
                          <div className="text-xs text-gray-500 mt-1">
                            {delegation.status === 'pending' ? (
                              <span className="inline-flex items-center gap-1 px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full">
                                Pending Acceptance
                              </span>
                            ) : (
                              <span className="text-gray-500">
                                Active since {new Date(delegation.dateAccepted!).toLocaleDateString()}
                              </span>
                            )}
                          </div>
                        </div>
                        <button
                          onClick={() => onRemoveDelegation(delegation.id)}
                          className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          Revoke
                        </button>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-12">
                      <ShoppingBag className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                      <p className="text-gray-500">No active delegates</p>
                      <p className="text-sm text-gray-400">Add a delegate to help with your sales</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'delegating-for' && (
              <div className="space-y-6">
                {/* Information Box - How Being a Delegate Works */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-blue-900 mb-2">Your Role as a Delegate</h4>
                      <ul className="text-sm text-blue-800 space-y-1.5">
                        <li>• You can post items for sale on behalf of others in their community</li>
                        <li>• You can only offer drop-off as a fulfillment option for delegate posts</li>
                        <li>• <strong>When a sale completes, the points are credited to your account</strong></li>
                        <li>• You are responsible for transferring the agreed share of points to the person you're selling for</li>
                        <li>• They will receive notifications when you post items and complete sales</li>
                        <li>• You can inactivate your delegation at any time</li>
                      </ul>
                      <p className="text-sm text-blue-900 font-medium mt-3">
                        💡 Important: Discuss and agree on the points split with the person before accepting (e.g., you keep 30%, transfer 70%)
                      </p>
                    </div>
                  </div>
                </div>

                {/* Pending Requests */}
                {delegatingFor.filter(r => r.status === 'pending').length > 0 && (
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-4">Pending Requests</h3>
                    <div className="space-y-4">
                      {delegatingFor
                        .filter(r => r.status === 'pending')
                        .map(request => (
                          <div
                            key={request.id}
                            className="flex items-center gap-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg"
                          >
                            <div className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center">
                              <User className="w-6 h-6 text-gray-600" />
                            </div>
                            <div className="flex-1">
                              <div className="font-semibold text-gray-900">{request.fromUserName}</div>
                              <div className="text-sm text-gray-600">{request.fromUserCommunity}</div>
                              <div className="text-xs text-gray-500 mt-1">
                                Requested {new Date(request.dateRequested).toLocaleDateString()}
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <button
                                onClick={() => onAcceptDelegation(request.id)}
                                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                              >
                                Accept
                              </button>
                              <button
                                onClick={() => onRejectDelegation(request.id)}
                                className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                              >
                                Decline
                              </button>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                )}

                {/* Active Delegations */}
                <div>
                  <h3 className="font-semibold text-gray-900 mb-4">Selling For</h3>
                  {delegatingFor.filter(r => r.status === 'accepted').length > 0 ? (
                    <div className="space-y-4">
                      {delegatingFor
                        .filter(r => r.status === 'accepted')
                        .map(request => (
                          <div
                            key={request.id}
                            className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg"
                          >
                            <div className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center">
                              <User className="w-6 h-6 text-gray-600" />
                            </div>
                            <div className="flex-1">
                              <div className="font-semibold text-gray-900">{request.fromUserName}</div>
                              <div className="text-sm text-gray-600">{request.fromUserCommunity}</div>
                              <div className="text-xs text-gray-500 mt-1">
                                You can post sales on their behalf
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <div className="px-3 py-1 bg-green-100 text-green-800 text-sm font-medium rounded-full">
                                Active
                              </div>
                              {onInactivateDelegatingFor && (
                                <button
                                  onClick={() => onInactivateDelegatingFor(request.id)}
                                  className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                                  title="Stop selling for this person"
                                >
                                  Inactivate
                                </button>
                              )}
                            </div>
                          </div>
                        ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <ShoppingBag className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                      <p className="text-gray-500">Not delegating for anyone</p>
                      <p className="text-sm text-gray-400">You'll see requests here when someone wants you to sell for them</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}