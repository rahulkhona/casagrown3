import React, { useState, useRef } from 'react';
import { Camera, Upload, X, Image as ImageIcon, Video as VideoIcon, CheckCircle, Gift, ArrowLeft, Plus } from 'lucide-react';

interface IntroPostProps {
  userName: string;
  userPhoto?: string;
  earnedPoints: number;
  onComplete: (data: { message: string; media?: string; mediaType?: 'image' | 'video'; makeFirstPost: boolean; gardenProduce: string[] }) => void;
  onSkip: () => void;
  onBack: () => void;
}

export default function IntroPost({ userName, userPhoto, earnedPoints, onComplete, onSkip, onBack }: IntroPostProps) {
  const [message, setMessage] = useState('');
  const [media, setMedia] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<'image' | 'video' | null>(null);
  const [makeFirstPost, setMakeFirstPost] = useState(true);
  const [gardenProduce, setGardenProduce] = useState<string[]>([]);
  const [customProduceInput, setCustomProduceInput] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  // Recommended produce options
  const recommendedProduce = [
    'Tomatoes', 'Lemons', 'Oranges', 'Avocados', 'Herbs', 
    'Lettuce', 'Peppers', 'Cucumbers', 'Zucchini', 'Strawberries',
    'Basil', 'Mint', 'Rosemary', 'Carrots', 'Radishes'
  ];

  const handleMediaUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'video') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setMedia(reader.result as string);
        setMediaType(type);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveMedia = () => {
    setMedia(null);
    setMediaType(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
    if (videoInputRef.current) videoInputRef.current.value = '';
  };

  const handleSubmit = () => {
    if (message.trim() || media) {
      onComplete({
        message: message.trim(),
        media: media || undefined,
        mediaType: mediaType || undefined,
        makeFirstPost,
        gardenProduce
      });
    }
  };

  const handleAddProduce = (produce: string) => {
    if (!gardenProduce.includes(produce)) {
      setGardenProduce([...gardenProduce, produce]);
    }
  };

  const handleRemoveProduce = (produce: string) => {
    setGardenProduce(gardenProduce.filter(p => p !== produce));
  };

  const handleAddCustomProduce = () => {
    if (customProduceInput.trim() && !gardenProduce.includes(customProduceInput.trim())) {
      setGardenProduce([...gardenProduce, customProduceInput.trim()]);
      setCustomProduceInput('');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Progress indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">Almost done!</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-green-600 h-2 rounded-full" style={{ width: '90%' }}></div>
          </div>
        </div>

        {/* Rewards Banner - only show if earnedPoints > 0 */}
        {earnedPoints > 0 && (
          <div className="bg-gradient-to-r from-green-600 to-green-500 text-white rounded-lg p-4 mb-6">
            <div className="flex items-start gap-3">
              <Gift className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold mb-1">Make your first post & earn {earnedPoints} points! 🎉</h3>
                <p className="text-sm text-green-50">
                  Your first post helps neighbors get to know you and kicks off your CasaGrown journey
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Main Card */}
        <div className="bg-white rounded-2xl shadow-xl p-6 sm:p-8">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Introduce Yourself! 👋</h2>
            <p className="text-gray-600">
              Share a little about yourself with your new community
            </p>
          </div>

          {/* User Info Preview */}
          <div className="flex items-center gap-3 mb-6 p-4 bg-gray-50 rounded-lg">
            {userPhoto ? (
              <img src={userPhoto} alt={userName} className="w-12 h-12 rounded-full object-cover" />
            ) : (
              <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center text-white font-semibold">
                {userName.charAt(0).toUpperCase()}
              </div>
            )}
            <div>
              <div className="font-semibold text-gray-900">{userName}</div>
              <div className="text-sm text-gray-500">New to CasaGrown</div>
            </div>
          </div>

          {/* Message Input */}
          <div className="mb-6">
            <label htmlFor="intro-message" className="block text-sm font-medium text-gray-700 mb-2">
              Your introduction
            </label>
            <textarea
              id="intro-message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
              placeholder="Hi neighbors! I'm excited to join the community. Fun fact: I have a lemon tree that produces year-round and I love experimenting with heirloom tomato varieties..."
              rows={4}
              maxLength={500}
            />
            <div className="flex justify-between items-center mt-1">
              <span className="text-xs text-gray-500">
                Share what you grow, what you're looking for, or just say hello!
              </span>
              <span className="text-xs text-gray-500">{message.length}/500</span>
            </div>
          </div>

          {/* Garden Produce Selection */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-3">
              What do you grow in your garden? (optional)
            </label>
            <p className="text-xs text-gray-500 mb-3">Select from popular items or add your own</p>
            
            {/* Recommended Produce Chips */}
            <div className="flex flex-wrap gap-2 mb-3">
              {recommendedProduce.map((produce) => {
                const isSelected = gardenProduce.includes(produce);
                return (
                  <button
                    key={produce}
                    type="button"
                    onClick={() => isSelected ? handleRemoveProduce(produce) : handleAddProduce(produce)}
                    className={`px-3 py-1.5 text-sm font-medium rounded-full transition-all ${
                      isSelected 
                        ? 'bg-green-600 text-white shadow-sm' 
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {produce}
                  </button>
                );
              })}
            </div>
            
            {/* Custom Produce Input */}
            <div className="flex gap-2">
              <input
                type="text"
                value={customProduceInput}
                onChange={(e) => setCustomProduceInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddCustomProduce();
                  }
                }}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Add custom produce..."
              />
              <button
                type="button"
                onClick={handleAddCustomProduce}
                disabled={!customProduceInput.trim()}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Add
              </button>
            </div>
            
            {/* Selected Produce Display */}
            {gardenProduce.length > 0 && (
              <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                <div className="text-xs font-medium text-green-900 mb-2">Your Garden ({gardenProduce.length}):</div>
                <div className="flex flex-wrap gap-2">
                  {gardenProduce.map((produce) => (
                    <div
                      key={produce}
                      className="inline-flex items-center gap-1 px-3 py-1 bg-white border border-green-300 text-green-800 text-sm font-medium rounded-full"
                    >
                      {produce}
                      <button
                        type="button"
                        onClick={() => handleRemoveProduce(produce)}
                        className="ml-1 hover:bg-green-100 rounded-full p-0.5 transition-colors"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Media Upload Section */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Add a photo or video (optional)
            </label>

            {media ? (
              // Media Preview
              <div className="relative rounded-lg overflow-hidden bg-gray-100">
                {mediaType === 'image' ? (
                  <img src={media} alt="Upload preview" className="w-full h-64 object-cover" />
                ) : (
                  <video src={media} className="w-full h-64 object-cover" controls />
                )}
                <button
                  onClick={handleRemoveMedia}
                  className="absolute top-2 right-2 p-2 bg-red-600 text-white rounded-full hover:bg-red-700 transition-colors shadow-lg"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              // Upload Buttons
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label className="flex flex-col items-center justify-center gap-2 p-4 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-green-500 hover:bg-green-50 transition-all">
                  <Upload className="w-6 h-6 text-gray-400" />
                  <span className="text-sm font-medium text-gray-700">Upload Photo/Video</span>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*,video/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const type = file.type.startsWith('video/') ? 'video' : 'image';
                        handleMediaUpload(e, type);
                      }
                    }}
                    className="hidden"
                  />
                </label>

                <label className="flex flex-col items-center justify-center gap-2 p-4 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-green-500 hover:bg-green-50 transition-all">
                  <Camera className="w-6 h-6 text-gray-400" />
                  <span className="text-sm font-medium text-gray-700">Take Photo/Video</span>
                  <input
                    ref={cameraInputRef}
                    type="file"
                    accept="image/*,video/*"
                    capture="environment"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const type = file.type.startsWith('video/') ? 'video' : 'image';
                        handleMediaUpload(e, type);
                      }
                    }}
                    className="hidden"
                  />
                </label>
              </div>
            )}
          </div>

          {/* Make First Post Checkbox */}
          <div className="mb-6">
            <label className="flex items-start gap-3 p-4 bg-gray-50 border-2 border-gray-200 rounded-lg cursor-pointer hover:border-green-300 transition-all">
              <input
                type="checkbox"
                checked={makeFirstPost}
                onChange={(e) => setMakeFirstPost(e.target.checked)}
                className="w-6 h-6 text-green-600 border-2 border-gray-300 rounded focus:ring-green-500 focus:ring-2 mt-0.5"
              />
              <div className="flex-1">
                <div className="font-medium text-gray-900 mb-1">Make this my first post</div>
                <div className="text-sm text-gray-600">
                  Share this introduction with your community to break the ice and start connecting with neighbors
                </div>
              </div>
            </label>
          </div>

          {/* Info Box */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <div className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-blue-800">
                <strong>Tip:</strong> Create a fun fact about your garden to introduce yourself to the community! Share what makes your garden unique or what you're excited to grow.
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={onBack}
              className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
            >
              Back
            </button>
            <button
              onClick={onSkip}
              className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
            >
              Skip for Now
            </button>
            <button
              onClick={handleSubmit}
              disabled={!message.trim() && !media}
              className="flex-1 px-6 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
            >
              {makeFirstPost ? 'Post & Continue' : 'Save & Continue'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}