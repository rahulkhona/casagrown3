import React, { useState } from 'react';
import { ArrowLeft, CreditCard, Coins, Check, Building2, AlertCircle } from 'lucide-react';

interface User {
  id: string;
  name: string;
  points: number;
}

interface BuyPointsProps {
  user: User;
  onBack: () => void;
  updateUserPoints: (points: number) => void;
}

// Service fee configuration
const PAYMENT_FEES = {
  creditCard: { type: 'percentage', value: 0.03, label: '3% processing fee' },
  ach: { type: 'flat', value: 1.00, label: '$1.00 processing fee' }
};

export default function BuyPoints({ user, onBack, updateUserPoints }: BuyPointsProps) {
  const [pointsToBuy, setPointsToBuy] = useState('100');
  const [selectedPackage, setSelectedPackage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState('');
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [purchasedPoints, setPurchasedPoints] = useState(0);
  
  // Payment method selection
  const [paymentMethod, setPaymentMethod] = useState<'creditCard' | 'ach' | null>(null);
  
  // Credit card fields
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [billingZip, setBillingZip] = useState('');
  
  // ACH fields
  const [routingNumber, setRoutingNumber] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountType, setAccountType] = useState<'checking' | 'savings'>('checking');

  const packages = [
    { points: 100, price: 10, label: 'Basic', popular: false },
    { points: 250, price: 22.50, label: 'Popular', popular: true },
    { points: 500, price: 40, label: 'Value', popular: false },
    { points: 1000, price: 70, label: 'Best Deal', popular: false }
  ];

  const handleSelectPackage = (points: number) => {
    setPointsToBuy(points.toString());
    setSelectedPackage(points.toString());
  };

  // Calculate costs with fees
  const calculateCosts = () => {
    const pointsNum = parseInt(pointsToBuy) || 0;
    const baseAmount = pointsNum * 0.10;
    const totalAmount = baseAmount; // No fees
    
    return { baseAmount, totalAmount };
  };

  const { baseAmount, totalAmount } = calculateCosts();

  const handleBuyPoints = () => {
    const pointsNum = parseInt(pointsToBuy);
    if (isNaN(pointsNum) || pointsNum <= 0) {
      setErrorMessage('Please enter a valid amount');
      return;
    }

    if (!paymentMethod) {
      setErrorMessage('Please select a payment method');
      return;
    }

    // Validate payment fields
    if (paymentMethod === 'creditCard') {
      if (!cardNumber || !cardExpiry || !cardCvv || !billingZip) {
        setErrorMessage('Please fill in all credit card fields');
        return;
      }
      if (cardNumber.replace(/\s/g, '').length !== 16) {
        setErrorMessage('Please enter a valid 16-digit card number');
        return;
      }
      if (cardCvv.length !== 3) {
        setErrorMessage('Please enter a valid 3-digit CVV');
        return;
      }
      if (billingZip.length !== 5) {
        setErrorMessage('Please enter a valid 5-digit ZIP code');
        return;
      }
    } else if (paymentMethod === 'ach') {
      if (!routingNumber || !accountNumber) {
        setErrorMessage('Please fill in all ACH fields');
        return;
      }
      if (routingNumber.length !== 9) {
        setErrorMessage('Please enter a valid 9-digit routing number');
        return;
      }
    }

    // Clear any previous error
    setErrorMessage('');

    // Mock point purchase (in real app, would process payment)
    updateUserPoints(user.points + pointsNum);
    setPurchasedPoints(pointsNum);
    setShowSuccessModal(true);
    
    // Auto-close modal and navigate back after 2 seconds
    setTimeout(() => {
      setShowSuccessModal(false);
      onBack();
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back</span>
        </button>

        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          {/* Title Section */}
          <div className="bg-gradient-to-r from-green-600 to-green-500 p-8 text-white">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <Coins className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-3xl font-bold">Buy Points</h1>
                <p className="text-green-50">Add points to your CasaGrown account</p>
              </div>
            </div>
            <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
              <div className="flex items-center justify-between">
                <span className="text-green-50">Current Balance</span>
                <span className="text-2xl font-bold">{user.points} points</span>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-8">
            {/* Quick Select Packages */}
            <div className="mb-8">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Choose a Package</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {packages.map((pkg) => (
                  <button
                    key={pkg.points}
                    onClick={() => handleSelectPackage(pkg.points)}
                    className={`relative p-6 border-2 rounded-xl transition-all hover:shadow-lg ${
                      selectedPackage === pkg.points.toString()
                        ? 'border-green-600 bg-green-50'
                        : 'border-gray-200 hover:border-green-300'
                    }`}
                  >
                    {pkg.popular && (
                      <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-green-600 text-white text-xs font-semibold rounded-full">
                        Most Popular
                      </div>
                    )}
                    <div className="text-center">
                      <div className="text-sm text-gray-600 mb-1">{pkg.label}</div>
                      <div className="text-3xl font-bold text-gray-900 mb-2">
                        {pkg.points}
                      </div>
                      <div className="text-sm text-gray-500 mb-3">points</div>
                      <div className="text-2xl font-bold text-green-600">
                        ${pkg.price.toFixed(2)}
                      </div>
                      <div className="text-xs text-gray-500 mt-1">
                        ${(pkg.price / pkg.points).toFixed(2)} per point
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Amount */}
            <div className="mb-8">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Or Enter Custom Amount</h2>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Points to Purchase
                </label>
                <input
                  type="number"
                  value={pointsToBuy}
                  onChange={(e) => {
                    setPointsToBuy(e.target.value);
                    setSelectedPackage(null);
                  }}
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-lg"
                  placeholder="Enter amount"
                  min="1"
                />
                <p className="text-sm text-gray-600 mt-2">
                  Buy minimum 100 points to keep credit card fees low
                </p>
              </div>
            </div>

            {/* Payment Method Selection */}
            <div className="space-y-4">
              <h3 className="font-semibold text-gray-900 mb-4">Select Payment Method</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                {/* Credit Card Option */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('creditCard')}
                  className={`p-6 border-2 rounded-xl transition-all hover:shadow-lg text-left ${
                    paymentMethod === 'creditCard'
                      ? 'border-green-600 bg-green-50'
                      : 'border-gray-200 hover:border-green-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <CreditCard className="w-5 h-5 text-blue-600" />
                    </div>
                    <div className="font-semibold text-gray-900">Credit Card</div>
                  </div>
                </button>

                {/* ACH Option */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('ach')}
                  className={`p-6 border-2 rounded-xl transition-all hover:shadow-lg text-left ${
                    paymentMethod === 'ach'
                      ? 'border-green-600 bg-green-50'
                      : 'border-gray-200 hover:border-green-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                      <Building2 className="w-5 h-5 text-purple-600" />
                    </div>
                    <div className="font-semibold text-gray-900">Bank Transfer (ACH)</div>
                  </div>
                </button>
              </div>

              {/* Credit Card Form */}
              {paymentMethod === 'creditCard' && (
                <div className="bg-gray-50 rounded-lg p-6 space-y-4">
                  <h3 className="font-semibold text-gray-900 mb-4">Credit Card Information</h3>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Card Number
                    </label>
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => {
                        const value = e.target.value.replace(/\s/g, '');
                        if (/^\d*$/.test(value) && value.length <= 16) {
                          setCardNumber(value.replace(/(\d{4})/g, '$1 ').trim());
                        }
                      }}
                      placeholder="1234 5678 9012 3456"
                      maxLength={19}
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="col-span-1">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Expiry
                      </label>
                      <input
                        type="text"
                        value={cardExpiry}
                        onChange={(e) => {
                          let value = e.target.value.replace(/\D/g, '');
                          if (value.length >= 2) {
                            value = value.slice(0, 2) + '/' + value.slice(2, 4);
                          }
                          if (value.length <= 5) {
                            setCardExpiry(value);
                          }
                        }}
                        placeholder="MM/YY"
                        maxLength={5}
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      />
                    </div>
                    
                    <div className="col-span-1">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        CVV
                      </label>
                      <input
                        type="text"
                        value={cardCvv}
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, '');
                          if (value.length <= 3) {
                            setCardCvv(value);
                          }
                        }}
                        placeholder="123"
                        maxLength={3}
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      />
                    </div>

                    <div className="col-span-1">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        ZIP Code
                      </label>
                      <input
                        type="text"
                        value={billingZip}
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, '');
                          if (value.length <= 5) {
                            setBillingZip(value);
                          }
                        }}
                        placeholder="12345"
                        maxLength={5}
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* ACH Form */}
              {paymentMethod === 'ach' && (
                <div className="bg-gray-50 rounded-lg p-6 space-y-4">
                  <h3 className="font-semibold text-gray-900 mb-4">Bank Account Information</h3>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Account Type
                    </label>
                    <div className="flex gap-4">
                      <button
                        type="button"
                        onClick={() => setAccountType('checking')}
                        className={`flex-1 px-4 py-3 border-2 rounded-lg font-medium transition-all ${
                          accountType === 'checking'
                            ? 'border-green-600 bg-green-50 text-green-700'
                            : 'border-gray-300 text-gray-700 hover:border-gray-400'
                        }`}
                      >
                        Checking
                      </button>
                      <button
                        type="button"
                        onClick={() => setAccountType('savings')}
                        className={`flex-1 px-4 py-3 border-2 rounded-lg font-medium transition-all ${
                          accountType === 'savings'
                            ? 'border-green-600 bg-green-50 text-green-700'
                            : 'border-gray-300 text-gray-700 hover:border-gray-400'
                        }`}
                      >
                        Savings
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Routing Number
                    </label>
                    <input
                      type="text"
                      value={routingNumber}
                      onChange={(e) => {
                        const value = e.target.value.replace(/\D/g, '');
                        if (value.length <= 9) {
                          setRoutingNumber(value);
                        }
                      }}
                      placeholder="9 digits"
                      maxLength={9}
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Found on the bottom of your check
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Account Number
                    </label>
                    <input
                      type="text"
                      value={accountNumber}
                      onChange={(e) => {
                        const value = e.target.value.replace(/\D/g, '');
                        if (value.length <= 17) {
                          setAccountNumber(value);
                        }
                      }}
                      placeholder="Account number"
                      maxLength={17}
                      className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Service Fee Explanation */}
            {paymentMethod && (
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-amber-900 mb-1">About Service Fees</h4>
                    <p className="text-sm text-amber-800">
                      CasaGrown passes along payment processing fees from our payment providers (Stripe, Plaid) to keep 
                      the platform sustainable. These fees cover the cost of secure payment processing, fraud protection, 
                      and regulatory compliance. We do not profit from these fees - they go directly to our payment processors.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Summary */}
            <div className="bg-gray-50 rounded-lg p-6 mb-6">
              <h3 className="font-semibold text-gray-900 mb-4">Purchase Summary</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-700">Current Points</span>
                  <span className="font-semibold text-gray-900">{user.points}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-700">Points to Add</span>
                  <span className="font-semibold text-gray-900">
                    {parseInt(pointsToBuy) || 0}
                  </span>
                </div>
                <div className="pt-3 border-t border-gray-300">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-gray-900">New Balance</span>
                    <span className="font-bold text-2xl text-green-600">
                      {user.points + (parseInt(pointsToBuy) || 0)}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Cost Display */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
              <h3 className="font-semibold text-gray-900 mb-3">Cost Breakdown</h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-gray-700">
                  <span>{parseInt(pointsToBuy) || 0} points × $0.10</span>
                  <span className="font-medium">${baseAmount.toFixed(2)}</span>
                </div>
                <div className="pt-3 border-t-2 border-blue-300">
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-semibold text-gray-900">Total Amount</span>
                    <span className="text-3xl font-bold text-gray-900">
                      ${totalAmount.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
              <p className="text-sm text-gray-600 mt-3">
                Secure payment processing
              </p>
            </div>

            {/* Info Box */}
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
              <h4 className="font-semibold text-green-900 mb-2">How Points Work</h4>
              <ul className="text-sm text-green-800 space-y-1">
                <li>• Use points to purchase produce and services from neighbors</li>
                <li>• Earn points by selling your backyard produce</li>
                <li>• Redeem points for gift cards or donate to charity</li>
                <li>• Points never expire and can be transferred to community members</li>
              </ul>
            </div>

            {/* Error Message */}
            {errorMessage && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
                <p className="text-sm text-red-800">{errorMessage}</p>
              </div>
            )}

            {/* Purchase Button */}
            <div className="flex gap-3">
              <button
                onClick={onBack}
                className="flex-1 px-6 py-4 border-2 border-gray-300 text-gray-700 font-semibold text-lg rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleBuyPoints}
                disabled={!pointsToBuy || parseInt(pointsToBuy) <= 0 || !paymentMethod}
                className="flex-1 flex items-center justify-center gap-2 px-6 py-4 bg-green-600 text-white font-semibold text-lg rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
              >
                <CreditCard className="w-6 h-6" />
                Purchase {parseInt(pointsToBuy) || 0} Points
              </button>
            </div>

            <p className="text-center text-xs text-gray-500 mt-4">
              This is a mock payment for MVP testing. No actual charges will be made.
            </p>
          </div>
        </div>
      </div>

      {/* Success Modal */}
      {showSuccessModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Purchase Successful!</h3>
            <p className="text-gray-600">
              You have successfully purchased {purchasedPoints} points!
            </p>
          </div>
        </div>
      )}
    </div>
  );
}