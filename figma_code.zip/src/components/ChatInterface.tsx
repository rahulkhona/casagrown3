import React, { useState, useRef, useEffect } from 'react';
import { Send, X, ShoppingCart, AlertTriangle, CheckCircle, RefreshCw, MapPin, Star, Calendar } from 'lucide-react';
import AddressInput from './AddressInput';

interface Message {
  id: string;
  senderId: string;
  senderName: string;
  text?: string;
  imageUrl?: string;
  timestamp: Date;
}

interface ChatInterfaceProps {
  currentUserId: string;
  currentUserName: string;
  otherUserId: string;
  otherUserName: string;
  postTitle: string;
  postType: 'sell' | 'buy' | 'service-request' | 'service-offer' | 'advice' | 'show-and-tell';
  onClose: () => void;
  onMakeOffer?: () => void;
  onAgreeToSell?: () => void;
  // Dispute mode props
  isDisputeMode?: boolean;
  isBuyerInDispute?: boolean;
  dropoffPhoto?: string;
  disputePhoto?: string;
  disputeReason?: string;
  onResolveDispute?: () => void;
  onRefundDispute?: () => void;
  onEscalateDispute?: () => void;
  // Seller address props
  isCurrentUserSeller?: boolean;
  savedAddress?: string;
  buyerPostedAgreement?: boolean; // Whether buyer has already posted agreement
  buyAgreementDetails?: string; // Buy agreement details to show in buyer's chat
  sellerHasAgreed?: boolean; // Whether seller has agreed to sell
  // Post details
  postData?: {
    id: string;
    authorName: string;
    authorRating?: number;
    authorTotalReviews?: number;
    category: string;
    description: string;
    price?: number;
    unit?: string;
    imageUrl?: string;
  };
  // Drop-off form state (for buyers)
  dropoffFormData?: {
    quantity: string;
    address: string;
    latestDate: string;
    instructions?: string;
  };
  // Embedded mode (for inline chat in modals)
  embedded?: boolean;
  // User points balance
  currentUserPoints?: number;
  onBuyPoints?: () => void;
}

export default function ChatInterface({
  currentUserId,
  currentUserName,
  otherUserId,
  otherUserName,
  postTitle,
  postType,
  onClose,
  onMakeOffer,
  onAgreeToSell,
  // Dispute mode props
  isDisputeMode,
  isBuyerInDispute,
  dropoffPhoto,
  disputePhoto,
  disputeReason,
  onResolveDispute,
  onRefundDispute,
  onEscalateDispute,
  // Seller address props
  isCurrentUserSeller = false,
  savedAddress = '',
  buyerPostedAgreement = false,
  buyAgreementDetails = '',
  sellerHasAgreed = false,
  // Post details
  postData,
  // Drop-off form state (for buyers)
  dropoffFormData,
  // Embedded mode
  embedded = false,
  // User points balance
  currentUserPoints,
  onBuyPoints
}: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>(() => {
    // If in dispute mode, initialize with dispute photos and reason
    if (isDisputeMode && dropoffPhoto && disputePhoto && disputeReason) {
      return [
        {
          id: '1',
          senderId: otherUserId,
          senderName: otherUserName,
          text: 'Here is the photo I took when I delivered the items:',
          timestamp: new Date(Date.now() - 3600000)
        },
        {
          id: '2',
          senderId: otherUserId,
          senderName: otherUserName,
          imageUrl: dropoffPhoto,
          timestamp: new Date(Date.now() - 3500000)
        },
        {
          id: '3',
          senderId: currentUserId,
          senderName: currentUserName,
          text: `I have a concern about the delivery: ${disputeReason}`,
          timestamp: new Date(Date.now() - 3000000)
        },
        {
          id: '4',
          senderId: currentUserId,
          senderName: currentUserName,
          text: 'Here is the photo of what I received:',
          timestamp: new Date(Date.now() - 2900000)
        },
        {
          id: '5',
          senderId: currentUserId,
          senderName: currentUserName,
          imageUrl: disputePhoto,
          timestamp: new Date(Date.now() - 2800000)
        }
      ];
    }
    
    // If buyer has posted agreement, show it in the messages
    if (buyerPostedAgreement && isCurrentUserSeller) {
      return [
        {
          id: '1',
          senderId: otherUserId,
          senderName: otherUserName,
          text: `Hi! I'm interested in \"${postTitle}\". Is this still available?`,
          timestamp: new Date(Date.now() - 7200000)
        },
        {
          id: '2',
          senderId: currentUserId,
          senderName: currentUserName,
          text: 'Yes, it is! What quantity are you looking for?',
          timestamp: new Date(Date.now() - 6600000)
        },
        {
          id: '3',
          senderId: otherUserId,
          senderName: otherUserName,
          text: 'I would like 2 lbs. Would 45 points work for you?',
          timestamp: new Date(Date.now() - 6000000)
        },
        {
          id: '4',
          senderId: currentUserId,
          senderName: currentUserName,
          text: 'That sounds good! When would you like to pick it up?',
          timestamp: new Date(Date.now() - 5400000)
        },
        {
          id: '5',
          senderId: otherUserId,
          senderName: otherUserName,
          text: 'How about this Saturday at 2 PM?',
          timestamp: new Date(Date.now() - 4800000)
        },
        {
          id: '6',
          senderId: currentUserId,
          senderName: currentUserName,
          text: 'Perfect! Saturday at 2 PM works for me.',
          timestamp: new Date(Date.now() - 4200000)
        },
        {
          id: '7',
          senderId: otherUserId,
          senderName: otherUserName,
          text: '📋 Buy Agreement Posted:\n\nQuantity: 2 lbs\nPrice: 45 points\nPickup: Saturday, Feb 1 at 2 PM\nAddress: 123 Garden Lane, Springfield',
          timestamp: new Date(Date.now() - 3600000)
        }
      ];
    }
    
    // If buyer just submitted agreement (buyer view with buyAgreementDetails)
    if (buyAgreementDetails && !isCurrentUserSeller) {
      return [
        {
          id: '1',
          senderId: otherUserId,
          senderName: otherUserName,
          text: `Hi! I'm interested in \\"${postTitle}\\". Is this still available?`,
          timestamp: new Date(Date.now() - 7200000)
        },
        {
          id: '2',
          senderId: currentUserId,
          senderName: currentUserName,
          text: buyAgreementDetails,
          timestamp: new Date(Date.now() - 100)
        }
      ];
    }
    
    return [
      {
        id: '1',
        senderId: otherUserId,
        senderName: otherUserName,
        text: `Hi! I'm interested in \"${postTitle}\". Is this still available?`,
        timestamp: new Date(Date.now() - 3600000)
      }
    ];
  });
  const [newMessage, setNewMessage] = useState('');
  const [showGuidance, setShowGuidance] = useState(!isDisputeMode);
  const [showAddressModal, setShowAddressModal] = useState(false);
  const [addressToShare, setAddressToShare] = useState(savedAddress);
  const [hasAgreedToSell, setHasAgreedToSell] = useState(sellerHasAgreed);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Drop-off form state for buyers
  const [quantity, setQuantity] = useState(dropoffFormData?.quantity || '');
  const [deliveryAddress, setDeliveryAddress] = useState(dropoffFormData?.address || '');
  const [latestDate, setLatestDate] = useState(dropoffFormData?.latestDate || '');
  const [dropoffInstructions, setDropoffInstructions] = useState(dropoffFormData?.instructions || '');
  const [requestSubmitted, setRequestSubmitted] = useState(!!dropoffFormData); // If dropoffFormData exists, request is already submitted
  const [showDropoffForm, setShowDropoffForm] = useState(false);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Update addressToShare when savedAddress changes
  useEffect(() => {
    if (savedAddress) {
      setAddressToShare(savedAddress);
    }
  }, [savedAddress]);

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    const message: Message = {
      id: Math.random().toString(36).substr(2, 9),
      senderId: currentUserId,
      senderName: currentUserName,
      text: newMessage,
      timestamp: new Date()
    };

    setMessages([...messages, message]);
    setNewMessage('');

    // Simulate response (mock)
    setTimeout(() => {
      const response: Message = {
        id: Math.random().toString(36).substr(2, 9),
        senderId: otherUserId,
        senderName: otherUserName,
        text: "Yes, it's available! Feel free to submit a buy agreement.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, response]);
    }, 1500);
  };

  const handleShareAddress = () => {
    if (!addressToShare.trim()) return;

    const message: Message = {
      id: Math.random().toString(36).substr(2, 9),
      senderId: currentUserId,
      senderName: currentUserName,
      text: `📍 My address: ${addressToShare}`,
      timestamp: new Date()
    };

    setMessages([...messages, message]);
    setShowAddressModal(false);
  };

  const handleUseCurrentLocation = () => {
    // Simulate getting current location
    // In a real app, this would use the Geolocation API
    setAddressToShare('Current Location: 123 Garden Lane, Springfield');
  };

  const formatTime = (date: Date) => {
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const displayHours = hours % 12 || 12;
    return `${displayHours}:${minutes.toString().padStart(2, '0')} ${ampm}`;
  };

  // Get guidance based on post type
  const getGuidanceContent = () => {
    switch (postType) {
      case 'sell':
        return {
          title: 'Selling Guidance',
          items: [
            'Discuss and agree on the exact quantity and price',
            'Confirm a specific pickup location (address)',
            'Set a date and time that works for both parties',
            'Once agreed, the buyer can submit a buy agreement'
          ],
          color: 'green'
        };
      case 'buy':
        return {
          title: 'Buying Request Guidance',
          items: [
            'Clarify the quantity and quality you\'re looking for',
            'Discuss your preferred pickup location and timing',
            'Negotiate on price that works for both parties',
            'Once agreed, click "Buy Agreement" to finalize'
          ],
          color: 'blue'
        };
      case 'service-offer':
        return {
          title: 'Service Offer Guidance',
          items: [
            'Discuss the specific service scope and requirements',
            'Agree on the date and time for service',
            'Negotiate a fair price in points',
            'Confirm the service location and any special needs'
          ],
          color: 'orange'
        };
      case 'service-request':
        return {
          title: 'Service Request Guidance',
          items: [
            'Describe the service you need in detail',
            'Share your preferred date and time availability',
            'Discuss and agree on a price in points',
            'Provide exact location and access information'
          ],
          color: 'purple'
        };
      default:
        return {
          title: 'Transaction Guidance',
          items: [
            'Discuss and agree on the exact quantity and price',
            'Confirm a specific pickup location (address)',
            'Set a date and time that works for both parties',
            'Once agreed, click "Buy Agreement" below to finalize'
          ],
          color: 'blue'
        };
    }
  };

  const guidance = getGuidanceContent();
  const colorClasses = {
    green: 'bg-green-50 border-green-200 text-green-900 text-green-800 text-green-600 hover:text-green-800',
    blue: 'bg-blue-50 border-blue-200 text-blue-900 text-blue-800 text-blue-600 hover:text-blue-800',
    orange: 'bg-orange-50 border-orange-200 text-orange-900 text-orange-800 text-orange-600 hover:text-orange-800',
    purple: 'bg-purple-50 border-purple-200 text-purple-900 text-purple-800 text-purple-600 hover:text-purple-800'
  };

  // Get action button based on post type
  const getActionButton = () => {
    if (postType === 'sell') {
      // For sell posts
      if (isCurrentUserSeller) {
        // Seller view: only show "Agree to Sell" after buyer has posted agreement and before seller agrees
        if (buyerPostedAgreement && !hasAgreedToSell) {
          return {
            label: 'Agree to Sell',
            icon: CheckCircle,
            show: true
          };
        }
        return { show: false };
      } else {
        // Buyer view: show "Submit Request" button if they haven't submitted yet
        if (!requestSubmitted) {
          return {
            label: 'Submit Request',
            icon: ShoppingCart,
            show: true
          };
        }
        return { show: false };
      }
    }
    if (postType === 'buy') {
      return {
        label: 'Submit Request',
        icon: ShoppingCart,
        show: true
      };
    }
    // Service posts only have simple chat, no action buttons
    return { show: false };
  };

  const actionButton = getActionButton();

  // Handle submit request for buyers
  const handleSubmitRequest = () => {
    // Validate form
    if (!quantity || !deliveryAddress || !latestDate) {
      alert('Please fill out all required fields in the drop-off form.');
      return;
    }

    // Calculate total
    const total = postData?.price ? Math.round(parseFloat(quantity) * postData.price) : 0;

    // Build the system message text
    let messageText = `📦 Drop-off request submitted!\n\nQuantity: ${quantity} ${postData?.unit || 'units'}\nDeliver to: ${deliveryAddress}\nBy: ${new Date(latestDate).toLocaleDateString()}`;
    
    if (dropoffInstructions) {
      messageText += `\nInstructions: ${dropoffInstructions}`;
    }
    
    messageText += `\nTotal: ${total} points\n\nWaiting for seller confirmation...`;

    // Create system message
    const requestMessage: Message = {
      id: Math.random().toString(36).substr(2, 9),
      senderId: 'system',
      senderName: 'CasaGrown',
      text: messageText,
      timestamp: new Date()
    };

    setMessages([...messages, requestMessage]);
    setRequestSubmitted(true);
  };

  // Get color classes for guidance banner
  const getGuidanceColorClasses = () => {
    switch (guidance.color) {
      case 'green':
        return {
          bg: 'bg-green-50',
          border: 'border-green-200',
          title: 'text-green-900',
          text: 'text-green-800',
          button: 'text-green-600 hover:text-green-800'
        };
      case 'blue':
        return {
          bg: 'bg-blue-50',
          border: 'border-blue-200',
          title: 'text-blue-900',
          text: 'text-blue-800',
          button: 'text-blue-600 hover:text-blue-800'
        };
      case 'orange':
        return {
          bg: 'bg-orange-50',
          border: 'border-orange-200',
          title: 'text-orange-900',
          text: 'text-orange-800',
          button: 'text-orange-600 hover:text-orange-800'
        };
      case 'purple':
        return {
          bg: 'bg-purple-50',
          border: 'border-purple-200',
          title: 'text-purple-900',
          text: 'text-purple-800',
          button: 'text-purple-600 hover:text-purple-800'
        };
      default:
        return {
          bg: 'bg-blue-50',
          border: 'border-blue-200',
          title: 'text-blue-900',
          text: 'text-blue-800',
          button: 'text-blue-600 hover:text-blue-800'
        };
    }
  };

  const guidanceColors = getGuidanceColorClasses();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end sm:items-center justify-center z-50 p-0 sm:p-4">
      <div className="bg-white w-full h-full sm:h-[90vh] sm:max-w-3xl sm:rounded-2xl flex flex-col shadow-xl">
        {/* Header */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-4 border-b border-gray-200 bg-white sm:rounded-t-2xl">
          <div>
            <h3 className="font-bold text-gray-900">Chat with {otherUserName}</h3>
            <p className="text-sm text-gray-500">About: {postTitle}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Post Card - SERVICE posts (always visible for context) */}
        {(postType === 'service-request' || postType === 'service-offer') && postData && (
          <div className="px-4 sm:px-6 py-4 bg-gray-50 border-b border-gray-200">
            <div className="bg-white rounded-lg overflow-hidden shadow-sm">
              {postData.imageUrl && (
                <img src={postData.imageUrl} alt={postTitle} className="w-full h-48 object-cover" />
              )}
              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-1">{postTitle}</h4>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-sm text-gray-600">{postData.category}</span>
                      {postData.authorRating && postData.authorTotalReviews && (
                        <>
                          <span className="text-gray-300">·</span>
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                            <span className="text-xs font-medium text-gray-900">{postData.authorRating.toFixed(1)}</span>
                            <span className="text-xs text-gray-500">({postData.authorTotalReviews})</span>
                          </div>
                        </>
                      )}
                    </div>
                    <p className="text-sm text-gray-600">{postData.description}</p>
                  </div>
                </div>
                {postData.price && (
                  <div className="flex items-center gap-2 mt-3 pt-3 border-t border-gray-100">
                    <span className="text-lg font-bold text-green-600">{postData.price} points</span>
                    {postData.unit && (
                      <span className="text-sm text-gray-500">per {postData.unit}</span>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Post Card - BUYER side (before order submitted, for context) */}
        {postType === 'sell' && !isCurrentUserSeller && !requestSubmitted && postData && (
          <div className="px-4 sm:px-6 py-4 bg-gray-50 border-b border-gray-200">
            <div className="bg-white rounded-lg overflow-hidden shadow-sm">
              {postData.imageUrl && (
                <img src={postData.imageUrl} alt={postTitle} className="w-full h-48 object-cover" />
              )}
              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-1">{postTitle}</h4>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-sm text-gray-600">{postData.category}</span>
                      {postData.authorRating && postData.authorTotalReviews && (
                        <>
                          <span className="text-gray-300">·</span>
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                            <span className="text-xs font-medium text-gray-900">{postData.authorRating.toFixed(1)}</span>
                            <span className="text-xs text-gray-500">({postData.authorTotalReviews})</span>
                          </div>
                        </>
                      )}
                    </div>
                    <p className="text-sm text-gray-600">{postData.description}</p>
                  </div>
                </div>
                {postData.price && (
                  <div className="flex items-center gap-2 mt-3 pt-3 border-t border-gray-100">
                    <span className="text-lg font-bold text-green-600">{postData.price} points</span>
                    {postData.unit && (
                      <span className="text-sm text-gray-500">per {postData.unit}</span>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Post Card - SELLER side (always visible) */}
        {postType === 'sell' && isCurrentUserSeller && postData && (
          <div className="px-4 sm:px-6 py-4 bg-gray-50 border-b border-gray-200">
            <div className="bg-white rounded-lg overflow-hidden shadow-sm">
              {postData.imageUrl && (
                <img src={postData.imageUrl} alt={postTitle} className="w-full h-48 object-cover" />
              )}
              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-1">{postTitle}</h4>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-sm text-gray-600">{postData.category}</span>
                      {postData.authorRating && postData.authorTotalReviews && (
                        <>
                          <span className="text-gray-300">·</span>
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                            <span className="text-xs font-medium text-gray-900">{postData.authorRating.toFixed(1)}</span>
                            <span className="text-xs text-gray-500">({postData.authorTotalReviews})</span>
                          </div>
                        </>
                      )}
                    </div>
                    <p className="text-sm text-gray-600">{postData.description}</p>
                  </div>
                </div>
                {postData.price && (
                  <div className="flex items-center gap-2 mt-3 pt-3 border-t border-gray-100">
                    <span className="text-lg font-bold text-green-600">{postData.price} points</span>
                    {postData.unit && (
                      <span className="text-sm text-gray-500">per {postData.unit}</span>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Compact Post Card - BUYER side (after order submitted) */}
        {postType === 'sell' && !isCurrentUserSeller && requestSubmitted && postData && (
          <div className="px-4 sm:px-6 py-4 bg-white border-b border-gray-200">
            <div className="flex gap-4">
              {postData.imageUrl && (
                <div className="flex-shrink-0">
                  <img 
                    src={postData.imageUrl} 
                    alt={postData.category}
                    className="w-20 h-20 rounded-lg object-cover"
                  />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900">{postTitle}</h3>
                    <p className="text-sm text-gray-600">{postData.category}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-gray-500">{postData.authorName}</span>
                      {postData.authorRating && (
                        <div className="flex items-center gap-1">
                          <Star className="w-3 h-3 text-yellow-400 fill-current" />
                          <span className="text-xs text-gray-600">
                            {postData.authorRating} ({postData.authorTotalReviews})
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                  {postData.price && (
                    <div className="text-right flex-shrink-0">
                      <div className="font-bold text-green-600">{postData.price} pts</div>
                      {postData.unit && (
                        <div className="text-xs text-gray-500">per {postData.unit}</div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Order Summary - BUYER side (after order submitted) */}
        {postType === 'sell' && !isCurrentUserSeller && requestSubmitted && (
          <div className="px-4 sm:px-6 py-3 bg-green-50 border-b border-green-200">
            <div className="bg-white rounded-lg p-4 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold text-gray-900">Order Details</h4>
                <span className="text-xs font-medium px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full">
                  Pending Confirmation
                </span>
              </div>
              <div className="space-y-2 text-sm">
                {quantity && (
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Quantity:</span>
                    <span className="font-medium text-gray-900">
                      {quantity} {postData?.unit || 'units'}
                    </span>
                  </div>
                )}
                {deliveryAddress && (
                  <div className="flex items-start justify-between">
                    <span className="text-gray-600">Deliver to:</span>
                    <span className="font-medium text-gray-900 text-right max-w-[60%]">{deliveryAddress}</span>
                  </div>
                )}
                {latestDate && (
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">By:</span>
                    <span className="font-medium text-gray-900">{new Date(latestDate).toLocaleDateString()}</span>
                  </div>
                )}
                {dropoffInstructions && (
                  <div className="flex items-start justify-between">
                    <span className="text-gray-600">Instructions:</span>
                    <span className="font-medium text-gray-900 text-right max-w-[60%]">{dropoffInstructions}</span>
                  </div>
                )}
                {postData?.price && quantity && (
                  <div className="flex items-center justify-between pt-2 border-t border-gray-200">
                    <span className="font-semibold text-gray-900">Total:</span>
                    <span className="text-lg font-bold text-green-600">
                      {Math.round(parseFloat(quantity) * postData.price)} points
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Drop-off Form for Buyers (compact summary with edit link) */}
        {!isCurrentUserSeller && !requestSubmitted && postType === 'sell' && (
          <div className="px-4 sm:px-6 py-3 bg-green-50 border-b border-green-200">
            {showDropoffForm ? (
              // Expanded Form View
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-semibold text-gray-900">Drop-Off Request</h4>
                  <button
                    onClick={() => setShowDropoffForm(false)}
                    className="text-sm text-green-600 hover:text-green-700 font-medium"
                  >
                    Collapse
                  </button>
                </div>
                
                <div className="space-y-4">
                  {/* Quantity Input */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Quantity {postData?.unit && `(${postData.unit})`}
                    </label>
                    <input
                      type="number"
                      value={quantity}
                      onChange={(e) => setQuantity(e.target.value)}
                      placeholder="Enter quantity"
                      min="0.1"
                      step="0.1"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                    {/* Total Points Display */}
                    {quantity && postData?.price && (
                      <div className="mt-2 flex items-center justify-between text-sm">
                        <span className="text-gray-600">Total Cost:</span>
                        <span className="font-bold text-green-600">
                          {Math.round(parseFloat(quantity) * postData.price)} points
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Delivery Address */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Delivery Address
                    </label>
                    <AddressInput
                      value={deliveryAddress}
                      onChange={(value) => setDeliveryAddress(value)}
                      placeholder="Enter your delivery address"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  {/* Latest Delivery Date */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Deliver By (Latest Date)
                    </label>
                    <input
                      type="date"
                      value={latestDate}
                      onChange={(e) => setLatestDate(e.target.value)}
                      min={new Date().toISOString().split('T')[0]}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>

                  {/* Drop-off Instructions */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Drop-off Instructions
                    </label>
                    <textarea
                      value={dropoffInstructions}
                      onChange={(e) => setDropoffInstructions(e.target.value)}
                      placeholder="Enter any special instructions for drop-off"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      rows={3}
                    />
                  </div>

                  {/* Insufficient Points Warning */}
                  {quantity && postData?.price && currentUserPoints !== undefined && 
                   parseFloat(quantity) * postData.price > currentUserPoints && (
                    <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                      <div className="flex items-start gap-2 mb-2">
                        <AlertTriangle className="w-4 h-4 text-orange-600 flex-shrink-0 mt-0.5" />
                        <div className="flex-1">
                          <p className="text-xs font-semibold text-orange-900">Insufficient Points</p>
                          <p className="text-xs text-orange-700 mt-1">
                            You need {Math.round(parseFloat(quantity) * postData.price - currentUserPoints)} more points.
                          </p>
                        </div>
                      </div>
                      {onBuyPoints && (
                        <button
                          onClick={onBuyPoints}
                          className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-orange-600 text-white text-sm font-medium rounded-lg hover:bg-orange-700 transition-colors"
                        >
                          <ShoppingCart className="w-4 h-4" />
                          Buy Points
                        </button>
                      )}
                    </div>
                  )}

                  {/* Submit Request Button */}
                  <button
                    onClick={handleSubmitRequest}
                    className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
                  >
                    <ShoppingCart className="w-5 h-5" />
                    Submit Request
                  </button>
                </div>
              </div>
            ) : (
              // Compact Summary View
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-semibold text-gray-900">Drop-Off Request</h4>
                  <button
                    onClick={() => setShowDropoffForm(true)}
                    className="text-xs text-green-600 hover:text-green-700 font-medium"
                  >
                    Edit
                  </button>
                </div>
                
                <div className="space-y-2 text-sm">
                  {quantity ? (
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Quantity:</span>
                      <span className="font-medium text-gray-900">
                        {quantity} {postData?.unit || 'units'}
                      </span>
                    </div>
                  ) : (
                    <p className="text-xs text-orange-600">Quantity not set</p>
                  )}
                  
                  {deliveryAddress ? (
                    <div className="flex items-start justify-between">
                      <span className="text-gray-600">Deliver to:</span>
                      <span className="font-medium text-gray-900 text-right max-w-[60%]">{deliveryAddress}</span>
                    </div>
                  ) : (
                    <p className="text-xs text-orange-600">Address not set</p>
                  )}
                  
                  {latestDate ? (
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">By:</span>
                      <span className="font-medium text-gray-900">{new Date(latestDate).toLocaleDateString()}</span>
                    </div>
                  ) : (
                    <p className="text-xs text-orange-600">Date not set</p>
                  )}
                  
                  {dropoffInstructions && (
                    <div className="flex items-start justify-between">
                      <span className="text-gray-600">Instructions:</span>
                      <span className="font-medium text-gray-900 text-right max-w-[60%]">{dropoffInstructions}</span>
                    </div>
                  )}
                  
                  {postData?.price && quantity && (
                    <div className="flex items-center justify-between pt-2 border-t border-gray-200">
                      <span className="font-semibold text-gray-900">Total:</span>
                      <span className="text-lg font-bold text-green-600">
                        {Math.round(parseFloat(quantity) * postData.price)} points
                      </span>
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="mt-4 space-y-2">
                  {/* Insufficient Points Warning & Buy Points Button */}
                  {quantity && postData?.price && currentUserPoints !== undefined && 
                   parseFloat(quantity) * postData.price > currentUserPoints && (
                    <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                      <div className="flex items-start gap-2 mb-2">
                        <AlertTriangle className="w-4 h-4 text-orange-600 flex-shrink-0 mt-0.5" />
                        <div className="flex-1">
                          <p className="text-xs font-semibold text-orange-900">Insufficient Points</p>
                          <p className="text-xs text-orange-700 mt-1">
                            You need {Math.round(parseFloat(quantity) * postData.price - currentUserPoints)} more points.
                          </p>
                        </div>
                      </div>
                      {onBuyPoints && (
                        <button
                          onClick={onBuyPoints}
                          className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-orange-600 text-white text-sm font-medium rounded-lg hover:bg-orange-700 transition-colors"
                        >
                          <ShoppingCart className="w-4 h-4" />
                          Buy Points
                        </button>
                      )}
                    </div>
                  )}

                  {/* Submit Order Button */}
                  {quantity && deliveryAddress && latestDate && (
                    <button
                      onClick={handleSubmitRequest}
                      disabled={postData?.price && currentUserPoints !== undefined && parseFloat(quantity) * postData.price > currentUserPoints}
                      className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
                    >
                      <ShoppingCart className="w-5 h-5" />
                      Submit Request
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-4 space-y-4 bg-gray-50">
          {messages.map((message) => {
            const isCurrentUser = message.senderId === currentUserId;
            const isSystemMessage = message.senderId === 'system';
            
            // System messages get special styling
            if (isSystemMessage) {
              return (
                <div key={message.id} className="flex justify-center">
                  <div className="max-w-[85%] bg-blue-50 border border-blue-200 rounded-lg px-4 py-3">
                    <p className="text-sm text-blue-900 text-center">{message.text}</p>
                    <p className="text-xs text-blue-600 mt-1 text-center">
                      {formatTime(message.timestamp)}
                    </p>
                  </div>
                </div>
              );
            }
            
            return (
              <div
                key={message.id}
                className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[75%] ${isCurrentUser ? 'order-2' : 'order-1'}`}>
                  {!isCurrentUser && (
                    <p className="text-xs text-gray-500 mb-1 ml-1">{message.senderName}</p>
                  )}
                  <div
                    className={`px-4 py-2 rounded-2xl ${
                      isCurrentUser
                        ? 'bg-green-600 text-white rounded-br-sm'
                        : 'bg-white text-gray-900 rounded-bl-sm border border-gray-200'
                    }`}
                  >
                    {message.imageUrl ? (
                      <img
                        src={message.imageUrl}
                        alt="Message"
                        className="max-w-full max-h-48"
                      />
                    ) : (
                      <p className="text-sm">{message.text}</p>
                    )}
                  </div>
                  <p className="text-xs text-gray-400 mt-1 ml-1">
                    {formatTime(message.timestamp)}
                  </p>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Dispute Resolution Buttons */}
        {isDisputeMode && (
          <div className="px-4 sm:px-6 py-3 border-t border-gray-200 bg-white space-y-2">
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-3">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-red-900 text-sm">Delivery Dispute Active</h4>
                  <p className="text-xs text-red-700 mt-1">
                    {isBuyerInDispute 
                      ? 'Work with the seller to resolve the issue, or escalate to CasaGrown admin if needed.'
                      : 'Work with the buyer to resolve the issue or issue a refund.'}
                  </p>
                </div>
              </div>
            </div>

            {isBuyerInDispute ? (
              // Buyer buttons
              <div className="flex gap-2">
                <button
                  onClick={onResolveDispute}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
                >
                  <CheckCircle className="w-5 h-5" />
                  Mark as Resolved
                </button>
                <button
                  onClick={onEscalateDispute}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 text-white font-medium rounded-lg hover:bg-orange-700 transition-colors"
                >
                  <AlertTriangle className="w-5 h-5" />
                  Escalate to Admin
                </button>
              </div>
            ) : (
              // Seller buttons
              <div className="flex gap-2">
                <button
                  onClick={onRefundDispute}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-red-600 text-white font-medium rounded-lg hover:bg-red-700 transition-colors"
                >
                  <RefreshCw className="w-5 h-5" />
                  Issue Refund
                </button>
                <button
                  onClick={onEscalateDispute}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 text-white font-medium rounded-lg hover:bg-orange-700 transition-colors"
                >
                  <AlertTriangle className="w-5 h-5" />
                  Escalate to Admin
                </button>
              </div>
            )}
          </div>
        )}

        {/* Message Input */}
        <div className="px-4 sm:px-6 py-4 border-t border-gray-200 bg-white sm:rounded-b-2xl">
          <div className="flex gap-2">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Type a message..."
              className="flex-1 px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
            <button
              onClick={handleSendMessage}
              disabled={!newMessage.trim()}
              className="p-2 bg-green-600 text-white rounded-full hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Share Address Modal */}
      {showAddressModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[60] p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Share Your Address</h3>
            <p className="text-gray-600 mb-4 text-sm">
              Share your address with {otherUserName} for pickup or delivery coordination.
            </p>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Your Address
                </label>
                <AddressInput
                  value={addressToShare}
                  onChange={(value) => setAddressToShare(value)}
                  placeholder="Enter your address"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>

              <button
                onClick={handleUseCurrentLocation}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-50 text-blue-700 font-medium rounded-lg border-2 border-blue-200 hover:bg-blue-100 transition-colors"
              >
                <MapPin className="w-5 h-5" />
                Use Current Location
              </button>

              <div className="bg-gray-50 border border-gray-200 rounded-lg p-3">
                <p className="text-xs text-gray-600">
                  <strong>Privacy Note:</strong> Your address will only be visible to {otherUserName} in this conversation.
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowAddressModal(false);
                  setAddressToShare(savedAddress);
                }}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleShareAddress}
                disabled={!addressToShare.trim()}
                className="flex-1 px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Share Address
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}