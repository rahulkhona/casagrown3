import React, { useState } from 'react';
import { ArrowLeft, Search, Star, MapPin, UserPlus, UserCheck, TrendingUp, Users as UsersIcon } from 'lucide-react';

interface User {
  id: string;
  name: string;
  points: number;
}

interface UserSearchPageProps {
  currentUser: User;
  onBack: () => void;
  onViewUserPosts: (userId: string) => void;
  onFollowToggle: (userId: string) => void;
  followingUsers: Set<string>;
}

interface SearchUser {
  id: string;
  name: string;
  photo?: string;
  bio: string;
  rating: number;
  totalReviews: number;
  communities: string[];
  specialties: string[];
  totalPosts: number;
  totalTransactions: number;
}

export default function UserSearchPage({ currentUser, onBack, onViewUserPosts, onFollowToggle, followingUsers }: UserSearchPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'following' | 'top-rated'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Mock users database
  const allUsers: SearchUser[] = [
    {
      id: '2',
      name: 'Sarah Johnson',
      photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400',
      bio: 'Passionate organic gardener specializing in heirloom tomatoes and herbs.',
      rating: 5.0,
      totalReviews: 47,
      communities: ['Lincoln High School Community'],
      specialties: ['Tomatoes', 'Herbs', 'Composting'],
      totalPosts: 28,
      totalTransactions: 134
    },
    {
      id: '3',
      name: 'Michael Chen',
      photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400',
      bio: 'Home chef and fruit enthusiast. Always looking for fresh, locally-grown produce.',
      rating: 4.9,
      totalReviews: 32,
      communities: ['Washington High School Community'],
      specialties: ['Fruits', 'Berries', 'Cooking'],
      totalPosts: 19,
      totalTransactions: 87
    },
    {
      id: '4',
      name: 'David Martinez',
      photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400',
      bio: 'Retired professional landscaper with 30 years of experience. Happy to share my tools and knowledge.',
      rating: 4.9,
      totalReviews: 23,
      communities: ['Lincoln High School Community', 'Roosevelt High School Community'],
      specialties: ['Equipment', 'Landscaping', 'Fruit Trees'],
      totalPosts: 15,
      totalTransactions: 56
    },
    {
      id: '5',
      name: 'Jessica Martinez',
      photo: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400',
      bio: 'High school junior building my lawn care business. Reliable, affordable, and passionate.',
      rating: 4.8,
      totalReviews: 31,
      communities: ['Lincoln High School Community'],
      specialties: ['Lawn Care', 'Weeding', 'Yard Cleanup'],
      totalPosts: 24,
      totalTransactions: 78
    },
    {
      id: '6',
      name: 'Lisa Wong',
      photo: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=400',
      bio: 'Berry farmer and jam maker. Love sharing my seasonal fruit harvests with neighbors.',
      rating: 4.7,
      totalReviews: 19,
      communities: ['Lincoln High School Community'],
      specialties: ['Berries', 'Fruits', 'Preserves'],
      totalPosts: 32,
      totalTransactions: 94
    },
    {
      id: '7',
      name: 'Tom Anderson',
      photo: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400',
      bio: 'Urban farmer and sustainability advocate. Growing food in the city for 15+ years.',
      rating: 4.9,
      totalReviews: 56,
      communities: ['Washington High School Community', 'Lincoln High School Community'],
      specialties: ['Urban Farming', 'Sustainability', 'Vegetables'],
      totalPosts: 41,
      totalTransactions: 167
    },
    {
      id: '8',
      name: 'Amanda Rodriguez',
      photo: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=400',
      bio: 'New to gardening and loving every minute of it! Learning from this amazing community.',
      rating: 4.5,
      totalReviews: 8,
      communities: ['Lincoln High School Community'],
      specialties: ['Cucumbers', 'Learning', 'Photography'],
      totalPosts: 11,
      totalTransactions: 23
    },
    {
      id: '9',
      name: 'Robert Kim',
      photo: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400',
      bio: 'Beekeeper and pollinator advocate. Selling local honey and sharing beekeeping knowledge.',
      rating: 5.0,
      totalReviews: 34,
      communities: ['Roosevelt High School Community'],
      specialties: ['Beekeeping', 'Honey', 'Pollination'],
      totalPosts: 18,
      totalTransactions: 71
    },
    {
      id: '10',
      name: 'Emily Parker',
      photo: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400',
      bio: 'Master gardener and educator. Running workshops on organic gardening practices.',
      rating: 5.0,
      totalReviews: 62,
      communities: ['Lincoln High School Community'],
      specialties: ['Education', 'Organic Methods', 'Workshops'],
      totalPosts: 53,
      totalTransactions: 142
    }
  ];

  // Extract all unique categories from user specialties
  const allCategories = Array.from(
    new Set(allUsers.flatMap(user => user.specialties))
  ).sort();

  // Filter users based on search query
  const textFilteredUsers = searchQuery.trim() === ''
    ? allUsers
    : allUsers.filter(user =>
        user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.specialties.some(specialty => specialty.toLowerCase().includes(searchQuery.toLowerCase())) ||
        user.bio.toLowerCase().includes(searchQuery.toLowerCase())
      );

  // Filter by selected category
  const categoryFilteredUsers = selectedCategory === 'all'
    ? textFilteredUsers
    : textFilteredUsers.filter(user => 
        user.specialties.some(specialty => specialty === selectedCategory)
      );

  // Remove current user from results
  let searchResults = categoryFilteredUsers.filter(user => user.id !== currentUser.id);

  // Apply active filter
  if (activeFilter === 'following') {
    searchResults = searchResults.filter(user => followingUsers.has(user.id));
  } else if (activeFilter === 'top-rated') {
    searchResults = [...searchResults].sort((a, b) => b.rating - a.rating);
  }

  // Top contributors (most transactions)
  const topContributors = [...allUsers]
    .filter(user => user.id !== currentUser.id)
    .sort((a, b) => b.totalTransactions - a.totalTransactions)
    .slice(0, 3);

  const allCount = categoryFilteredUsers.filter(user => user.id !== currentUser.id).length;
  const followingCount = categoryFilteredUsers.filter(user => user.id !== currentUser.id && followingUsers.has(user.id)).length;

  // Count users per category
  const getCategoryCount = (category: string) => {
    if (category === 'all') return allUsers.filter(user => user.id !== currentUser.id).length;
    return allUsers.filter(user => 
      user.id !== currentUser.id && 
      user.specialties.some(specialty => specialty === category)
    ).length;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-4 mb-4">
            <button
              onClick={onBack}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back</span>
            </button>
            <h1 className="text-xl font-bold text-gray-900">Search Members</h1>
          </div>

          {/* Search Input */}
          <div className="relative mb-4">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search by name, specialty, or keyword..."
              value={searchQuery}
              onChange={(e) => {
                const newQuery = e.target.value;
                console.log('Search query changed to:', newQuery);
                setSearchQuery(newQuery);
              }}
              className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent"
              autoFocus
            />
          </div>

          {/* People/Category Toggle */}
          <div className="mb-4">
            <div className="flex items-center gap-2 mb-3">
              <UsersIcon className="w-4 h-4 text-gray-600" />
              <span className="text-sm font-medium text-gray-700">Filter by Category:</span>
            </div>
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-colors ${
                  selectedCategory === 'all'
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                All Categories ({getCategoryCount('all')})
              </button>
              {allCategories.map(category => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-colors ${
                    selectedCategory === category
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {category} ({getCategoryCount(category)})
                </button>
              ))}
            </div>
          </div>

          {/* Filter Tabs */}
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-colors ${
                activeFilter === 'all'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              All Members ({allCount})
            </button>
            <button
              onClick={() => setActiveFilter('following')}
              className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-colors ${
                activeFilter === 'following'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Following ({followingCount})
            </button>
            <button
              onClick={() => setActiveFilter('top-rated')}
              className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1 ${
                activeFilter === 'top-rated'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <Star className="w-4 h-4" />
              Top Rated
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        {/* Top Contributors Section - Show only when no search query and no category selected */}
        {searchQuery.trim() === '' && selectedCategory === 'all' && (
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-5 h-5 text-green-600" />
              <h2 className="text-lg font-bold text-gray-900">Top Contributors</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {topContributors.map((user, index) => (
                <div
                  key={user.id}
                  className="bg-white rounded-xl shadow-sm p-4 border-2 border-green-100 hover:border-green-300 transition-colors cursor-pointer"
                  onClick={() => onViewUserPosts(user.id)}
                >
                  <div className="flex items-start gap-3 mb-3">
                    <div className="relative">
                      {user.photo ? (
                        <img
                          src={user.photo}
                          alt={user.name}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                      ) : (
                        <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center text-white font-bold">
                          {user.name.charAt(0)}
                        </div>
                      )}
                      <div className="absolute -top-1 -right-1 w-6 h-6 bg-green-600 text-white rounded-full flex items-center justify-center text-xs font-bold">
                        {index + 1}
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-900 truncate">{user.name}</h3>
                      <div className="flex items-center gap-1">
                        <Star className="w-3.5 h-3.5 text-yellow-500 fill-current" />
                        <span className="text-sm font-medium text-gray-700">{user.rating.toFixed(1)}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-xs text-gray-600 mb-2">
                    {user.totalTransactions} transactions
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {user.specialties.slice(0, 2).map((specialty, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 bg-green-50 text-green-600 rounded text-xs"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Search Results */}
        <div>
          <h2 className="text-lg font-bold text-gray-900 mb-4">
            {searchQuery.trim() === '' && selectedCategory === 'all'
              ? 'All Community Members'
              : selectedCategory !== 'all'
              ? `${selectedCategory} Specialists (${searchResults.length})`
              : `Search Results for "${searchQuery}" (${searchResults.length})`}
          </h2>

          {searchResults.length === 0 ? (
            <div className="bg-white rounded-xl shadow-sm p-12 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No users found</h3>
              <p className="text-gray-600">
                Try adjusting your search terms, category filter, or browse all community members.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {searchResults.map((user) => {
                const isFollowing = followingUsers.has(user.id);

                return (
                  <div
                    key={user.id}
                    className="bg-white rounded-xl shadow-sm p-4 sm:p-6 hover:shadow-md transition-shadow"
                  >
                    <div className="flex flex-col sm:flex-row gap-4">
                      {/* User Photo */}
                      <div className="flex-shrink-0">
                        {user.photo ? (
                          <img
                            src={user.photo}
                            alt={user.name}
                            className="w-20 h-20 rounded-full object-cover border-4 border-green-50 cursor-pointer hover:border-green-100 transition-colors"
                            onClick={() => onViewUserPosts(user.id)}
                          />
                        ) : (
                          <div 
                            className="w-20 h-20 bg-green-600 rounded-full flex items-center justify-center text-white text-2xl font-bold border-4 border-green-50 cursor-pointer hover:border-green-100 transition-colors"
                            onClick={() => onViewUserPosts(user.id)}
                          >
                            {user.name.charAt(0)}
                          </div>
                        )}
                      </div>

                      {/* User Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 mb-3">
                          <div className="flex-1 min-w-0">
                            <h3 
                              className="text-xl font-bold text-gray-900 mb-1 cursor-pointer hover:text-green-600 transition-colors"
                              onClick={() => onViewUserPosts(user.id)}
                            >
                              {user.name}
                            </h3>
                            <div className="flex items-center gap-3 text-sm mb-2">
                              <div className="flex items-center gap-1">
                                <Star className="w-4 h-4 text-yellow-500 fill-current" />
                                <span className="font-semibold text-gray-900">{user.rating.toFixed(1)}</span>
                                <span className="text-gray-500">({user.totalReviews} reviews)</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                              <MapPin className="w-4 h-4" />
                              <span>{user.communities[0]}</span>
                            </div>
                          </div>

                          {/* Follow Button */}
                          <button
                            onClick={() => onFollowToggle(user.id)}
                            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${
                              isFollowing
                                ? 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                : 'bg-green-600 text-white hover:bg-green-700'
                            }`}
                          >
                            {isFollowing ? (
                              <>
                                <UserCheck className="w-4 h-4" />
                                Following
                              </>
                            ) : (
                              <>
                                <UserPlus className="w-4 h-4" />
                                Follow
                              </>
                            )}
                          </button>
                        </div>

                        <p className="text-gray-700 text-sm mb-3">{user.bio}</p>

                        {/* Stats */}
                        <div className="flex flex-wrap gap-3 mb-3">
                          <div className="bg-green-50 rounded-lg px-3 py-1.5">
                            <span className="text-sm font-semibold text-green-700">{user.totalPosts}</span>
                            <span className="text-xs text-green-600 ml-1">posts</span>
                          </div>
                          <div className="bg-blue-50 rounded-lg px-3 py-1.5">
                            <span className="text-sm font-semibold text-blue-700">{user.totalTransactions}</span>
                            <span className="text-xs text-blue-600 ml-1">transactions</span>
                          </div>
                        </div>

                        {/* Specialties */}
                        <div className="flex flex-wrap gap-2">
                          {user.specialties.map((specialty, index) => (
                            <button
                              key={index}
                              onClick={() => setSelectedCategory(specialty)}
                              className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                                selectedCategory === specialty
                                  ? 'bg-green-600 text-white'
                                  : 'bg-green-100 text-green-700 hover:bg-green-200'
                              }`}
                            >
                              {specialty}
                            </button>
                          ))}
                        </div>

                        {/* View Posts Button */}
                        <button
                          onClick={() => onViewUserPosts(user.id)}
                          className="mt-3 w-full sm:w-auto px-6 py-2 bg-white border-2 border-green-600 text-green-600 rounded-lg font-medium hover:bg-green-50 transition-colors"
                        >
                          View All Posts
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
