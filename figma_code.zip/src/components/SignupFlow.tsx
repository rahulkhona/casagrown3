import React, { useState } from 'react';
import { Camera, MapPin, CheckCircle, Gift, Users, ShoppingBag, Wrench, Bell, Phone, Upload, X, Plus, Navigation } from 'lucide-react';
import IntroPost from './IntroPost';
import ToggleSwitch from './ToggleSwitch';
import { calculateFirstPostReward } from '../utils/rewardPolicy';

interface User {
  id: string;
  name: string;
  email: string;
  photo?: string;
  points: number;
  communities: string[];
  roles: string[];
  completedProfile: boolean;
  hasPostedIntro: boolean;
}

interface SignupFlowProps {
  user: User;
  onComplete: (user: User, introPost?: {
    message: string;
    media?: string;
    mediaType?: 'image' | 'video';
    gardenProduce: string[];
  } | null) => void;
  onBack?: () => void;
}

export default function SignupFlow({ user, onComplete, onBack }: SignupFlowProps) {
  const [step, setStep] = useState(1);
  const [name, setName] = useState(user.name);
  const [photo, setPhoto] = useState(user.photo || '');
  const [zipcode, setZipcode] = useState('');
  const [address, setAddress] = useState('');
  const [isLocating, setIsLocating] = useState(false);
  const [selectedCommunity, setSelectedCommunity] = useState('');
  const [detectedCommunity, setDetectedCommunity] = useState('');
  const [roles, setRoles] = useState<string[]>([]);
  const [pushNotifications, setPushNotifications] = useState(false);
  const [smsNotifications, setSmsNotifications] = useState(false);
  const [notifyWhenWanted, setNotifyWhenWanted] = useState(false);
  const [notifyWhenOffered, setNotifyWhenOffered] = useState(false);
  const [phone, setPhone] = useState('');
  const [firstPostReward, setFirstPostReward] = useState(0); // Will be set based on policy
  const [introPostData, setIntroPostData] = useState<{
    message: string;
    media?: string;
    mediaType?: 'image' | 'video';
    makeFirstPost: boolean;
    gardenProduce: string[];
  } | null>(null);

  // Mock function to find nearest landmark based on address/location
  const findNearestLandmark = (addressOrZip: string): string => {
    // In production, this would call backend API with geocoding
    // For now, mock different landmarks based on input
    const landmarks = [
      'Lincoln High School',
      'Oak Ridge Park',
      'Sunset Valley Mall', 
      'Main St & Elm Ave',
      'Washington Park',
      'Central Plaza',
      'Roosevelt Community Center',
      'Riverside Shopping District'
    ];
    
    // Simple mock: use hash of input to pick a landmark consistently
    const hash = addressOrZip.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    return landmarks[hash % landmarks.length];
  };

  // Handle geolocation
  const handleUseLocation = () => {
    setIsLocating(true);
    // Mock geolocation - in production would use navigator.geolocation
    setTimeout(() => {
      const mockAddress = '123 Main St, Your City';
      const community = findNearestLandmark(mockAddress);
      setAddress(mockAddress);
      setDetectedCommunity(community);
      setSelectedCommunity(community);
      setIsLocating(false);
    }, 1500);
  };

  // Handle manual address input
  const handleAddressSubmit = () => {
    if (address.trim() && zipcode.length === 5) {
      const community = findNearestLandmark(address + zipcode);
      setDetectedCommunity(community);
      setSelectedCommunity(community);
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCommunityToggle = (community: string) => {
    if (selectedCommunity === community) {
      setSelectedCommunity('');
    } else {
      setSelectedCommunity(community);
    }
  };

  const handleRoleToggle = (role: string) => {
    if (roles.includes(role)) {
      setRoles(roles.filter(r => r !== role));
    } else {
      setRoles([...roles, role]);
    }
  };

  const handleNext = () => {
    // When moving to step 3 (intro post), calculate the potential reward based on policy
    if (step === 2 && selectedCommunity) {
      const reward = calculateFirstPostReward(zipcode, selectedCommunity);
      setFirstPostReward(reward);
    }
    setStep(step + 1);
  };

  const handleComplete = (postData?: typeof introPostData) => {
    // Use the passed postData or fallback to state
    const finalPostData = postData || introPostData;
    
    // Calculate final points: only add reward if they made first post
    const finalPoints = finalPostData?.makeFirstPost ? user.points + firstPostReward : user.points;
    
    const updatedUser: User = {
      ...user,
      name,
      photo,
      communities: selectedCommunity ? [selectedCommunity] : [],
      roles,
      points: finalPoints,
      completedProfile: true,
      hasPostedIntro: finalPostData?.makeFirstPost || false
    };
    onComplete(updatedUser, finalPostData);
  };

  const totalSteps = 3;
  const progress = (step / totalSteps) * 100;

  // Render IntroPost as a separate screen (not in the card)
  if (step === 3) {
    return (
      <IntroPost
        userName={name}
        userPhoto={photo}
        earnedPoints={firstPostReward}
        onComplete={(data) => {
          // Pass the data directly to handleComplete to avoid state timing issues
          handleComplete(data);
        }}
        onSkip={() => handleComplete(null)}
        onBack={() => setStep(2)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">Step {step} of {totalSteps}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-green-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-xl p-6 sm:p-8">
          {/* Step 1: Profile Setup */}
          {step === 1 && (
            <div className="space-y-6">
              <div className="text-center">
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Set Up Your Profile</h2>
                <p className="text-gray-600">Let your neighbors get to know you</p>
              </div>

              {/* Signup Success Message */}
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <CheckCircle className="w-6 h-6 text-green-600" />
                  </div>
                  <div className="text-sm">
                    <div className="font-bold text-green-900 mb-1">🎉 Welcome to CasaGrown!</div>
                    <p className="text-green-800">
                      Complete your profile and make your first post to start trading fresh produce with your neighbors!
                    </p>
                  </div>
                </div>
              </div>

              {/* Profile Photo */}
              <div className="flex flex-col items-center">
                <div className="relative">
                  {photo ? (
                    <img src={photo} alt={name} className="w-32 h-32 rounded-full object-cover" />
                  ) : (
                    <div className="w-32 h-32 bg-green-100 rounded-full flex items-center justify-center">
                      <span className="text-4xl font-bold text-green-600">
                        {name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                  )}
                  <label className="absolute bottom-0 right-0 w-10 h-10 bg-green-600 rounded-full flex items-center justify-center cursor-pointer hover:bg-green-700 transition-colors shadow-lg">
                    <Camera className="w-5 h-5 text-white" />
                    <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                  </label>
                </div>
                
                {/* Upload or Take Photo Options */}
                <div className="flex gap-3 mt-3">
                  <label className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg cursor-pointer hover:border-green-500 hover:bg-green-50 transition-all">
                    <Upload className="w-4 h-4 text-gray-600" />
                    <span className="text-sm font-medium text-gray-700">Upload</span>
                    <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                  </label>
                  
                  <label className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg cursor-pointer hover:border-green-500 hover:bg-green-50 transition-all">
                    <Camera className="w-4 h-4 text-gray-600" />
                    <span className="text-sm font-medium text-gray-700">Take Photo</span>
                    <input type="file" accept="image/*" capture="user" onChange={handlePhotoUpload} className="hidden" />
                  </label>
                </div>
              </div>

              {/* Name Input */}
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                  Your Name
                </label>
                <input
                  type="text"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="Enter your name"
                  required
                />
              </div>

              {/* Notification Preferences */}
              <div className="border-t border-gray-200 pt-6">
                <div className="mb-4">
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">Notification Preferences</h3>
                  <p className="text-sm text-gray-600">Choose how you'd like to stay updated</p>
                </div>

                {/* Notification Checkboxes */}
                <div className="space-y-3">
                  <label className="flex items-start gap-3 p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                    <input
                      type="checkbox"
                      checked={notifyWhenWanted}
                      onChange={(e) => setNotifyWhenWanted(e.target.checked)}
                      className="mt-0.5 w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
                    />
                    <div className="flex-1">
                      <div className="text-sm font-medium text-gray-900">Notify when someone wants produce I have</div>
                      <div className="text-xs text-gray-600 mt-0.5">Get alerts when buyers are looking for items you sell</div>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                    <input
                      type="checkbox"
                      checked={notifyWhenOffered}
                      onChange={(e) => setNotifyWhenOffered(e.target.checked)}
                      className="mt-0.5 w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
                    />
                    <div className="flex-1">
                      <div className="text-sm font-medium text-gray-900">Notify when someone is offering produce I want</div>
                      <div className="text-xs text-gray-600 mt-0.5">Get alerts when sellers post items you're interested in</div>
                    </div>
                  </label>
                </div>

                {/* Show Push/SMS options if either notification is selected */}
                {(notifyWhenWanted || notifyWhenOffered) && (
                  <div className="mt-4 pl-7 space-y-3">
                    <label className="flex items-center justify-between p-3 bg-gray-50 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
                      <div className="flex items-center gap-3">
                        <Bell className="w-4 h-4 text-gray-600" />
                        <span className="text-sm font-medium text-gray-900">Push Notifications</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={pushNotifications}
                        onChange={(e) => setPushNotifications(e.target.checked)}
                        className="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
                      />
                    </label>

                    <label className="flex items-center justify-between p-3 bg-gray-50 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
                      <div className="flex items-center gap-3">
                        <Phone className="w-4 h-4 text-gray-600" />
                        <span className="text-sm font-medium text-gray-900">SMS Notifications</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={smsNotifications}
                        onChange={(e) => setSmsNotifications(e.target.checked)}
                        className="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
                      />
                    </label>

                    {/* Phone Number Input */}
                    {smsNotifications && (
                      <div className="mt-3">
                        <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                          Phone Number
                        </label>
                        <input
                          type="tel"
                          id="phone"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                          placeholder="(555) 123-4567"
                        />
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="flex gap-3">
                <button
                  onClick={onBack}
                  className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Back
                </button>
                <button
                  onClick={handleNext}
                  disabled={!name.trim()}
                  className="flex-1 px-6 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
                >
                  Continue
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Community Selection */}
          {step === 2 && (
            <div className="space-y-6">
              <div className="text-center">
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Join Your Community</h2>
                <p className="text-gray-600">We'll find the nearest landmark to match you with local neighbors</p>
              </div>

              {/* Explanation Box */}
              <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <div className="text-sm text-blue-900">
                    <div className="font-semibold mb-1">How community matching works</div>
                    <p className="text-blue-800">
                      Enter your address or nearest cross street, and we'll find the closest local landmark (school, park, mall, or major intersection) to create your hyper-local community. This keeps trades safe and convenient within your neighborhood.
                    </p>
                  </div>
                </div>
              </div>

              {/* Use Current Location Button */}
              <button
                onClick={handleUseLocation}
                disabled={isLocating}
                className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-400 shadow-md"
              >
                {isLocating ? (
                  <>
                    <div className="animate-spin">
                      <Navigation className="w-5 h-5" />
                    </div>
                    <span>Locating...</span>
                  </>
                ) : (
                  <>
                    <Navigation className="w-5 h-5" />
                    <span>Use My Current Location</span>
                  </>
                )}
              </button>

              {/* OR Divider */}
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white text-gray-500">OR</span>
                </div>
              </div>

              {/* Manual Address Entry */}
              <div className="space-y-4">
                <div>
                  <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-2">
                    Enter Your Address or Nearest Cross Street
                  </label>
                  <input
                    type="text"
                    id="address"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    onBlur={handleAddressSubmit}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    placeholder="e.g., 123 Main St or Main St & Elm Ave"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    You can enter your street address or just the nearest cross streets for privacy
                  </p>
                </div>

                <div>
                  <label htmlFor="zipcode" className="block text-sm font-medium text-gray-700 mb-2">
                    Zip Code <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    id="zipcode"
                    value={zipcode}
                    onChange={(e) => {
                      setZipcode(e.target.value);
                      // Auto-submit when both address and zip are filled
                      if (e.target.value.length === 5 && address.trim()) {
                        setTimeout(handleAddressSubmit, 100);
                      }
                    }}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    placeholder="Enter zip code"
                    maxLength={5}
                  />
                </div>

                {/* Find My Community Button */}
                {address.trim() && zipcode.length === 5 && !detectedCommunity && (
                  <button
                    onClick={handleAddressSubmit}
                    className="w-full px-6 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
                  >
                    Find My Community
                  </button>
                )}
              </div>

              {/* Detected Community Display */}
              {detectedCommunity && (
                <div className="border-2 border-green-500 bg-green-50 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-green-900 mb-1">Your Community</h3>
                      <p className="text-lg font-semibold text-green-700 mb-2">{detectedCommunity}</p>
                      <p className="text-sm text-green-800">
                        Based on your location, you'll trade with neighbors near {detectedCommunity}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Reward Preview - show if community is selected */}
              {selectedCommunity && zipcode.length === 5 && (() => {
                const potentialReward = calculateFirstPostReward(zipcode, selectedCommunity);
                if (potentialReward > 0) {
                  return (
                    <div className="bg-gradient-to-r from-green-600 to-green-500 text-white rounded-lg p-4 mb-4">
                      <div className="flex items-start gap-3">
                        <Gift className="w-5 h-5 flex-shrink-0 mt-0.5" />
                        <div>
                          <h4 className="font-semibold mb-1">🎉 Earn {potentialReward} points with your first post!</h4>
                          <p className="text-sm text-green-50">
                            After joining {selectedCommunity}, introduce yourself to earn your welcome bonus
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                }
                return null;
              })()}

              <div className="flex gap-3">
                <button
                  onClick={() => setStep(step - 1)}
                  className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Back
                </button>
                <button
                  onClick={handleNext}
                  disabled={!selectedCommunity}
                  className="flex-1 px-6 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
                >
                  Continue
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}