import React, { useState } from 'react';
import { Gift, Search, Heart, CreditCard, ShoppingBag, History } from 'lucide-react';

interface User {
  id: string;
  name: string;
  points: number;
}

interface RedemptionStoreProps {
  user: User;
  updateUserPoints: (points: number) => void;
}

interface GiftCard {
  id: string;
  name: string;
  category: 'retail' | 'food' | 'charity';
  pointsRequired: number;
  value: number;
  imageUrl: string;
}

interface Transaction {
  id: string;
  date: Date;
  type: 'giftcard' | 'charity';
  name: string;
  points: number;
}

const mockGiftCards: GiftCard[] = [
  {
    id: '1',
    name: 'Amazon',
    category: 'retail',
    pointsRequired: 250,
    value: 25,
    imageUrl: 'https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?w=400'
  },
  {
    id: '2',
    name: 'Starbucks',
    category: 'food',
    pointsRequired: 100,
    value: 10,
    imageUrl: 'https://images.unsplash.com/photo-1559305616-3b04d4e59e8c?w=400'
  },
  {
    id: '3',
    name: 'Whole Foods',
    category: 'food',
    pointsRequired: 500,
    value: 50,
    imageUrl: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400'
  },
  {
    id: '4',
    name: 'Target',
    category: 'retail',
    pointsRequired: 250,
    value: 25,
    imageUrl: 'https://images.unsplash.com/photo-1596464716127-f2a82984de30?w=400'
  },
  {
    id: '5',
    name: 'Feeding America',
    category: 'charity',
    pointsRequired: 100,
    value: 10,
    imageUrl: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=400'
  },
  {
    id: '6',
    name: 'Local Food Bank',
    category: 'charity',
    pointsRequired: 50,
    value: 5,
    imageUrl: 'https://images.unsplash.com/photo-1593113646773-028c64a8f1b8?w=400'
  }
];

const mockTransactions: Transaction[] = [
  {
    id: '1',
    date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    type: 'giftcard',
    name: 'Starbucks $10 Gift Card',
    points: 100
  },
  {
    id: '2',
    date: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
    type: 'charity',
    name: 'Feeding America Donation',
    points: 100
  }
];

export default function RedemptionStore({ user, updateUserPoints }: RedemptionStoreProps) {
  const [activeTab, setActiveTab] = useState<'store' | 'history'>('store');
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'retail' | 'food' | 'charity'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showRedeemModal, setShowRedeemModal] = useState<GiftCard | null>(null);

  const filteredCards = mockGiftCards.filter(card => {
    if (selectedCategory !== 'all' && card.category !== selectedCategory) return false;
    if (searchQuery && !card.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const handleRedeem = (card: GiftCard) => {
    if (user.points < card.pointsRequired) {
      alert('Not enough points!');
      return;
    }
    updateUserPoints(user.points - card.pointsRequired);
    setShowRedeemModal(null);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Redemption Store</h1>
          <p className="text-gray-600">Redeem your points for gift cards or donate to charity</p>
        </div>

        {/* Points Balance */}
        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl p-6 text-white mb-8">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-green-100 mb-1">Available Points</div>
              <div className="text-4xl font-bold">{user.points}</div>
            </div>
            <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
              <Gift className="w-8 h-8" />
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow-sm mb-6">
          <div className="flex border-b border-gray-200">
            <button
              onClick={() => setActiveTab('store')}
              className={`flex-1 px-6 py-4 text-center font-medium transition-colors ${
                activeTab === 'store'
                  ? 'text-green-600 border-b-2 border-green-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <div className="flex items-center justify-center gap-2">
                <ShoppingBag className="w-5 h-5" />
                <span>Store</span>
              </div>
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`flex-1 px-6 py-4 text-center font-medium transition-colors ${
                activeTab === 'history'
                  ? 'text-green-600 border-b-2 border-green-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <div className="flex items-center justify-center gap-2">
                <History className="w-5 h-5" />
                <span>History</span>
              </div>
            </button>
          </div>
        </div>

        {activeTab === 'store' ? (
          <>
            {/* Search and Filter */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search gift cards or charities..."
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mt-3">
                <button
                  onClick={() => setSelectedCategory('all')}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    selectedCategory === 'all'
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setSelectedCategory('retail')}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    selectedCategory === 'retail'
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Retail
                </button>
                <button
                  onClick={() => setSelectedCategory('food')}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    selectedCategory === 'food'
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Food & Dining
                </button>
                <button
                  onClick={() => setSelectedCategory('charity')}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    selectedCategory === 'charity'
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Charity
                </button>
              </div>
            </div>

            {/* Gift Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCards.map((card) => (
                <div key={card.id} className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                  <div className="aspect-video w-full overflow-hidden bg-gray-100">
                    <img src={card.imageUrl} alt={card.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-gray-900">{card.name}</h3>
                      {card.category === 'charity' && (
                        <Heart className="w-5 h-5 text-red-500 flex-shrink-0" />
                      )}
                    </div>
                    <div className="text-sm text-gray-600 mb-4">
                      ${card.value} {card.category === 'charity' ? 'Donation' : 'Gift Card'}
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold text-green-600">{card.pointsRequired}</div>
                        <div className="text-xs text-gray-500">points</div>
                      </div>
                      <button
                        onClick={() => setShowRedeemModal(card)}
                        disabled={user.points < card.pointsRequired}
                        className="px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
                      >
                        Redeem
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {filteredCards.length === 0 && (
              <div className="bg-white rounded-lg shadow-sm p-12 text-center">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No results found</h3>
                <p className="text-gray-600">Try adjusting your search or filters</p>
              </div>
            )}
          </>
        ) : (
          <div className="space-y-4">
            {/* Transaction History */}
            {mockTransactions.map((transaction) => (
              <div key={transaction.id} className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                      transaction.type === 'charity' ? 'bg-red-100' : 'bg-green-100'
                    }`}>
                      {transaction.type === 'charity' ? (
                        <Heart className="w-6 h-6 text-red-600" />
                      ) : (
                        <CreditCard className="w-6 h-6 text-green-600" />
                      )}
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{transaction.name}</h3>
                      <p className="text-sm text-gray-600">
                        {transaction.date.toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-bold text-gray-900">-{transaction.points}</div>
                    <div className="text-sm text-gray-500">points</div>
                  </div>
                </div>
              </div>
            ))}

            {mockTransactions.length === 0 && (
              <div className="bg-white rounded-lg shadow-sm p-12 text-center">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <History className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No redemption history</h3>
                <p className="text-gray-600">You haven't redeemed any points yet</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Redeem Confirmation Modal */}
      {showRedeemModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Confirm Redemption</h3>
            
            <div className="bg-gray-50 rounded-lg p-4 mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-700">{showRedeemModal.name}</span>
                <span className="font-semibold text-gray-900">${showRedeemModal.value}</span>
              </div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-700">Points Required</span>
                <span className="font-semibold text-gray-900">{showRedeemModal.pointsRequired}</span>
              </div>
              <div className="pt-2 border-t border-gray-200">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-gray-900">Remaining Points</span>
                  <span className="font-bold text-green-600">
                    {user.points - showRedeemModal.pointsRequired}
                  </span>
                </div>
              </div>
            </div>

            <p className="text-sm text-gray-600 mb-6">
              {showRedeemModal.category === 'charity'
                ? 'Your donation will be sent directly to the charity. You will receive a confirmation email.'
                : 'Your gift card code will be sent to your email within 24 hours.'}
            </p>

            <div className="flex gap-3">
              <button
                onClick={() => setShowRedeemModal(null)}
                className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleRedeem(showRedeemModal)}
                className="flex-1 px-4 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}