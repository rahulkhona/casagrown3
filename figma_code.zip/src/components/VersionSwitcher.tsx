import React, { useState } from 'react';
import { Settings, X, Check } from 'lucide-react';
import { useDelegationMode, DelegationMode } from '../contexts/DelegationModeContext';

export default function VersionSwitcher() {
  const { mode, setMode } = useDelegationMode();
  const [isOpen, setIsOpen] = useState(false);

  const versions: { value: DelegationMode; label: string; description: string }[] = [
    {
      value: 'baseline',
      label: 'Baseline',
      description: 'No delegation features (current production)'
    },
    {
      value: 'business',
      label: 'Business Delegation',
      description: 'Service providers managing multiple clients'
    },
    {
      value: 'team',
      label: 'Team Member Delegation',
      description: 'Family/household management (parent-teen)'
    },
    {
      value: 'combined',
      label: 'Combined',
      description: 'Both business & team delegation models'
    }
  ];

  const currentVersion = versions.find(v => v.value === mode);

  return (
    <>
      {/* Floating Badge */}
      <div className="fixed bottom-4 right-4 z-50">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-full shadow-lg hover:bg-purple-700 transition-colors text-sm font-medium"
        >
          <Settings className="w-4 h-4" />
          <span className="hidden sm:inline">Version: {currentVersion?.label}</span>
          <span className="sm:hidden">Ver</span>
        </button>
      </div>

      {/* Modal */}
      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Version Switcher</h2>
                <p className="text-sm text-gray-600 mt-1">Select delegation model to test</p>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            {/* Version Options */}
            <div className="p-6 space-y-3">
              {versions.map((version) => (
                <button
                  key={version.value}
                  onClick={() => {
                    setMode(version.value);
                    setIsOpen(false);
                  }}
                  className={`w-full text-left p-4 rounded-lg border-2 transition-all ${
                    mode === version.value
                      ? 'border-purple-600 bg-purple-50'
                      : 'border-gray-200 hover:border-purple-300 hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-gray-900">{version.label}</h3>
                        {mode === version.value && (
                          <span className="flex items-center gap-1 px-2 py-0.5 bg-purple-600 text-white text-xs rounded-full">
                            <Check className="w-3 h-3" />
                            Active
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mt-1">{version.description}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {/* Info Section */}
            <div className="p-6 bg-gray-50 border-t border-gray-200">
              <h3 className="font-semibold text-gray-900 mb-2">How to share versions:</h3>
              <div className="space-y-2 text-sm text-gray-700">
                <div className="bg-white p-3 rounded border border-gray-200">
                  <code className="text-purple-600">?delegation=baseline</code>
                  <span className="ml-2">- No delegation features</span>
                </div>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <code className="text-purple-600">?delegation=business</code>
                  <span className="ml-2">- Business delegate model</span>
                </div>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <code className="text-purple-600">?delegation=team</code>
                  <span className="ml-2">- Team member model</span>
                </div>
                <div className="bg-white p-3 rounded border border-gray-200">
                  <code className="text-purple-600">?delegation=combined</code>
                  <span className="ml-2">- Both models enabled</span>
                </div>
              </div>
              <p className="text-xs text-gray-500 mt-3">
                💡 Your selection is saved and persists across page reloads
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
