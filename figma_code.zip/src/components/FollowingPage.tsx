import React, { useState } from 'react';
import { ArrowLeft, UserCheck, MapPin, Star, FileText, Calendar } from 'lucide-react';

interface User {
  id: string;
  name: string;
  email: string;
  photo?: string;
  points: number;
  communities: string[];
  roles: string[];
}

interface FollowingPageProps {
  user: User;
  onBack: () => void;
  onViewPost: (postId: string) => void;
  onViewUserPosts?: (userId: string) => void;
}

interface UserProfile {
  id: string;
  name: string;
  photo?: string;
  bio: string;
  location: string;
  rating?: number;
  totalReviews?: number;
  joinedDate: Date;
  communities: string[];
  specialties: string[];
  introPostId?: string;
  introPostTitle?: string;
  introPostExcerpt?: string;
}

// Mock data for followed users
const mockFollowedUsers: UserProfile[] = [
  {
    id: '2',
    name: 'Sarah Johnson',
    photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400',
    bio: 'Organic gardening enthusiast. Growing food for my family and community for over 10 years. Love sharing tips and fresh produce!',
    location: 'Lincoln High School Community',
    rating: 5.0,
    totalReviews: 47,
    joinedDate: new Date('2024-01-15'),
    communities: ['Lincoln High School Community'],
    specialties: ['Tomatoes', 'Herbs', 'Composting'],
    introPostId: 'intro-2',
    introPostTitle: 'Hello from a Tomato Lover! 🍅',
    introPostExcerpt: 'Hi neighbors! I\'m Sarah and I\'ve been growing organic vegetables for over a decade. Excited to share my harvest and learn from all of you...'
  },
  {
    id: '4',
    name: 'David Martinez',
    photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400',
    bio: 'Retired landscaper turned backyard farmer. Specializing in garden equipment and sustainable practices.',
    location: 'Lincoln High School Community',
    rating: 4.9,
    totalReviews: 23,
    joinedDate: new Date('2024-02-20'),
    communities: ['Lincoln High School Community', 'Roosevelt High School Community'],
    specialties: ['Equipment', 'Landscaping', 'Fruit Trees'],
    introPostId: 'intro-4',
    introPostTitle: 'Former Landscaper Here to Help!',
    introPostExcerpt: 'After 30 years in professional landscaping, I\'m enjoying my retirement by helping neighbors with their gardens. Happy to share my tools and knowledge...'
  },
  {
    id: '5',
    name: 'Jessica Martinez',
    photo: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400',
    bio: 'High school student offering lawn care services. Saving up for college while keeping our community beautiful!',
    location: 'Lincoln High School Community',
    rating: 4.8,
    totalReviews: 31,
    joinedDate: new Date('2024-03-10'),
    communities: ['Lincoln High School Community'],
    specialties: ['Lawn Care', 'Weeding', 'Yard Cleanup'],
    introPostId: 'intro-5',
    introPostTitle: 'Teen Entrepreneur Ready to Help!',
    introPostExcerpt: 'Hi everyone! I\'m Jessica, a junior at Lincoln High. I love working outdoors and I\'m offering affordable lawn care services to our community...'
  },
  {
    id: '8',
    name: 'Amanda Rodriguez',
    photo: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=400',
    bio: 'First-time gardener learning from this amazing community. Grateful for all the support and advice!',
    location: 'Lincoln High School Community',
    rating: 4.5,
    totalReviews: 8,
    joinedDate: new Date('2024-04-01'),
    communities: ['Lincoln High School Community'],
    specialties: ['Cucumbers', 'Learning', 'Photography'],
    introPostId: 'intro-8',
    introPostTitle: 'New Gardener, Excited to Learn!',
    introPostExcerpt: 'Hello neighbors! I just moved to the area and decided to try my hand at gardening. This community has been so welcoming and helpful...'
  }
];

export default function FollowingPage({ user, onBack, onViewPost, onViewUserPosts }: FollowingPageProps) {
  const [followedUsers, setFollowedUsers] = useState<UserProfile[]>(mockFollowedUsers);

  const handleUnfollow = (userId: string) => {
    setFollowedUsers(prev => prev.filter(u => u.id !== userId));
  };

  const getTimeAsMember = (joinedDate: Date) => {
    const months = Math.floor((new Date().getTime() - joinedDate.getTime()) / (1000 * 60 * 60 * 24 * 30));
    if (months < 1) return 'New member';
    if (months === 1) return '1 month';
    return `${months} months`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={onBack}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <ArrowLeft className="w-6 h-6 text-gray-600" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Following</h1>
              <p className="text-sm text-gray-600">{followedUsers.length} {followedUsers.length === 1 ? 'person' : 'people'}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Following List */}
      <div className="max-w-4xl mx-auto px-4 py-6">
        {followedUsers.length === 0 ? (
          <div className="bg-white rounded-lg shadow-sm p-12 text-center">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <UserCheck className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No one followed yet</h3>
            <p className="text-gray-600">Start following community members to see their posts and updates here.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {followedUsers.map((followedUser) => (
              <div key={followedUser.id} className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                <div className="p-6">
                  {/* User Header */}
                  <div className="flex items-start gap-4 mb-4">
                    {followedUser.photo ? (
                      <img
                        src={followedUser.photo}
                        alt={followedUser.name}
                        className="w-16 h-16 rounded-full object-cover flex-shrink-0"
                      />
                    ) : (
                      <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center text-white text-xl font-semibold flex-shrink-0">
                        {followedUser.name.charAt(0)}
                      </div>
                    )}
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <h3 className="font-bold text-gray-900 text-lg">{followedUser.name}</h3>
                          {followedUser.rating && followedUser.totalReviews && (
                            <div className="flex items-center gap-1 mt-1">
                              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                              <span className="text-sm font-medium text-gray-900">{followedUser.rating.toFixed(1)}</span>
                              <span className="text-sm text-gray-500">({followedUser.totalReviews} reviews)</span>
                            </div>
                          )}
                        </div>
                        <button
                          onClick={() => handleUnfollow(followedUser.id)}
                          className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-medium text-sm flex-shrink-0"
                        >
                          <UserCheck className="w-4 h-4" />
                          <span>Following</span>
                        </button>
                      </div>
                      
                      <p className="text-gray-600 mt-2 text-sm leading-relaxed">{followedUser.bio}</p>
                    </div>
                  </div>

                  {/* User Info */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span>{followedUser.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <span>Member for {getTimeAsMember(followedUser.joinedDate)}</span>
                    </div>
                  </div>

                  {/* Specialties */}
                  {followedUser.specialties.length > 0 && (
                    <div className="mb-4">
                      <div className="flex flex-wrap gap-2">
                        {followedUser.specialties.map((specialty) => (
                          <span
                            key={specialty}
                            className="px-3 py-1 bg-green-50 text-green-700 rounded-full text-xs font-medium"
                          >
                            {specialty}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Intro Post */}
                  {followedUser.introPostId && (
                    <div className="border-t border-gray-100 pt-4 space-y-2">
                      <button
                        onClick={() => onViewPost(followedUser.introPostId!)}
                        className="w-full text-left p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors group"
                      >
                        <div className="flex items-start gap-3">
                          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                            <FileText className="w-5 h-5 text-green-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-xs font-medium text-green-600 uppercase">Intro Post</span>
                            </div>
                            <h4 className="font-semibold text-gray-900 text-sm mb-1 group-hover:text-green-600 transition-colors">
                              {followedUser.introPostTitle}
                            </h4>
                            <p className="text-xs text-gray-600 line-clamp-2">
                              {followedUser.introPostExcerpt}
                            </p>
                          </div>
                        </div>
                      </button>

                      {/* View All Posts Button */}
                      {onViewUserPosts && (
                        <button
                          onClick={() => onViewUserPosts(followedUser.id)}
                          className="w-full px-4 py-2 text-sm font-medium text-green-600 hover:bg-green-50 rounded-lg transition-colors border border-green-200"
                        >
                          View All Posts by {followedUser.name.split(' ')[0]}
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}