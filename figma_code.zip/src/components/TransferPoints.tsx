import React, { useState } from 'react';
import { ArrowLeft, Send, Search, CheckCircle, AlertCircle } from 'lucide-react';

interface User {
  id: string;
  name: string;
  email: string;
  photo?: string;
  points: number;
  communities: string[];
  roles: string[];
}

interface TransferPointsProps {
  user: User;
  updateUserPoints: (points: number) => void;
}

interface CommunityMember {
  id: string;
  name: string;
  email: string;
  photo?: string;
  community: string;
}

// Mock community members
const mockMembers: CommunityMember[] = [
  {
    id: '2',
    name: 'Sarah Johnson',
    email: 'sarah.j@email.com',
    community: 'Lincoln High School Community'
  },
  {
    id: '3',
    name: 'Michael Chen',
    email: 'mchen@email.com',
    community: 'Washington High School Community'
  },
  {
    id: '4',
    name: 'Jessica Martinez',
    email: 'jmartinez@email.com',
    community: 'Lincoln High School Community'
  },
  {
    id: '5',
    name: 'David Williams',
    email: 'dwilliams@email.com',
    community: 'Roosevelt High School Community'
  },
  {
    id: '6',
    name: 'Emily Davis',
    email: 'emilyd@email.com',
    community: 'Lincoln High School Community'
  },
  {
    id: '7',
    name: 'Amanda Rodriguez',
    email: 'arodriguez@email.com',
    community: 'Lincoln High School Community'
  }
];

export default function TransferPoints({ user, updateUserPoints }: TransferPointsProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMember, setSelectedMember] = useState<CommunityMember | null>(null);
  const [amount, setAmount] = useState('');
  const [message, setMessage] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);
  const [error, setError] = useState('');

  const filteredMembers = mockMembers.filter(member => {
    if (member.id === user.id) return false;
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        member.name.toLowerCase().includes(query) ||
        member.email.toLowerCase().includes(query) ||
        member.community.toLowerCase().includes(query)
      );
    }
    return true;
  });

  const handleTransfer = () => {
    setError('');
    const transferAmount = parseInt(amount);

    if (!selectedMember) {
      setError('Please select a recipient');
      return;
    }

    if (!amount || transferAmount <= 0) {
      setError('Please enter a valid amount');
      return;
    }

    if (transferAmount > user.points) {
      setError('Insufficient points');
      return;
    }

    // Perform transfer
    updateUserPoints(user.points - transferAmount);
    setShowSuccess(true);
    
    // Reset after 3 seconds
    setTimeout(() => {
      setShowSuccess(false);
      setSelectedMember(null);
      setAmount('');
      setMessage('');
    }, 3000);
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl shadow-lg p-8 max-w-md w-full text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Transfer Successful!</h2>
          <p className="text-gray-600 mb-6">
            You sent {amount} points to {selectedMember?.name}
          </p>
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="text-sm text-gray-600 mb-1">New Balance</div>
            <div className="text-3xl font-bold text-green-600">{user.points} points</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-2xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Transfer Points</h1>
          <p className="text-gray-600">Send points to your neighbors</p>
          
          {/* Current Balance */}
          <div className="mt-4 p-4 bg-green-50 rounded-lg">
            <div className="text-sm text-gray-600 mb-1">Your Balance</div>
            <div className="text-2xl font-bold text-green-600">{user.points} points</div>
          </div>
        </div>

        {/* Select Recipient */}
        {!selectedMember ? (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Select Recipient</h2>
            
            {/* Search */}
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by name, email, or community..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>

            {/* Members List */}
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {filteredMembers.map((member) => (
                <button
                  key={member.id}
                  onClick={() => setSelectedMember(member)}
                  className="w-full flex items-center gap-3 p-3 hover:bg-gray-50 rounded-lg transition-colors text-left"
                >
                  {member.photo ? (
                    <img src={member.photo} alt={member.name} className="w-10 h-10 rounded-full object-cover" />
                  ) : (
                    <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center text-white font-semibold">
                      {member.name.charAt(0)}
                    </div>
                  )}
                  <div className="flex-1">
                    <div className="font-semibold text-gray-900">{member.name}</div>
                    <div className="text-sm text-gray-500">{member.community}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-gray-900">Transfer Details</h2>
              <button
                onClick={() => {
                  setSelectedMember(null);
                  setAmount('');
                  setMessage('');
                  setError('');
                }}
                className="text-sm text-green-600 hover:text-green-700 font-medium"
              >
                Change Recipient
              </button>
            </div>

            {/* Selected Member */}
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg mb-6">
              {selectedMember.photo ? (
                <img src={selectedMember.photo} alt={selectedMember.name} className="w-12 h-12 rounded-full object-cover" />
              ) : (
                <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center text-white font-semibold">
                  {selectedMember.name.charAt(0)}
                </div>
              )}
              <div>
                <div className="font-semibold text-gray-900">{selectedMember.name}</div>
                <div className="text-sm text-gray-500">{selectedMember.community}</div>
              </div>
            </div>

            {/* Amount Input */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Amount (points)
              </label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount"
                min="1"
                max={user.points}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
              <div className="mt-1 flex gap-2">
                <button
                  onClick={() => setAmount('10')}
                  className="px-3 py-1 text-xs bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200"
                >
                  10
                </button>
                <button
                  onClick={() => setAmount('25')}
                  className="px-3 py-1 text-xs bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200"
                >
                  25
                </button>
                <button
                  onClick={() => setAmount('50')}
                  className="px-3 py-1 text-xs bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200"
                >
                  50
                </button>
                <button
                  onClick={() => setAmount('100')}
                  className="px-3 py-1 text-xs bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200"
                >
                  100
                </button>
              </div>
            </div>

            {/* Message (Optional) */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Message (Optional)
              </label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Add a note..."
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>

            {/* Error Message */}
            {error && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-red-600">{error}</p>
              </div>
            )}

            {/* Transfer Button */}
            <button
              onClick={handleTransfer}
              disabled={!amount || parseInt(amount) <= 0 || parseInt(amount) > user.points}
              className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-5 h-5" />
              Transfer Points
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
