import React, { useState } from 'react';
import { Edit2, Trash2, Eye, AlertCircle } from 'lucide-react';

interface User {
  id: string;
  name: string;
}

interface MyPostsProps {
  user: User;
  onViewPost: (postId: string) => void;
}

interface Post {
  id: string;
  type: 'sell' | 'buy' | 'service-request' | 'service-offer' | 'advice';
  title: string;
  category: string;
  description: string;
  price?: number;
  status: 'active' | 'flagged' | 'expired';
  views: number;
  responses: number;
  createdAt: Date;
  expiresAt?: Date;
}

const mockPosts: Post[] = [
  {
    id: '1',
    type: 'sell',
    title: 'Fresh Organic Tomatoes',
    category: 'Vegetables',
    description: 'Just harvested! 5 lbs of fresh organic heirloom tomatoes.',
    price: 50,
    status: 'active',
    views: 48,
    responses: 5,
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    expiresAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000)
  },
  {
    id: '2',
    type: 'service-offer',
    title: 'Lawn Mowing Services',
    category: 'Lawn Care',
    description: 'Available for lawn mowing on weekends.',
    price: 30,
    status: 'active',
    views: 32,
    responses: 7,
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    expiresAt: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000)
  },
  {
    id: '3',
    type: 'advice',
    title: 'Tips for Growing Tomatoes',
    category: 'Gardening Tips',
    description: 'Sharing my experience with growing tomatoes in our climate.',
    status: 'active',
    views: 156,
    responses: 23,
    createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000)
  },
  {
    id: '4',
    type: 'sell',
    title: 'Garden Tools Set',
    category: 'Equipment',
    description: 'Lightly used garden tools, moving to apartment.',
    price: 75,
    status: 'flagged',
    views: 12,
    responses: 1,
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    expiresAt: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000)
  }
];

export default function MyPosts({ user, onViewPost }: MyPostsProps) {
  const [posts, setPosts] = useState(mockPosts);
  const [showDeleteModal, setShowDeleteModal] = useState<string | null>(null);

  const postTypeColors = {
    sell: 'bg-green-100 text-green-700',
    buy: 'bg-blue-100 text-blue-700',
    'service-request': 'bg-purple-100 text-purple-700',
    'service-offer': 'bg-orange-100 text-orange-700',
    advice: 'bg-yellow-100 text-yellow-700'
  };

  const postTypeLabels = {
    sell: 'For Sale',
    buy: 'Wanted',
    'service-request': 'Service Needed',
    'service-offer': 'Service Offered',
    advice: 'Advice'
  };

  const statusColors = {
    active: 'bg-green-100 text-green-700',
    flagged: 'bg-red-100 text-red-700',
    expired: 'bg-gray-100 text-gray-700'
  };

  const handleDelete = (postId: string) => {
    setPosts(posts.filter(p => p.id !== postId));
    setShowDeleteModal(null);
  };

  const getDaysRemaining = (expiresAt?: Date) => {
    if (!expiresAt) return null;
    const days = Math.ceil((expiresAt.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
    return days;
  };

  const activePosts = posts.filter(p => p.status === 'active');
  const flaggedPosts = posts.filter(p => p.status === 'flagged');
  const expiredPosts = posts.filter(p => p.status === 'expired');

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold text-gray-900">My Posts</h1>
          <div className="text-sm text-gray-600">
            {posts.length} total post{posts.length !== 1 ? 's' : ''}
          </div>
        </div>

        {/* Flagged Posts Alert */}
        {flaggedPosts.length > 0 && (
          <div className="bg-red-50 border-2 border-red-200 rounded-lg p-4 mb-6 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h3 className="font-semibold text-red-900 mb-1">Action Required</h3>
              <p className="text-sm text-red-800">
                You have {flaggedPosts.length} flagged post{flaggedPosts.length !== 1 ? 's' : ''} that need{flaggedPosts.length === 1 ? 's' : ''} to be edited. 
                Flagged posts will be automatically deleted if not updated soon.
              </p>
            </div>
          </div>
        )}

        {/* Posts List */}
        <div className="space-y-4">
          {posts.map((post) => {
            const daysRemaining = getDaysRemaining(post.expiresAt);
            
            return (
              <div key={post.id} className={`bg-white rounded-lg shadow-sm overflow-hidden ${
                post.status === 'flagged' ? 'border-2 border-red-300' : ''
              }`}>
                <div className="p-6">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2 flex-wrap">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${postTypeColors[post.type]}`}>
                          {postTypeLabels[post.type]}
                        </span>
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[post.status]}`}>
                          {post.status === 'flagged' ? '⚠️ Flagged' : post.status === 'expired' ? 'Expired' : 'Active'}
                        </span>
                        {post.status === 'active' && daysRemaining !== null && daysRemaining <= 3 && (
                          <span className="px-3 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-700">
                            Expires in {daysRemaining} day{daysRemaining !== 1 ? 's' : ''}
                          </span>
                        )}
                      </div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-1">{post.title}</h3>
                      <p className="text-sm text-gray-600 mb-2">{post.description}</p>
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span>{post.category}</span>
                        {post.price && (
                          <>
                            <span>·</span>
                            <span className="font-semibold text-green-600">{post.price} points</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Flagged Warning */}
                  {post.status === 'flagged' && (
                    <div className="bg-red-50 rounded-lg p-3 mb-4">
                      <p className="text-sm text-red-800">
                        This post was flagged for violating community guidelines. Please edit and resubmit, or it will be automatically deleted.
                      </p>
                    </div>
                  )}

                  {/* Stats */}
                  <div className="flex items-center gap-6 text-sm text-gray-600 mb-4 pb-4 border-b border-gray-200">
                    <div className="flex items-center gap-2">
                      <Eye className="w-4 h-4" />
                      <span>{post.views} views</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                      </svg>
                      <span>{post.responses} responses</span>
                    </div>
                    <span className="text-gray-400">·</span>
                    <span>Posted {Math.floor((new Date().getTime() - post.createdAt.getTime()) / (1000 * 60 * 60 * 24))} days ago</span>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => onViewPost(post.id)}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <Eye className="w-4 h-4" />
                      View
                    </button>
                    <button
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <Edit2 className="w-4 h-4" />
                      Edit
                    </button>
                    <button
                      onClick={() => setShowDeleteModal(post.id)}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 border border-red-300 text-red-600 rounded-lg hover:bg-red-50 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            );
          })}

          {posts.length === 0 && (
            <div className="bg-white rounded-lg shadow-sm p-12 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No posts yet</h3>
              <p className="text-gray-600 mb-6">Start sharing with your community by creating your first post!</p>
              <button className="px-6 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors">
                Create First Post
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-2">Delete Post?</h3>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this post? This action cannot be undone.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowDeleteModal(null)}
                className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(showDeleteModal)}
                className="flex-1 px-4 py-3 bg-red-600 text-white font-medium rounded-lg hover:bg-red-700 transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
