import React from 'react';
import { Share2, Copy, CheckCircle, Gift } from 'lucide-react';
import { copyToClipboard } from '../utils/clipboard';

interface ShareMovementProps {
  hasPostedIntro: boolean;
  userName: string;
  userId: string;
  earnedPoints: number;
  onContinue: () => void;
  onSkip: () => void;
}

export default function ShareMovement({ hasPostedIntro, userName, userId, earnedPoints, onContinue, onSkip }: ShareMovementProps) {
  const [copied, setCopied] = React.useState(false);
  
  // Generate referral link based on whether they posted their intro
  const referralCode = userId.substring(0, 8); // Use first 8 chars of user ID as referral code
  const shareUrl = hasPostedIntro 
    ? `https://casagrown.com/post/${referralCode}` // Link to their first post
    : `https://casagrown.com/join?ref=${referralCode}`; // Link to join page with referral
  
  const shareMessage = hasPostedIntro
    ? `Check out my intro on CasaGrown! Join me in building a sustainable neighborhood community where we share fresh produce and reduce food waste. 🌱`
    : `Join me on CasaGrown! It's a hyper-local community platform where neighbors share fresh produce and gardening services. Let's reduce food waste together! 🌱`;

  const handleNativeShare = async () => {
    // Check if Web Share API is supported
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join CasaGrown',
          text: shareMessage,
          url: shareUrl,
        });
      } catch (err) {
        // User cancelled share or error occurred
        console.log('Share cancelled or failed:', err);
      }
    } else {
      // Fallback: copy to clipboard
      handleCopyLink();
    }
  };

  const handleCopyLink = async () => {
    const success = await copyToClipboard(shareUrl);
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 py-8 px-4 flex items-center">
      <div className="max-w-2xl mx-auto w-full">
        {/* Points Earned Display */}
        <div className="flex justify-end mb-6">
          <div className="flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-md">
            <Gift className="w-4 h-4 text-green-600" />
            <span className="text-sm font-medium text-green-600">{earnedPoints} points earned</span>
          </div>
        </div>
        
        <div className="bg-white rounded-2xl shadow-xl p-6 sm:p-8">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Share2 className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Share & Grow the Movement! 🌱</h2>
            <p className="text-gray-600">
              Help us build a stronger community by inviting your neighbors to join CasaGrown
            </p>
          </div>

          {/* Referral Rewards Banner */}
          <div className="bg-gradient-to-r from-green-600 to-green-500 text-white rounded-lg p-6 mb-6">
            <div className="flex items-start gap-3">
              <Gift className="w-6 h-6 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-semibold text-lg mb-2">Earn Rewards for Sharing!</h3>
                <ul className="space-y-1.5 text-sm text-green-50">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 flex-shrink-0" />
                    <span><strong>50 points</strong> when someone signs up using your link</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 flex-shrink-0" />
                    <span><strong>100 bonus points</strong> when they complete their first transaction</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Benefits */}
          <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-6 mb-6">
            <h3 className="font-semibold text-gray-900 mb-4">Why CasaGrown is Different</h3>
            <div className="space-y-4">
              {/* Transaction Safety */}
              <div>
                <div className="flex items-start gap-2 mb-1.5">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <h4 className="font-semibold text-gray-900">Transaction Safety & Security</h4>
                </div>
                <p className="text-sm text-gray-700 ml-7">
                  Built-in escrow system protects both buyers and sellers. Choose contactless drop-off for convenience and safety. 
                  Safe for teen sellers, and local-only membership keeps your community safe and trusted. 
                  Dispute handling included for peace of mind.
                </p>
              </div>

              {/* Quick Availability */}
              <div>
                <div className="flex items-start gap-2 mb-1.5">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <h4 className="font-semibold text-gray-900">Instant Point Availability</h4>
                </div>
                <p className="text-sm text-gray-700 ml-7">
                  Unlike credit cards or Venmo which take 2-5 days to clear, <strong>CasaGrown points are available immediately</strong> upon order completion. 
                  Start spending or redeeming your points instantly—no waiting periods or banking delays.
                </p>
              </div>

              {/* Charity Donations */}
              <div>
                <div className="flex items-start gap-2 mb-1.5">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <h4 className="font-semibold text-gray-900">Give Back to Your Community</h4>
                </div>
                <p className="text-sm text-gray-700 ml-7">
                  Donate your points to local charities and food banks, turning your backyard surplus into community support. 
                  Every transaction helps reduce food waste while giving you the option to make a difference.
                </p>
              </div>

              {/* Community Benefits */}
              <div className="pt-3 mt-3 border-t border-green-200">
                <h4 className="font-semibold text-gray-900 mb-2">Why invite your neighbors?</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>More neighbors means more fresh produce variety in your community</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>Together we reduce food waste and support local sustainability</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span>Build stronger connections with the people around you</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <span><strong>Homeowners:</strong> Invite your teens to manage selling your produce and earn pocket money while learning entrepreneurship</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Share Button */}
          <div className="mb-6">
            <button
              onClick={handleNativeShare}
              className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition-colors shadow-lg hover:shadow-xl"
            >
              <Share2 className="w-5 h-5" />
              <span>Share Your {hasPostedIntro ? 'Introduction' : 'Invite Link'}</span>
            </button>
            <p className="text-xs text-gray-500 text-center mt-2">
              {hasPostedIntro 
                ? 'Share your first post with neighbors and friends' 
                : 'Share via text, email, social media, or any app'}
            </p>
          </div>

          {/* Copy Link */}
          <div className="mb-6">
            <h3 className="font-semibold text-gray-900 mb-3">Or copy the link</h3>
            <div className="flex gap-2">
              <input
                type="text"
                value={shareUrl}
                readOnly
                className="flex-1 px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 text-gray-700 text-sm"
              />
              <button
                onClick={handleCopyLink}
                className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
              >
                {copied ? (
                  <>
                    <CheckCircle className="w-5 h-5" />
                    <span className="hidden sm:inline">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-5 h-5" />
                    <span className="hidden sm:inline">Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Your Referral Code */}
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-600 mb-1">Your Referral Code</div>
                <div className="font-mono font-bold text-lg text-gray-900">{referralCode.toUpperCase()}</div>
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-600">Total Referrals</div>
                <div className="text-2xl font-bold text-green-600">0</div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-gray-200">
            <button
              onClick={onSkip}
              className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
            >
              I'll Do This Later
            </button>
            <button
              onClick={onContinue}
              className="flex-1 px-6 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
            >
              Continue to Feed
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}