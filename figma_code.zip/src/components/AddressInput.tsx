import React, { useState } from 'react';
import { MapPin, Loader2 } from 'lucide-react';

interface AddressInputProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  label?: string;
  required?: boolean;
  multiline?: boolean;
  rows?: number;
}

export default function AddressInput({
  value,
  onChange,
  placeholder = 'Enter address',
  className = '',
  label,
  required = false,
  multiline = false,
  rows = 3
}: AddressInputProps) {
  const [isLocating, setIsLocating] = useState(false);

  const handleLocate = async () => {
    setIsLocating(true);

    try {
      // Check if geolocation is supported
      if (!navigator.geolocation) {
        alert('Geolocation is not supported by your browser. Please enter your address manually.');
        setIsLocating(false);
        return;
      }

      // Get user's current position
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
          resolve,
          (error) => {
            // Handle geolocation errors
            let errorMessage = '';
            switch (error.code) {
              case error.PERMISSION_DENIED:
                errorMessage = 'Location permission denied. Please enable location access in your browser settings and try again.';
                break;
              case error.POSITION_UNAVAILABLE:
                errorMessage = 'Location information unavailable. Please check your device settings and try again.';
                break;
              case error.TIMEOUT:
                errorMessage = 'Location request timed out. Please try again.';
                break;
              default:
                errorMessage = 'An unknown error occurred while getting your location.';
            }
            reject(new Error(errorMessage));
          },
          {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
          }
        );
      });

      const { latitude, longitude } = position.coords;

      // Use Nominatim (OpenStreetMap) for reverse geocoding - free and no API key required
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`,
        {
          headers: {
            'Accept-Language': 'en-US,en',
            'User-Agent': 'CasaGrown/1.0'
          }
        }
      );

      if (!response.ok) {
        throw new Error('Failed to get address from location. Please try again or enter manually.');
      }

      const data = await response.json();
      
      // Format the address from the response
      let formattedAddress = '';
      
      if (data.address) {
        const parts = [];
        
        // Street number and name
        if (data.address.house_number && data.address.road) {
          parts.push(`${data.address.house_number} ${data.address.road}`);
        } else if (data.address.road) {
          parts.push(data.address.road);
        }
        
        // City
        if (data.address.city || data.address.town || data.address.village) {
          parts.push(data.address.city || data.address.town || data.address.village);
        }
        
        // State
        if (data.address.state) {
          parts.push(data.address.state);
        }
        
        // Postal code
        if (data.address.postcode) {
          parts.push(data.address.postcode);
        }
        
        formattedAddress = parts.join(', ');
      }
      
      // Fallback to display_name if formatted address is empty
      if (!formattedAddress && data.display_name) {
        formattedAddress = data.display_name;
      }

      if (formattedAddress) {
        onChange(formattedAddress);
      } else {
        alert('Could not determine address from your location. Please enter manually.');
      }
    } catch (error) {
      console.error('Error getting location:', error);
      
      // Show user-friendly error message
      const errorMessage = error instanceof Error ? error.message : 'Unable to get your location. Please enter your address manually.';
      alert(errorMessage);
    } finally {
      setIsLocating(false);
    }
  };

  const inputClasses = `w-full px-4 py-2 pr-24 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent ${className}`;

  return (
    <div>
      {label && (
        <label className="block text-sm font-medium text-gray-700 mb-2">
          {label} {required && <span className="text-red-500">*</span>}
        </label>
      )}
      <div className="relative">
        {multiline ? (
          <textarea
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className={`${inputClasses} resize-none`}
            placeholder={placeholder}
            rows={rows}
          />
        ) : (
          <input
            type="text"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className={inputClasses}
            placeholder={placeholder}
          />
        )}
        <button
          type="button"
          onClick={handleLocate}
          disabled={isLocating}
          className="absolute right-2 top-2 px-3 py-1.5 bg-green-600 text-white text-xs font-medium rounded hover:bg-green-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center gap-1.5"
          title="Use current location"
        >
          {isLocating ? (
            <>
              <Loader2 className="w-3 h-3 animate-spin" />
              <span className="hidden sm:inline">Locating...</span>
            </>
          ) : (
            <>
              <MapPin className="w-3 h-3" />
              <span className="hidden sm:inline">Locate</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
}