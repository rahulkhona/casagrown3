import React, { useState } from 'react';
import { Leaf, Mail, ArrowLeft, Chrome } from 'lucide-react';
import Logo from './Logo';

interface LoginPageProps {
  onLogin: (email: string, name: string) => void;
  onBack: () => void;
}

export default function LoginPage({ onLogin, onBack }: LoginPageProps) {
  const [loginMethod, setLoginMethod] = useState<'select' | 'email' | 'otp'>('select');
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [name, setName] = useState('');

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      // In real app, send OTP to email
      setLoginMethod('otp');
    }
  };

  const handleOtpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length >= 4) {
      // Simulate OTP verification
      onLogin(email, name || email.split('@')[0]);
    }
  };

  const handleSocialLogin = (provider: string) => {
    // Simulate social login with realistic names
    const mockNames = {
      'Google': 'Alex Johnson',
      'Facebook': 'Emma Davis',
      'Apple': 'Jordan Smith'
    };
    const mockName = mockNames[provider as keyof typeof mockNames] || 'Alex Johnson';
    const mockEmail = `${mockName.toLowerCase().replace(' ', '.')}@${provider.toLowerCase()}.com`;
    onLogin(mockEmail, mockName);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        {/* Back Button */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back</span>
        </button>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          {/* Logo */}
          <div className="flex justify-center mb-6">
            <Logo size="lg" showText={false} />
          </div>

          <h2 className="text-2xl font-bold text-gray-900 text-center mb-2">
            Welcome to CasaGrown
          </h2>
          <p className="text-gray-600 text-center mb-8">
            Sign in to start buying and selling fresh produce
          </p>

          {loginMethod === 'select' && (
            <div className="space-y-4">
              {/* Social Login Buttons */}
              <button
                onClick={() => handleSocialLogin('Google')}
                className="w-full flex items-center justify-center gap-3 px-4 py-3 border-2 border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <Chrome className="w-5 h-5 text-gray-700" />
                <span className="font-medium text-gray-700">Continue with Google</span>
              </button>

              <button
                onClick={() => handleSocialLogin('Facebook')}
                className="w-full flex items-center justify-center gap-3 px-4 py-3 border-2 border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <svg className="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
                <span className="font-medium text-gray-700">Continue with Facebook</span>
              </button>

              <button
                onClick={() => handleSocialLogin('Apple')}
                className="w-full flex items-center justify-center gap-3 px-4 py-3 border-2 border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <svg className="w-5 h-5 text-gray-700" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09l.01-.01zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
                </svg>
                <span className="font-medium text-gray-700">Continue with Apple</span>
              </button>

              {/* Divider */}
              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-4 bg-white text-gray-500">Or continue with email</span>
                </div>
              </div>

              {/* Email Button */}
              <button
                onClick={() => setLoginMethod('email')}
                className="w-full flex items-center justify-center gap-3 px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                <Mail className="w-5 h-5" />
                <span className="font-medium">Continue with Email</span>
              </button>
            </div>
          )}

          {loginMethod === 'email' && (
            <form onSubmit={handleEmailSubmit} className="space-y-4">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="you@example.com"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full px-4 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
              >
                Send Verification Code
              </button>

              <button
                type="button"
                onClick={() => setLoginMethod('select')}
                className="w-full text-sm text-gray-600 hover:text-gray-900 transition-colors"
              >
                ← Back to login options
              </button>
            </form>
          )}

          {loginMethod === 'otp' && (
            <form onSubmit={handleOtpSubmit} className="space-y-4">
              <div className="text-center mb-4">
                <p className="text-sm text-gray-600">
                  We sent a verification code to
                </p>
                <p className="font-medium text-gray-900">{email}</p>
              </div>

              <div>
                <label htmlFor="otp" className="block text-sm font-medium text-gray-700 mb-2">
                  Verification Code
                </label>
                <input
                  type="text"
                  id="otp"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-center text-2xl tracking-widest"
                  placeholder="000000"
                  maxLength={6}
                  required
                />
              </div>

              <button
                type="submit"
                disabled={otp.length < 4}
                className="w-full px-4 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
              >
                Verify & Continue
              </button>

              <button
                type="button"
                onClick={() => setLoginMethod('email')}
                className="w-full text-sm text-gray-600 hover:text-gray-900 transition-colors"
              >
                ← Back
              </button>

              <button
                type="button"
                className="w-full text-sm text-green-600 hover:text-green-700 transition-colors"
              >
                Resend code
              </button>
            </form>
          )}
        </div>

        {/* Terms */}
        <p className="text-center text-xs text-gray-600 mt-6">
          By continuing, you agree to CasaGrown's{' '}
          <button className="text-green-600 hover:underline">Terms of Service</button>
          {' '}and{' '}
          <button className="text-green-600 hover:underline">Privacy Policy</button>
        </p>
      </div>
    </div>
  );
}