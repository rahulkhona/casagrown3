import React from 'react';
import { Leaf, Users, TrendingDown, DollarSign, Heart, ArrowRight, Sparkles, Trash2, TrendingUp, GraduationCap, Ban, Shield, Zap, HandHeart } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import heroImage from 'figma:asset/8328c96c9abdb7753f104069405933eb791158c2.png';
import logoImage from 'figma:asset/3ac37b0699e9d282cf5693465931b5a50117a050.png';

interface LandingPageProps {
  onGetStarted: () => void;
}

export default function LandingPage({ onGetStarted }: LandingPageProps) {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-green-50 to-green-100 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left side - Text content */}
            <div className="text-center lg:text-left order-2 lg:order-1">
              <div className="flex items-center justify-center lg:justify-start gap-4 mb-6">
                {/* CasaGrown Logo */}
                <img 
                  src={logoImage}
                  alt="CasaGrown Logo"
                  className="w-16 h-16 object-contain"
                />
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900">
                  CasaGrown
                </h1>
              </div>
              <p className="text-2xl sm:text-3xl text-green-700 font-semibold mb-6">
                Fresh from Neighbors' backyard 🌱
              </p>
              <p className="text-lg text-gray-700 mb-8">
                Buy and sell fresh, locally-grown produce from your neighbors' backyards. 
                Join a hyper-local community working together to reduce waste and expand access to fresh food.
              </p>
              <button
                onClick={onGetStarted}
                className="inline-flex items-center gap-2 px-8 py-4 bg-green-600 text-white font-semibold rounded-full hover:bg-green-700 transition-all shadow-lg hover:shadow-xl hover:scale-105"
              >
                Join the Movement!
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
            
            {/* Right side - Hero image */}
            <div className="order-1 lg:order-2">
              <div className="rounded-2xl overflow-hidden shadow-2xl transform hover:scale-105 transition-transform duration-300">
                <ImageWithFallback 
                  src={heroImage}
                  alt="Community sharing fresh produce"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            How It Works 🎯
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Join your hyper-local community and start buying, selling, and connecting with neighbors
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          <div className="text-center bg-white p-6 rounded-xl shadow-sm hover:shadow-lg transition-all hover:-translate-y-1">
            <div className="w-16 h-16 bg-green-600 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4 shadow-lg">
              1
            </div>
            <h3 className="font-semibold text-gray-900 mb-2 text-lg">Join Your Community</h3>
            <p className="text-gray-600">
              Sign up and join communities based on your neighborhood, workplace, or frequented spots
            </p>
          </div>

          <div className="text-center bg-white p-6 rounded-xl shadow-sm hover:shadow-lg transition-all hover:-translate-y-1">
            <div className="w-16 h-16 bg-green-600 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4 shadow-lg">
              2
            </div>
            <h3 className="font-semibold text-gray-900 mb-2 text-lg">Buy or Sell Produce</h3>
            <p className="text-gray-600">
              List your excess produce or find fresh items from neighbors using our point system
            </p>
          </div>

          <div className="text-center bg-white p-6 rounded-xl shadow-sm hover:shadow-lg transition-all hover:-translate-y-1">
            <div className="w-16 h-16 bg-green-600 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4 shadow-lg">
              3
            </div>
            <h3 className="font-semibold text-gray-900 mb-2 text-lg">Delegate Tasks (Optional)</h3>
            <p className="text-gray-600">
              Optionally empower your teen or gardener to manage sales and deliveries on your behalf
            </p>
          </div>

          <div className="text-center bg-white p-6 rounded-xl shadow-sm hover:shadow-lg transition-all hover:-translate-y-1">
            <div className="w-16 h-16 bg-green-600 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4 shadow-lg">
              4
            </div>
            <h3 className="font-semibold text-gray-900 mb-2 text-lg">Drop-off</h3>
            <p className="text-gray-600">
              Drop-off produce, take photo of delivery and get paid in points.
            </p>
            <p className="text-gray-600">
              No awkward meetups or schedule coordination needed—safe, contactless, and convenient for everyone.
            </p>
          </div>

          <div className="text-center bg-white p-6 rounded-xl shadow-sm hover:shadow-lg transition-all hover:-translate-y-1">
            <div className="w-16 h-16 bg-green-600 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4 shadow-lg">
              5
            </div>
            <h3 className="font-semibold text-gray-900 mb-2 text-lg">Redeem or Donate Points</h3>
            <p className="text-gray-600">
              Redeem your points for gift cards or donate to local charities and food banks
            </p>
          </div>
        </div>
      </div>

      {/* Points System CTA */}
      <div className="bg-green-600 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Why Use a Points System?
          </h2>
          <p className="text-lg text-green-50 mb-8 max-w-3xl mx-auto">
            Our closed-loop point system minimizes payment processing fees and keeps more money in your community. 
            Points are available instantly (unlike credit cards that take 2-5 days), making escrow and returns seamless. 
            Buy points once, trade with neighbors, and redeem for gift cards or donate to charity.
          </p>
          <button
            onClick={onGetStarted}
            className="inline-flex items-center gap-2 px-8 py-4 bg-white text-green-600 font-semibold rounded-full hover:bg-gray-50 transition-colors shadow-lg"
          >
            Join CasaGrown Today
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Platform Benefits Section */}
      <div className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              Built for Safety & Convenience
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              CasaGrown is designed with features that make buying and selling homegrown produce, simple, safe and rewarding
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Transaction Safety */}
            <div className="bg-white border-2 border-green-200 p-8 rounded-2xl shadow-md hover:shadow-xl transition-all hover:-translate-y-1">
              <div className="w-14 h-14 bg-green-600 rounded-xl flex items-center justify-center mb-5 shadow-lg">
                <Shield className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Transaction Safety & Security</h3>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold mt-0.5">•</span>
                  <span className="text-sm">Built-in escrow system protects buyers and sellers</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold mt-0.5">•</span>
                  <span className="text-sm">Drop-off option for safety and convenience</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold mt-0.5">•</span>
                  <span className="text-sm">Safe for teen sellers</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold mt-0.5">•</span>
                  <span className="text-sm">Local-only membership keeps community trusted</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold mt-0.5">•</span>
                  <span className="text-sm">Dispute handling for complete peace of mind</span>
                </li>
              </ul>
            </div>

            {/* Instant Point Availability */}
            <div className="bg-white border-2 border-green-200 p-8 rounded-2xl shadow-md hover:shadow-xl transition-all hover:-translate-y-1">
              <div className="w-14 h-14 bg-green-600 rounded-xl flex items-center justify-center mb-5 shadow-lg">
                <Zap className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Instant Point Availability</h3>
              <p className="text-gray-700 mb-4 text-sm leading-relaxed">
                Unlike credit cards or Venmo which take <strong>2-5 business days</strong> to make funds available, 
                <strong className="text-green-600"> CasaGrown points are available immediately</strong> upon order completion.
              </p>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold mt-0.5">•</span>
                  <span className="text-sm">No waiting periods or banking delays</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold mt-0.5">•</span>
                  <span className="text-sm">Start spending points instantly</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold mt-0.5">•</span>
                  <span className="text-sm">Redeem for gift cards anytime</span>
                </li>
              </ul>
            </div>

            {/* Charity Donations */}
            <div className="bg-white border-2 border-green-200 p-8 rounded-2xl shadow-md hover:shadow-xl transition-all hover:-translate-y-1">
              <div className="w-14 h-14 bg-green-600 rounded-xl flex items-center justify-center mb-5 shadow-lg">
                <HandHeart className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Give Back to Your Community</h3>
              <p className="text-gray-700 mb-4 text-sm leading-relaxed">
                Turn your backyard surplus into community support by donating points to local charities and food banks.
              </p>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold mt-0.5">•</span>
                  <span className="text-sm">Donate points to local charities</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold mt-0.5">•</span>
                  <span className="text-sm">Support community food banks</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold mt-0.5">•</span>
                  <span className="text-sm">Every transaction reduces food waste</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold mt-0.5">•</span>
                  <span className="text-sm">Make a difference with every sale</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Mission Section */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              Why Trade Homegrown?
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              We're on a mission to eliminate wastage of food grown in American backyards 
              and expand access to freshly picked produce to many more people.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-emerald-200 p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-emerald-300 rounded-full flex items-center justify-center mb-4">
                <Sparkles className="w-6 h-6 text-emerald-700" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Incredible Freshness</h3>
              <p className="text-sm text-gray-700">
                Fruits in grocery stores often take weeks to months to reach the shelves. CasaGrown connects you with neighbors for produce picked fresh from the tree.
              </p>
            </div>

            <div className="bg-amber-200 p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-amber-300 rounded-full flex items-center justify-center mb-4">
                <Ban className="w-6 h-6 text-amber-700" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Stop Food Waste</h3>
              <p className="text-sm text-gray-700">
                Over 11.5 billion pounds of backyard produce goes to waste every year. Join us in saving it to feed 28 million people.
              </p>
            </div>

            <div className="bg-sky-200 p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-sky-300 rounded-full flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-sky-700" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Beat Inflation</h3>
              <p className="text-sm text-gray-700">
                Earn extra cash from your garden selling homegrown abundance to neighbors, or save money by finding high-quality produce right next door.
              </p>
            </div>

            <div className="bg-pink-200 p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-pink-300 rounded-full flex items-center justify-center mb-4">
                <GraduationCap className="w-6 h-6 text-pink-700" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Teen Opportunity</h3>
              <p className="text-sm text-gray-700">
                Empower teens to learn business skills and earn pocket money by selling and delivering homegrown produce.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Final CTA */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl p-8 sm:p-12 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Ready to Make a Difference?
          </h2>
          <p className="text-lg text-gray-700 mb-6 max-w-2xl mx-auto">
            Join thousands of neighbors already reducing waste, saving money, and building stronger communities.
          </p>
          <button
            onClick={onGetStarted}
            className="inline-flex items-center gap-2 px-8 py-4 bg-green-600 text-white font-semibold rounded-full hover:bg-green-700 transition-colors shadow-lg hover:shadow-xl"
          >
            Join the Movement!
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}