import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type DelegationMode = 'baseline' | 'business' | 'team' | 'combined';

interface DelegationModeContextType {
  mode: DelegationMode;
  setMode: (mode: DelegationMode) => void;
  hasBusinessDelegation: boolean;
  hasTeamDelegation: boolean;
}

const DelegationModeContext = createContext<DelegationModeContextType | undefined>(undefined);

export function DelegationModeProvider({ children }: { children: ReactNode }) {
  const [mode, setModeState] = useState<DelegationMode>('baseline');

  // Initialize mode from URL parameter or localStorage
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const urlMode = urlParams.get('delegation') as DelegationMode | null;
    
    if (urlMode && ['baseline', 'business', 'team', 'combined'].includes(urlMode)) {
      setModeState(urlMode);
      localStorage.setItem('casagrown_delegation_mode', urlMode);
    } else {
      const savedMode = localStorage.getItem('casagrown_delegation_mode') as DelegationMode | null;
      if (savedMode && ['baseline', 'business', 'team', 'combined'].includes(savedMode)) {
        setModeState(savedMode);
      }
    }
  }, []);

  const setMode = (newMode: DelegationMode) => {
    setModeState(newMode);
    localStorage.setItem('casagrown_delegation_mode', newMode);
    
    // Update URL without reload
    const url = new URL(window.location.href);
    url.searchParams.set('delegation', newMode);
    window.history.replaceState({}, '', url.toString());
  };

  const hasBusinessDelegation = mode === 'business' || mode === 'combined';
  const hasTeamDelegation = mode === 'team' || mode === 'combined';

  return (
    <DelegationModeContext.Provider value={{ mode, setMode, hasBusinessDelegation, hasTeamDelegation }}>
      {children}
    </DelegationModeContext.Provider>
  );
}

export function useDelegationMode() {
  const context = useContext(DelegationModeContext);
  if (!context) {
    throw new Error('useDelegationMode must be used within DelegationModeProvider');
  }
  return context;
}
