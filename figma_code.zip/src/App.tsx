import React, { useState, useEffect } from 'react';
import { Leaf, Menu, X, Bell, Search, Plus, User, ShoppingCart, Gift, LogOut, Users, Settings, UserPlus, Send, Copy, Check } from 'lucide-react';
import LandingPage from './components/LandingPage';
import LoginPage from './components/LoginPage';
import SignupFlow from './components/SignupFlow';
import ShareMovement from './components/ShareMovement';
import MainFeed from './components/MainFeed';
import PostDetail from './components/PostDetail';
import ProfilePage from './components/ProfilePage';
import MyPosts from './components/MyPosts';
import { copyToClipboard } from './utils/clipboard';
import { DelegationModeProvider } from './contexts/DelegationModeContext';
import VersionSwitcher from './components/VersionSwitcher';
import Logo from './components/Logo';
import CreatePost from './components/CreatePost';
import OrdersPage from './components/OrdersPage';
import RedemptionStore from './components/RedemptionStore';
import NotificationsPage from './components/NotificationsPage';
import Chats from './components/Chats';
import TransferPoints from './components/TransferPoints';
import BuyPoints from './components/BuyPoints';
import FollowingPage from './components/FollowingPage';
import UserPostsPage from './components/UserPostsPage';
import UserSearchPage from './components/UserSearchPage';
import AdminDashboard from './components/AdminDashboard';
import DelegateManagement from './components/DelegateManagement';

// Mock user type
interface User {
  id: string;
  name: string;
  email: string;
  photo?: string;
  points: number;
  communities: string[];
  roles: string[];
  completedProfile: boolean;
  hasPostedIntro?: boolean;
}

// Route type
type Route = 'landing' | 'login' | 'signup' | 'share-movement' | 'feed' | 'create-post' | 'post-detail' | 'orders' | 'redemption' | 'profile' | 'my-posts' | 'notifications' | 'chats' | 'transfer-points' | 'buy-points' | 'following' | 'user-posts' | 'user-search' | 'admin-dashboard' | 'delegate-management';

function AppContent() {
  const [currentRoute, setCurrentRoute] = useState<Route>('landing');
  const [user, setUser] = useState<User | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showPointsDropdown, setShowPointsDropdown] = useState(false);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteLinkCopied, setInviteLinkCopied] = useState(false);
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [followingUsers, setFollowingUsers] = useState<Set<string>>(new Set(['2', '4', '5', '8'])); // Mock following data
  const [createPostType, setCreatePostType] = useState<'sell' | 'buy' | 'service-request' | 'service-offer' | 'advice' | null>(null);
  const [postingAsDelegateFor, setPostingAsDelegateFor] = useState<string | null>(null);
  
  // FOR TESTING: Mock intro post data to verify display works
  const [introPostData, setIntroPostData] = useState<{
    message: string;
    media?: string;
    mediaType?: 'image' | 'video';
    gardenProduce: string[];
  } | null>({
    message: "Hey neighbors! Excited to join this amazing community. Looking forward to sharing fresh produce from my backyard garden and connecting with fellow gardeners!",
    gardenProduce: ['Tomatoes', 'Lemons', 'Basil', 'Peppers'],
    media: 'https://images.unsplash.com/photo-1697046028903-18150964b6f2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWNreWFyZCUyMGdhcmRlbiUyMHZlZ2V0YWJsZXMlMjBoYXJ2ZXN0JTIwYmFza2V0fGVufDF8fHx8MTc2OTY3NjgzOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    mediaType: 'image'
  });

  // Delegation state
  const [delegations, setDelegations] = useState<Array<{
    id: string;
    delegateId: string;
    delegateName: string;
    delegateCommunity: string;
    status: 'active' | 'pending';
    dateRequested: string;
    dateAccepted?: string;
  }>>([]);
  
  const [delegationRequests, setDelegationRequests] = useState<Array<{
    id: string;
    fromUserId: string;
    fromUserName: string;
    fromUserCommunity: string;
    status: 'pending' | 'accepted' | 'rejected';
    dateRequested: string;
  }>>([
    // Mock data: Someone wants me to be their delegate
    {
      id: 'req-1',
      fromUserId: 'user-3',
      fromUserName: 'Michael Torres',
      fromUserCommunity: 'Sunset Hills',
      status: 'pending',
      dateRequested: new Date().toISOString()
    }
  ]);

  // Badge counts for navigation (mock data)
  const unreadMessagesCount = 2;
  const unreadMessagesCountV2 = 4; // Total unread for Chats V2 (2 + 1 + 1 + 0)
  const pendingOrdersCount = 2;
  const flaggedPostsCount = 1;
  const unreadNotificationsCount = 5; // Includes 2 delegate notifications

  // Check if user is logged in on mount
  /* Temporarily disabled to show landing page
  useEffect(() => {
    const savedUser = localStorage.getItem('casagrown_user');
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser);
      setUser(parsedUser);
      if (parsedUser.completedProfile) {
        setCurrentRoute('feed');
      } else {
        setCurrentRoute('signup');
      }
    }
  }, []);
  */

  const handleLogin = (email: string, name: string) => {
    // Check if this is the admin test account
    const isAdmin = email === 'admin@casagrown.com' || email.includes('admin');
    
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      email,
      points: 0, // No signup reward - only first post reward based on policy
      communities: isAdmin ? ['Lincoln Park Community', 'Downtown Gardens'] : [],
      roles: isAdmin ? ['admin', 'buyer', 'seller'] : [],
      completedProfile: isAdmin ? true : false
    };
    setUser(newUser);
    localStorage.setItem('casagrown_user', JSON.stringify(newUser));
    
    // Admin goes directly to feed
    if (isAdmin) {
      setCurrentRoute('feed');
    } else {
      setCurrentRoute('signup');
    }
  };

  const handleCompleteSignup = (updatedUser: User) => {
    const completeUser = { ...updatedUser, completedProfile: true };
    setUser(completeUser);
    localStorage.setItem('casagrown_user', JSON.stringify(completeUser));
    setCurrentRoute('feed');
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('casagrown_user');
    setCurrentRoute('landing');
    setMobileMenuOpen(false);
  };

  const updateUserPoints = (points: number) => {
    if (user) {
      const updatedUser = { ...user, points };
      setUser(updatedUser);
      localStorage.setItem('casagrown_user', JSON.stringify(updatedUser));
    }
  };

  const navigateToPost = (postId: string) => {
    setSelectedPostId(postId);
    setCurrentRoute('post-detail');
  };

  const navigateToUserPosts = (userId: string) => {
    setSelectedUserId(userId);
    setCurrentRoute('user-posts');
  };

  const toggleFollow = (userId: string) => {
    const newFollowing = new Set(followingUsers);
    if (newFollowing.has(userId)) {
      newFollowing.delete(userId);
    } else {
      newFollowing.add(userId);
    }
    setFollowingUsers(newFollowing);
  };

  // Delegation handlers
  const handleAddDelegation = (delegation: any) => {
    setDelegations(prev => [...prev, delegation]);
    // In real app, would send notification to delegate about the request
    console.log(`Notification sent to ${delegation.delegateName}: ${user?.name} wants you to be their delegate`);
  };

  const handleRemoveDelegation = (delegationId: string) => {
    const delegation = delegations.find(d => d.id === delegationId);
    if (delegation) {
      // Notify the delegate that access has been revoked
      console.log(`Notification sent to ${delegation.delegateName}: ${user?.name} has revoked your delegate access`);
    }
    setDelegations(prev => prev.filter(d => d.id !== delegationId));
  };

  const handleAcceptDelegation = (requestId: string) => {
    const request = delegationRequests.find(r => r.id === requestId);
    if (!request) return;

    // Update request status
    setDelegationRequests(prev =>
      prev.map(r => r.id === requestId ? { ...r, status: 'accepted' as const } : r)
    );

    // Notify the person who sent the request that it was accepted
    console.log(`Notification sent to ${request.fromUserName}: ${user?.name} accepted your delegation request`);
  };

  const handleRejectDelegation = (requestId: string) => {
    const request = delegationRequests.find(r => r.id === requestId);
    if (request) {
      // Notify the person who sent the request that it was rejected
      console.log(`Notification sent to ${request.fromUserName}: ${user?.name} declined your delegation request`);
    }
    setDelegationRequests(prev =>
      prev.map(r => r.id === requestId ? { ...r, status: 'rejected' as const } : r)
    );
  };

  const handleInactivateDelegatingFor = (requestId: string) => {
    const request = delegationRequests.find(r => r.id === requestId);
    if (request) {
      // Notify the person that the delegate has inactivated their delegation
      console.log(`Notification sent to ${request.fromUserName}: ${user.name} is no longer selling on your behalf`);
    }
    // Mark delegation request as inactive/rejected
    setDelegationRequests(prev =>
      prev.map(r => r.id === requestId ? { ...r, status: 'rejected' as const } : r)
    );
  };

  const handleAccountDeactivation = () => {
    if (!user) return;

    // 1. Revoke all delegations where I delegated to others
    delegations.forEach(delegation => {
      console.log(`Notification sent to ${delegation.delegateName}: ${user.name} has deactivated their account. Your delegate access has been revoked.`);
    });

    // 2. Inactivate all delegations where I was delegating for others
    delegationRequests.filter(r => r.status === 'accepted').forEach(request => {
      console.log(`Notification sent to ${request.fromUserName}: ${user.name} has deactivated their account and can no longer sell on your behalf.`);
    });

    // 3. Clear delegations
    setDelegations([]);
    setDelegationRequests([]);

    // 4. Logout user
    handleLogout();
  };

  // Get delegated users for CreatePost (users who have accepted to let me post for them)
  const getDelegatedUsersForPosting = () => {
    return delegationRequests
      .filter(r => r.status === 'accepted')
      .map(r => ({
        id: r.fromUserId,
        name: r.fromUserName,
        community: r.fromUserCommunity
      }));
  };

  // Header component
  const Header = () => {
    if (!user || currentRoute === 'landing' || currentRoute === 'login' || currentRoute === 'signup' || currentRoute === 'share-movement') {
      return null;
    }

    return (
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Logo 
              size="md"
              showText={true}
              onClick={() => setCurrentRoute('feed')}
            />

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-6">
              <button
                onClick={() => setCurrentRoute('feed')}
                className={`text-sm font-medium transition-colors ${
                  currentRoute === 'feed' ? 'text-green-600' : 'text-gray-700 hover:text-green-600'
                }`}
              >
                Feed
              </button>
              <button
                onClick={() => setCurrentRoute('chats')}
                className={`text-sm font-medium transition-colors relative ${
                  currentRoute === 'chats' ? 'text-green-600' : 'text-gray-700 hover:text-green-600'
                }`}
              >
                Chats
                {unreadMessagesCount > 0 && (
                  <span className="absolute -top-1 -right-4 bg-red-500 text-white text-xs font-bold px-1.5 py-0.5 rounded-full min-w-[20px] text-center">
                    {unreadMessagesCount}
                  </span>
                )}
              </button>
              <button
                onClick={() => setCurrentRoute('orders')}
                className={`text-sm font-medium transition-colors relative ${
                  currentRoute === 'orders' ? 'text-green-600' : 'text-gray-700 hover:text-green-600'
                }`}
              >
                Orders
                {pendingOrdersCount > 0 && (
                  <span className="absolute -top-1 -right-4 bg-red-500 text-white text-xs font-bold px-1.5 py-0.5 rounded-full min-w-[20px] text-center">
                    {pendingOrdersCount}
                  </span>
                )}
              </button>
              <button
                onClick={() => setCurrentRoute('my-posts')}
                className={`text-sm font-medium transition-colors relative ${
                  currentRoute === 'my-posts' ? 'text-green-600' : 'text-gray-700 hover:text-green-600'
                }`}
              >
                My Posts
                {flaggedPostsCount > 0 && (
                  <span className="absolute -top-1 -right-4 bg-red-500 text-white text-xs font-bold px-1.5 py-0.5 rounded-full min-w-[20px] text-center">
                    {flaggedPostsCount}
                  </span>
                )}
              </button>
              <button
                onClick={() => setCurrentRoute('redemption')}
                className={`text-sm font-medium transition-colors ${
                  currentRoute === 'redemption' ? 'text-green-600' : 'text-gray-700 hover:text-green-600'
                }`}
              >
                Redeem
              </button>
              <button
                onClick={() => setCurrentRoute('transfer-points')}
                className={`text-sm font-medium transition-colors ${
                  currentRoute === 'transfer-points' ? 'text-green-600' : 'text-gray-700 hover:text-green-600'
                }`}
              >
                Transfer Points
              </button>
              <button
                onClick={() => setCurrentRoute('delegate-management')}
                className={`text-sm font-medium transition-colors relative ${
                  currentRoute === 'delegate-management' ? 'text-green-600' : 'text-gray-700 hover:text-green-600'
                }`}
              >
                Delegate Sales
                {delegationRequests.filter(req => req.status === 'pending').length > 0 && (
                  <span className="absolute -top-1 -right-4 bg-red-500 text-white text-xs font-bold px-1.5 py-0.5 rounded-full min-w-[20px] text-center">
                    {delegationRequests.filter(req => req.status === 'pending').length}
                  </span>
                )}
              </button>
            </nav>

            {/* Right side actions */}
            <div className="flex items-center gap-2 sm:gap-4">
              {/* Search Icon */}
              <button
                onClick={() => setCurrentRoute('user-search')}
                className="p-2 text-gray-600 hover:text-green-600 hover:bg-gray-50 rounded-full transition-colors"
                title="Search Users"
              >
                <Search className="w-5 h-5" />
              </button>

              {/* Invite Button */}
              <button
                onClick={() => setShowInviteModal(true)}
                className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-gradient-to-r from-green-600 to-green-500 text-white rounded-full hover:from-green-700 hover:to-green-600 transition-all shadow-sm hover:shadow-md"
                title="Invite Friends"
              >
                <UserPlus className="w-4 h-4" />
                <span className="text-sm font-medium">Invite</span>
              </button>

              {/* Invite Icon (Mobile) */}
              <button
                onClick={() => setShowInviteModal(true)}
                className="sm:hidden p-2 text-green-600 hover:text-green-700 hover:bg-green-50 rounded-full transition-colors"
                title="Invite Friends"
              >
                <UserPlus className="w-5 h-5" />
              </button>

              {/* Points display */}
              <div className="relative">
                <button
                  onClick={() => setShowPointsDropdown(!showPointsDropdown)}
                  className="flex items-center gap-2 px-3 py-1.5 bg-green-50 text-green-700 rounded-full hover:bg-green-100 transition-colors"
                >
                  <span className="font-semibold">{user.points}</span>
                  <span className="hidden sm:inline text-sm">points</span>
                </button>
                {showPointsDropdown && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-1">
                    <button
                      onClick={() => {
                        setShowPointsDropdown(false);
                        setCurrentRoute('buy-points');
                      }}
                      className="w-full px-4 py-2 text-left text-sm hover:bg-gray-50"
                    >
                      Buy More Points
                    </button>
                    <button
                      onClick={() => {
                        setShowPointsDropdown(false);
                        setCurrentRoute('redemption');
                      }}
                      className="w-full px-4 py-2 text-left text-sm hover:bg-gray-50"
                    >
                      Redeem Points
                    </button>
                  </div>
                )}
              </div>

              {/* Notifications */}
              <button
                onClick={() => setCurrentRoute('notifications')}
                className="p-2 text-gray-600 hover:text-green-600 hover:bg-gray-50 rounded-full transition-colors relative"
              >
                <Bell className="w-5 h-5" />
                {unreadNotificationsCount > 0 && (
                  <span className="absolute top-0 right-0 bg-red-500 text-white text-xs font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
                    {unreadNotificationsCount}
                  </span>
                )}
              </button>

              {/* Profile */}
              <button
                onClick={() => setCurrentRoute('profile')}
                className="p-1.5 text-gray-600 hover:text-green-600 hover:bg-gray-50 rounded-full transition-colors"
              >
                {user.photo ? (
                  <img src={user.photo} alt={user.name} className="w-8 h-8 rounded-full object-cover" />
                ) : (
                  <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center text-white text-sm font-semibold">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                )}
              </button>

              {/* Mobile menu button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 text-gray-600 hover:bg-gray-50 rounded-lg"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <div className="md:hidden border-t border-gray-200 py-4">
              <nav className="flex flex-col gap-2">
                <button
                  onClick={() => {
                    setCurrentRoute('feed');
                    setMobileMenuOpen(false);
                  }}
                  className="px-4 py-2 text-left text-gray-700 hover:bg-gray-50 rounded-lg"
                >
                  Feed
                </button>
                <button
                  onClick={() => {
                    setCurrentRoute('chats');
                    setMobileMenuOpen(false);
                  }}
                  className="px-4 py-2 text-left text-gray-700 hover:bg-gray-50 rounded-lg flex items-center justify-between relative"
                >
                  <span>Chats</span>
                  {unreadMessagesCount > 0 && (
                    <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full min-w-[20px] text-center">
                      {unreadMessagesCount}
                    </span>
                  )}
                </button>
                <button
                  onClick={() => {
                    setCurrentRoute('orders');
                    setMobileMenuOpen(false);
                  }}
                  className="px-4 py-2 text-left text-gray-700 hover:bg-gray-50 rounded-lg flex items-center justify-between relative"
                >
                  <span>Orders</span>
                  {pendingOrdersCount > 0 && (
                    <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full min-w-[20px] text-center">
                      {pendingOrdersCount}
                    </span>
                  )}
                </button>
                <button
                  onClick={() => {
                    setCurrentRoute('my-posts');
                    setMobileMenuOpen(false);
                  }}
                  className="px-4 py-2 text-left text-gray-700 hover:bg-gray-50 rounded-lg flex items-center justify-between relative"
                >
                  <span>My Posts</span>
                  {flaggedPostsCount > 0 && (
                    <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full min-w-[20px] text-center">
                      {flaggedPostsCount}
                    </span>
                  )}
                </button>
                <button
                  onClick={() => {
                    setCurrentRoute('buy-points');
                    setMobileMenuOpen(false);
                  }}
                  className="px-4 py-2 text-left text-gray-700 hover:bg-gray-50 rounded-lg"
                >
                  Buy Points
                </button>
                <button
                  onClick={() => {
                    setCurrentRoute('redemption');
                    setMobileMenuOpen(false);
                  }}
                  className="px-4 py-2 text-left text-gray-700 hover:bg-gray-50 rounded-lg"
                >
                  Redeem Points
                </button>
                <button
                  onClick={() => {
                    setCurrentRoute('delegate-management');
                    setMobileMenuOpen(false);
                  }}
                  className="px-4 py-2 text-left text-gray-700 hover:bg-gray-50 rounded-lg flex items-center justify-between relative"
                >
                  <span>Delegate Sales</span>
                  {delegationRequests.filter(r => r.status === 'pending').length > 0 && (
                    <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full min-w-[20px] text-center">
                      {delegationRequests.filter(r => r.status === 'pending').length}
                    </span>
                  )}
                </button>
                <button
                  onClick={handleLogout}
                  className="px-4 py-2 text-left text-red-600 hover:bg-red-50 rounded-lg flex items-center gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  Logout
                </button>
              </nav>
            </div>
          )}
        </div>
      </header>
    );
  };

  // Footer component
  const Footer = () => {
    if (!user || currentRoute === 'landing' || currentRoute === 'login') {
      return null;
    }

    const isAdmin = user.roles.includes('admin');

    return (
      <footer className="bg-gray-50 border-t border-gray-200 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                  <Leaf className="w-5 h-5 text-white" />
                </div>
                <span className="text-lg font-bold text-gray-900">CasaGrown</span>
              </div>
              <p className="text-sm text-gray-600">
                Connecting neighborhoods to eliminate food waste and expand access to fresh produce.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-4">Learn More</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>
                  <button className="hover:text-green-600 transition-colors">Why Points System?</button>
                </li>
                <li>
                  <button className="hover:text-green-600 transition-colors">How It Works</button>
                </li>
                <li>
                  <button className="hover:text-green-600 transition-colors">Support</button>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-4">Legal</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>
                  <button className="hover:text-green-600 transition-colors">Privacy Policy</button>
                </li>
                <li>
                  <button className="hover:text-green-600 transition-colors">User Agreement</button>
                </li>
                <li>
                  <button className="hover:text-green-600 transition-colors">Terms of Service</button>
                </li>
                {isAdmin && (
                  <li>
                    <button 
                      onClick={() => setCurrentRoute('admin-dashboard')}
                      className="flex items-center gap-1.5 hover:text-blue-600 transition-colors font-medium"
                    >
                      <Settings className="w-4 h-4" />
                      Admin Dashboard
                    </button>
                  </li>
                )}
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-200 text-center text-sm text-gray-500">
            © 2026 CasaGrown. All rights reserved.
          </div>
        </div>
      </footer>
    );
  };

  // Render current route
  const renderContent = () => {
    switch (currentRoute) {
      case 'landing':
        return <LandingPage onGetStarted={() => setCurrentRoute('login')} />;
      case 'login':
        return <LoginPage onLogin={handleLogin} onBack={() => setCurrentRoute('landing')} />;
      case 'signup':
        return user ? <SignupFlow user={user} onComplete={(updatedUser, introPost) => {
          handleCompleteSignup(updatedUser);
          if (introPost) {
            setIntroPostData(introPost);
          }
        }} onBack={() => setCurrentRoute('login')} /> : null;
      case 'share-movement':
        return user ? (
          <ShareMovement 
            hasPostedIntro={user.hasPostedIntro || false}
            userName={user.name}
            userId={user.id}
            earnedPoints={user.points}
            onContinue={() => setCurrentRoute('feed')} 
            onSkip={() => setCurrentRoute('feed')} 
          />
        ) : null;
      case 'feed':
        return user ? (
          <MainFeed 
            user={user} 
            onCreatePost={() => { 
              setCreatePostType(null); 
              setPostingAsDelegateFor(null);
              setCurrentRoute('create-post'); 
            }} 
            onCreateDelegatePost={
              getDelegatedUsersForPosting().length > 0 
                ? () => {
                    setCreatePostType('sell');
                    // Pre-select first delegated user
                    const delegatedUsers = getDelegatedUsersForPosting();
                    if (delegatedUsers.length > 0) {
                      setPostingAsDelegateFor(delegatedUsers[0].id);
                    }
                    setCurrentRoute('create-post');
                  }
                : undefined
            }
            onViewPost={(postId) => {
              setSelectedPostId(postId);
              setCurrentRoute('post-detail');
            }}
            onBuyPoints={() => {
              setCurrentRoute('buy-points');
            }}
            introPost={introPostData}
          />
        ) : null;
      case 'create-post':
        return user ? (
          <CreatePost 
            user={user} 
            onBack={() => setCurrentRoute('feed')} 
            onComplete={() => setCurrentRoute('feed')} 
            initialPostType={createPostType || undefined}
            delegatedUsers={getDelegatedUsersForPosting()}
            postingAsDelegateFor={postingAsDelegateFor}
          />
        ) : null;
      case 'post-detail':
        return user && selectedPostId ? (
          <PostDetail 
            user={user} 
            postId={selectedPostId} 
            onBack={() => setCurrentRoute('feed')} 
            updateUserPoints={updateUserPoints}
            onCreatePost={(postType) => { setCreatePostType(postType || null); setCurrentRoute('create-post'); }}
          />
        ) : null;
      case 'orders':
        return user ? <OrdersPage user={user} /> : null;
      case 'redemption':
        return user ? <RedemptionStore user={user} updateUserPoints={updateUserPoints} /> : null;
      case 'profile':
        return user ? <ProfilePage user={user} onUpdate={setUser} onLogout={handleLogout} onNavigateToFollowing={() => setCurrentRoute('following')} onDeactivateAccount={handleAccountDeactivation} /> : null;
      case 'my-posts':
        return user ? <MyPosts user={user} onViewPost={navigateToPost} /> : null;
      case 'notifications':
        return user ? <NotificationsPage user={user} onNavigateToPost={navigateToPost} /> : null;
      case 'chats':
        return user ? <Chats user={user} /> : null;
      case 'transfer-points':
        return user ? <TransferPoints user={user} updateUserPoints={updateUserPoints} /> : null;
      case 'buy-points':
        return user ? <BuyPoints user={user} updateUserPoints={updateUserPoints} onBack={() => {
          // Check if there's a pending drop-off request
          const pendingRequest = sessionStorage.getItem('pendingDropoffRequest');
          if (pendingRequest) {
            // Return to feed with a flag to restore the modal
            sessionStorage.setItem('shouldRestoreDropoffModal', 'true');
          }
          setCurrentRoute('feed');
        }} /> : null;
      case 'following':
        return user ? <FollowingPage user={user} onBack={() => setCurrentRoute('profile')} onViewPost={navigateToPost} onViewUserPosts={navigateToUserPosts} /> : null;
      case 'user-posts':
        return user && selectedUserId ? (
          <UserPostsPage 
            userId={selectedUserId}
            currentUser={user}
            onBack={() => setCurrentRoute('feed')}
            onPostClick={navigateToPost}
            onFollowToggle={toggleFollow}
            isFollowing={followingUsers.has(selectedUserId)}
          />
        ) : null;
      case 'user-search':
        return user ? (
          <UserSearchPage 
            currentUser={user}
            onBack={() => setCurrentRoute('feed')}
            onViewUserPosts={navigateToUserPosts}
            onFollowToggle={toggleFollow}
            followingUsers={followingUsers}
          />
        ) : null;
      case 'admin-dashboard':
        return user && user.roles.includes('admin') ? <AdminDashboard onBack={() => setCurrentRoute('feed')} /> : null;
      case 'delegate-management':
        return user ? (
          <DelegateManagement
            user={{ id: user.id, name: user.name, community: user.communities[0] || '' }}
            onBack={() => setCurrentRoute('feed')}
            delegations={delegations}
            delegationRequests={delegationRequests}
            onAddDelegation={handleAddDelegation}
            onRemoveDelegation={handleRemoveDelegation}
            onAcceptDelegation={handleAcceptDelegation}
            onRejectDelegation={handleRejectDelegation}
            onInactivateDelegatingFor={handleInactivateDelegatingFor}
          />
        ) : null;
      default:
        return <LandingPage onGetStarted={() => setCurrentRoute('login')} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <main className="flex-1">
        {renderContent()}
      </main>
      <Footer />
      
      {/* Invite Modal */}
      {showInviteModal && user && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="bg-gradient-to-r from-green-600 to-green-500 p-6 text-white rounded-t-2xl">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                    <UserPlus className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold">Invite Friends & Neighbors</h2>
                    <p className="text-green-50 text-sm">Help grow your local community</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setShowInviteModal(false);
                    setInviteLinkCopied(false);
                  }}
                  className="text-white hover:bg-white/20 rounded-full p-2 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              {/* Benefits Section */}
              <div>
                <h3 className="font-bold text-gray-900 mb-3">Why Invite Others?</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <Users className="w-4 h-4 text-green-600" />
                      </div>
                      <div>
                        <div className="font-semibold text-green-900 mb-1">Build Community</div>
                        <p className="text-sm text-green-800">
                          More neighbors means more variety of produce and services available locally
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <ShoppingCart className="w-4 h-4 text-blue-600" />
                      </div>
                      <div>
                        <div className="font-semibold text-blue-900 mb-1">More Options</div>
                        <p className="text-sm text-blue-800">
                          Find more fresh produce and garden services from people you trust
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <Gift className="w-4 h-4 text-purple-600" />
                      </div>
                      <div>
                        <div className="font-semibold text-purple-900 mb-1">Grow the Community</div>
                        <p className="text-sm text-purple-800">
                          Help build a thriving local marketplace for fresh produce
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <Leaf className="w-4 h-4 text-amber-600" />
                      </div>
                      <div>
                        <div className="font-semibold text-amber-900 mb-1">Reduce Waste</div>
                        <p className="text-sm text-amber-800">
                          Help eliminate food waste in your neighborhood together
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Teen Seller Call-out */}
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-xl">👨‍👩‍👧‍👦</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-blue-900 mb-2">Perfect for Families!</h4>
                    <p className="text-sm text-blue-800 mb-2">
                      Homeowners: Create accounts for your teenagers to sell your backyard produce. It's an excellent way for them to:
                    </p>
                    <ul className="text-sm text-blue-800 space-y-1">
                      <li>• Earn pocket money from home</li>
                      <li>• Learn entrepreneurship and money management</li>
                      <li>• Contribute to the local community</li>
                      <li>• Build valuable life skills</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Share Options */}
              <div>
                <h3 className="font-bold text-gray-900 mb-3">Share Your Invite Link</h3>
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <code className="flex-1 bg-white px-3 py-2 rounded border border-gray-300 text-sm text-gray-700 overflow-x-auto">
                      https://casagrown.com/invite/{user.id}
                    </code>
                    <button
                      onClick={() => {
                        copyToClipboard(`https://casagrown.com/invite/${user.id}`);
                        setInviteLinkCopied(true);
                        setTimeout(() => setInviteLinkCopied(false), 2000);
                      }}
                      className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
                    >
                      {inviteLinkCopied ? (
                        <>
                          <Check className="w-4 h-4" />
                          <span className="hidden sm:inline">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4" />
                          <span className="hidden sm:inline">Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                  <p className="text-xs text-gray-500">
                    Share this link with friends, family, and neighbors in your community
                  </p>
                </div>

                {/* Quick Share Buttons */}
                <div className="grid grid-cols-1 gap-3">
                  <button
                    onClick={() => {
                      const shareData = {
                        title: 'Join CasaGrown!',
                        text: `Join me on CasaGrown! Buy and sell fresh produce with neighbors in our community.`,
                        url: `https://casagrown.com/invite/${user.id}`
                      };
                      
                      if (navigator.share) {
                        navigator.share(shareData).catch((error) => {
                          console.log('Error sharing:', error);
                        });
                      } else {
                        // Fallback: copy link if share is not supported
                        copyToClipboard(`https://casagrown.com/invite/${user.id}`);
                        setInviteLinkCopied(true);
                        setTimeout(() => setInviteLinkCopied(false), 2000);
                      }
                    }}
                    className="flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-green-600 to-green-500 text-white rounded-lg hover:from-green-700 hover:to-green-600 transition-all shadow-sm hover:shadow-md"
                  >
                    <Send className="w-5 h-5" />
                    <span className="font-medium">Share Invite</span>
                  </button>
                </div>
              </div>

              {/* Tips */}
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <h4 className="font-semibold text-green-900 mb-2">💡 Invitation Tips</h4>
                <ul className="text-sm text-green-800 space-y-1">
                  <li>• Invite neighbors within walking distance for easy pickup/delivery</li>
                  <li>• Share with local gardening groups and community boards</li>
                  <li>• Tell them about specific produce you're selling or looking for</li>
                  <li>• Remind them it's free to join!</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <DelegationModeProvider>
      <AppContent />
    </DelegationModeProvider>
  );
}