# CasaGrown - Simplify Sales Post to Drop-Off Only

## Changes Implemented

### ✅ 1. Platform Fee Notice
- Added 10% platform fee notice in `/components/CreatePost.tsx` after the price input field
- Blue informational banner explaining the fee is inclusive of credit card processing

## Changes Needed

### 2. CreatePost.tsx - Simplify Sell Post Fulfillment Options

**Location:** `/components/CreatePost.tsx` lines 855-1080

**Current:** Sellers can choose from 4 fulfillment options:
- Drop-off
- Allow pickup at my address
- Can meet nearby and hand over
- Allow buyer self harvest

**Change To:** Only drop-off option

**New Code:**
```tsx
{/* Fulfillment Options (for sell posts) - Drop-off only */}
{postType === 'sell' && (
  <div className="space-y-4">
    <label className="block text-sm font-medium text-gray-700 mb-3">
      Drop-Off Availability <span className="text-red-500">*</span>
      <span className="block text-xs text-gray-500 font-normal mt-1">Add dates when you can drop off to buyers (drop-off only)</span>
    </label>
    
    {/* Drop-off Info Banner */}
    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
      <p className="text-sm text-blue-900">
        <span className="font-semibold">Drop-off delivery:</span> You'll deliver items to buyers' addresses. Buyers will specify their delivery address and latest drop-off date when purchasing.
      </p>
    </div>

    {/* Drop-off dates */}
    <div className="border border-gray-300 rounded-lg p-4">
      <div className="mb-3">
        <span className="font-medium text-gray-900">Available drop-off dates</span>
        <p className="text-xs text-gray-600 mt-1">Add dates when you can drop off orders</p>
      </div>
      
      <div className="space-y-2">
        {fulfillmentOptions.dropoffDates.map((date, index) => (
          <div key={index} className="flex gap-2 items-center">
            <input
              type="date"
              value={date}
              onChange={(e) => updateDate('canDropoff', index, e.target.value)}
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent"
              min={new Date().toISOString().split('T')[0]}
            />
            <button
              onClick={() => removeDateFromOption('canDropoff', index)}
              className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        ))}
        <button
          onClick={() => {
            const today = new Date();
            today.setDate(today.getDate() + fulfillmentOptions.dropoffDates.length + 1);
            addDateToOption('canDropoff', today.toISOString().split('T')[0]);
          }}
          className="flex items-center gap-2 px-3 py-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors text-sm"
        >
          <Plus className="w-4 h-4" />
          Add date
        </button>
      </div>
    </div>
  </div>
)}
```

### 3. PostDetail.tsx - Add Chat Button to Drop-Off Request Modal

**Location:** `/components/PostDetail.tsx` line 1679

**Current:** Modal has Cancel and Submit Request buttons

**Change To:** Add "Chat with Seller" button above Cancel/Submit

**Replace lines 1679-1702 with:**
```tsx
<div className="space-y-3">
  {/* Chat with Seller Button */}
  <button
    onClick={() => {
      setShowDropoffRequestModal(false);
      setShowChatInterface(true);
    }}
    className="w-full flex items-center justify-center gap-2 px-4 py-2 border-2 border-green-600 text-green-700 font-medium rounded-lg hover:bg-green-50 transition-colors"
  >
    <MessageCircle className="w-5 h-5" />
    Chat with Seller
  </button>
  
  <div className="flex gap-3">
    <button
      onClick={() => {
        setShowDropoffRequestModal(false);
        // Reset form
        setDropoffRequestQuantity('');
        setDropoffRequestAddress('');
        setDropoffRequestDate('');
        setDropoffRequestLatestDate('');
        setDropoffRequestPreferredDates([]);
        setTempDropoffDate('');
        setErrorMessage('');
      }}
      className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
    >
      Cancel
    </button>
    <button
      onClick={handleSubmitDropoffRequest}
      className="flex-1 px-4 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
    >
      Submit Request
    </button>
  </div>
</div>
```

### 4. PostDetail.tsx - Hide Non-Drop-Off Fulfillment UI

**Location:** `/components/PostDetail.tsx` lines 809-940

**Current:** Shows pickup, meet nearby, and self-harvest options in post detail

**Change To:** Only show drop-off option

**Replace lines 805-941 with:**
```tsx
{/* Pickup Info */}
<div className="bg-gray-50 rounded-lg p-4 mb-6">
  <h3 className="font-semibold text-gray-900 mb-3">Fulfillment Method</h3>
  <div className="space-y-3 text-sm">
    {/* Drop-off Option */}
    {(post.fulfillmentOptions?.canDropoff || post.allowsDropoff) && (
      <div className="flex items-center gap-2 text-green-700 font-medium">
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
        </svg>
        <span>Seller will drop off at your address</span>
      </div>
    )}
    
    {/* Available Drop-off Dates */}
    {post.fulfillmentOptions?.dropoffDates && post.fulfillmentOptions.dropoffDates.length > 0 && (
      <div className="ml-6 space-y-1">
        <div className="text-xs text-gray-600 font-medium">Available dates:</div>
        {post.fulfillmentOptions.dropoffDates.map((date: string, index: number) => (
          <div key={index} className="flex items-center gap-2 text-gray-700">
            <Calendar className="w-4 h-4 text-gray-400" />
            <span>{formatDate(date)}</span>
          </div>
        ))}
      </div>
    )}
  </div>
</div>
```

### 5. PostDetail.tsx - Simplify Action Buttons

**Location:** `/components/PostDetail.tsx` lines 943-969

**Current:** Shows different buttons based on multiple fulfillment options

**Change To:** Always show "Make Drop-Off Request" button for sell posts

**Replace lines 943-969 with:**
```tsx
{/* Action Buttons */}
<div className="flex gap-3 mb-6">
  <button
    onClick={() => setShowDropoffRequestModal(true)}
    className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors"
  >
    <ShoppingCart className="w-5 h-5" />
    Make Drop-Off Request
  </button>
  
  <button
    onClick={() => setShowChatInterface(true)}
    className="flex-1 flex items-center justify-center gap-2 px-6 py-3 border-2 border-green-600 text-green-700 font-medium rounded-lg hover:bg-green-50 transition-colors"
  >
    <MessageCircle className="w-5 h-5" />
    Chat with Seller
  </button>
</div>
```

### 6. Update Buy Agreement Message

**Location:** `/components/PostDetail.tsx` line 428

**Current:** Builds agreement details with multiple fulfillment methods

**Change To:** Only include drop-off details

**Replace lines 427-438 with:**
```tsx
// Build the buy agreement message details (drop-off only)
let agreementDetails = `📋 Buy Agreement Posted:\n\nQuantity: ${quantity} ${quantityUnit}\nPrice: ${offerPrice} points\nDropoff to: ${dropoffAddress}\nLatest by: ${dropoffLatestDate}${dropoffTimeWindow ? `\nTime window: ${dropoffTimeWindow}` : ''}`;
```

## Testing Checklist

After implementing these changes:

- [ ] Sell post creation only shows drop-off availability
- [ ] Buyers can only request drop-off delivery
- [ ] Drop-off request modal has "Chat with Seller" button
- [ ] Buy agreement messages only reference drop-off
- [ ] Post detail page only shows drop-off fulfillment option
- [ ] Platform fee notice appears on sell posts

## Notes

- All references to pickup, meet nearby, and self-harvest should be removed from the sell post flow
- The buy post flow remains unchanged (buyers can still specify their fulfillment preferences)
- The simplification makes the MVP easier to understand and use
- Drop-off only aligns with the geotagged photo confirmation feature
