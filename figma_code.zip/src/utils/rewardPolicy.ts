// Mock reward policy based on zipcode/community
// In production, this would come from the backend API

export interface RewardPolicy {
  zipcode?: string;
  community?: string;
  firstPostReward: number; // Points awarded for first post
}

// Mock policy data - in production, this comes from the backend
const MOCK_REWARD_POLICIES: RewardPolicy[] = [
  // High reward areas (new communities we want to grow)
  { zipcode: '90001', firstPostReward: 100 },
  { zipcode: '90002', firstPostReward: 100 },
  { zipcode: '10001', firstPostReward: 100 },
  { zipcode: '60601', firstPostReward: 100 },
  
  // Medium reward areas (established communities)
  { zipcode: '94102', firstPostReward: 50 },
  { zipcode: '95120', firstPostReward: 50 }, // San Jose area
  { zipcode: '02101', firstPostReward: 50 },
  { zipcode: '98101', firstPostReward: 50 },
  
  // Standard reward areas
  { zipcode: '73301', firstPostReward: 25 },
  { zipcode: '33101', firstPostReward: 25 },
  
  // No reward areas (testing or restricted)
  { zipcode: '00000', firstPostReward: 0 },
];

// Community-based policies (override zipcode if both are present)
const COMMUNITY_REWARD_POLICIES: RewardPolicy[] = [
  { community: 'Lincoln High School Community', firstPostReward: 75 },
  { community: 'Washington High School Community', firstPostReward: 50 },
  { community: 'Roosevelt High School Community', firstPostReward: 50 },
  { community: 'Jefferson High School Community', firstPostReward: 25 },
];

/**
 * Get the reward policy for a given zipcode and/or community
 * In production, this would be an API call to the backend
 */
export function getRewardPolicy(zipcode?: string, community?: string): RewardPolicy {
  // Special case: zipcode 00000 always returns 0 (for testing no-reward scenarios)
  if (zipcode === '00000') {
    return { zipcode: '00000', firstPostReward: 0 };
  }
  
  // Community policy takes precedence
  if (community) {
    const communityPolicy = COMMUNITY_REWARD_POLICIES.find(
      p => p.community === community
    );
    if (communityPolicy) {
      return communityPolicy;
    }
  }
  
  // Fall back to zipcode policy
  if (zipcode) {
    const zipcodePolicy = MOCK_REWARD_POLICIES.find(
      p => p.zipcode === zipcode
    );
    if (zipcodePolicy) {
      return zipcodePolicy;
    }
  }
  
  // Default: 50 points for areas without specific policy
  return { firstPostReward: 50 };
}

/**
 * Calculate points to award for completing first post
 */
export function calculateFirstPostReward(zipcode?: string, community?: string): number {
  const policy = getRewardPolicy(zipcode, community);
  return policy.firstPostReward;
}