
  # Responsive Web and Mobile Apps

  This is a code bundle for Responsive Web and Mobile Apps. The original project is available at https://www.figma.com/design/CVA4SrNdaYyVIWmXh9SNDX/Responsive-Web-and-Mobile-Apps.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  